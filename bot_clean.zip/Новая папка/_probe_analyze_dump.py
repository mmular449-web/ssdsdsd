"""Разбор сохранённого HTML выдачи: где именно лежат объявления."""

from __future__ import annotations

import json
import re
from pathlib import Path

HTML = Path("_search_dump.html").read_text(encoding="utf-8")

print(f"длина: {len(HTML)}")

# --- 1. Что за страница: заголовок/заголовки ---
print("\n=== Заголовки страницы")
for tag in ("h1", "h2"):
    for m in re.findall(rf"<{tag}[^>]*>(.*?)</{tag}>", HTML, re.S)[:5]:
        text = " ".join(re.sub(r"<[^>]+>", " ", m).split())
        print(f"   <{tag}>: {text[:120]}")
m = re.search(r"<title[^>]*>(.*?)</title>", HTML, re.S)
print("   <title>:", m.group(1)[:120] if m else "ОТСУТСТВУЕТ")

# --- 2. Где упоминается captcha ---
print("\n=== Контекст 'captcha'")
i = HTML.lower().find("captcha")
print("   ...", re.sub(r"\s+", " ", HTML[max(0, i - 160):i + 160]))

# --- 3. data-marker: какие бывают ---
print("\n=== data-marker значения")
vals = re.findall(r'data-marker="([^"]+)"', HTML)
from collections import Counter
for v, c in Counter(vals).most_common(25):
    print(f"   {v}: {c}")

# --- 4. Двойное кодирование: window.__preloadedState__ = "..." ---
print("\n=== window.__preloadedState__")
m = re.search(r'window\.__preloadedState__\s*=\s*"((?:[^"\\]|\\.)*)"', HTML)
if m:
    raw = m.group(1)
    print(f"   длина строки-литерала: {len(raw)}")
    try:
        decoded = json.loads('"' + raw + '"')   # раскрываем JSON-строку
        print(f"   после раскрытия: {len(decoded)} симв.")
        state = json.loads(decoded)             # сам JSON
        print(f"   ключи верхнего уровня: {list(state)[:30]}")
        Path("_state.json").write_text(decoded, encoding="utf-8")
        print("   сохранено: _state.json")
    except Exception as exc:
        print(f"   ОШИБКА разбора: {type(exc).__name__}: {exc}")
else:
    print("   НЕ НАЙДЕН")

# --- 5. __staticRouterHydrationData ---
print("\n=== window.__staticRouterHydrationData")
m = re.search(
    r'window\.__staticRouterHydrationData\s*=\s*JSON\.parse\("((?:[^"\\]|\\.)*)"\)',
    HTML)
if m:
    try:
        data = json.loads(json.loads('"' + m.group(1) + '"'))
        print(f"   ключи: {list(data)[:20]}")
        print("   loaderData keys:", list(data.get("loaderData", {})))
        Path("_hydration.json").write_text(json.dumps(data, ensure_ascii=False),
                                           encoding="utf-8")
        print("   сохранено: _hydration.json")
    except Exception as exc:
        print(f"   ОШИБКА: {type(exc).__name__}: {exc}")
else:
    print("   НЕ НАЙДЕН")

# --- 6. Есть ли вообще	id объявлений (10+ цифр) ---
print("\n=== Поиск числовых id объявлений")
ids = re.findall(r"\b(\d{9,12})\b", HTML)
print(f"   найдено чисел 9-12 знаков: {len(ids)}, уникальных: {len(set(ids))}")
print(f"   примеры: {list(dict.fromkeys(ids))[:12]}")

# --- 7. Ссылки, похожие на карточки (ослабленный шаблон) ---
print("\n=== href, содержащие '_' и цифры")
cands = [h for h in re.findall(r'href="([^"]+)"', HTML) if re.search(r"_\d{6,}", h)]
print(f"   найдено: {len(cands)}")
for h in cands[:12]:
    print(f"      {h}")
