"""Фабрики бота и диспетчера aiogram + самолечение связи с Telegram.

Если api.telegram.org недоступен напрямую (провайдер режет), бот ходит
через SOCKS5-прокси. Публичные прокси живут часы, поэтому сессия умеет
самоустанавливаться: resolve_working_session() проверяет текущий канал
связи и при сбое перебирает кандидатов (прокси из .env, прямое
соединение, свежие публичные списки), пока не найдёт живой.
"""

import asyncio
import re
import urllib.request
from urllib.parse import parse_qs, urlparse

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from loguru import logger

import handlers
from config import TELEGRAM_PROXY_URL

PROXY_SOURCES = (
    # Ежечасно обновляемый список из репозитория-коллектора
    "https://raw.githubusercontent.com/kort0881/telegram-proxy-collector/"
    "main/socks5.txt",
    # Публичный агрегатор SOCKS5
    "https://api.proxyscrape.com/v2/?request=displayproxies"
    "&protocol=socks5&timeout=8000&country=all",
)


def _make_session(proxy_url: str) -> AiohttpSession | None:
    """Сессия для Telegram API: напрямую (None) или через прокси."""
    if not proxy_url or proxy_url == "direct":
        return None

    try:
        from aiohttp_socks import ProxyConnector
    except ImportError:
        # aiohttp-socks не установлен: http(s)-прокси aiohttp умеет сам
        return AiohttpSession(proxy=proxy_url)

    class ProxiedSession(AiohttpSession):
        """aiogram не принимает сторонний connector напрямую, поэтому
        подменяем фабрику коннекторов на aiohttp-socks."""

        def _create_connector(self):
            return ProxyConnector.from_url(proxy_url)

    return ProxiedSession(proxy=proxy_url)


def create_bot(token: str) -> Bot:
    """Создаёт инстанс бота с HTML-разметкой сообщений по умолчанию."""
    bot_kwargs: dict = {"default": DefaultBotProperties(parse_mode=ParseMode.HTML)}
    session = _make_session(TELEGRAM_PROXY_URL)
    if session is not None:
        bot_kwargs["session"] = session
    return Bot(token=token, **bot_kwargs)


# ------------------- самолечение связи с Telegram -------------------

def _fetch_public_proxies() -> list[str]:
    """Скачивает публичные списки SOCKS5 и возвращает строки socks5://host:port."""
    found: list[str] = []
    for url in PROXY_SOURCES:
        try:
            with urllib.request.urlopen(url, timeout=30) as response:
                text = response.read().decode("utf-8", errors="replace")
        except Exception as exc:
            logger.warning("Список прокси {} недоступен: {}", url, exc)
            continue
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("tg://socks"):
                qs = parse_qs(urlparse(line).query)
                found.append(f"socks5://{qs['server'][0]}:{qs['port'][0]}")
            elif line.startswith("socks5://"):
                found.append(line)
            elif re.match(r"^[\d.]+:\d+$", line):
                found.append(f"socks5://{line}")
    # Уникальные, сохраняя порядок
    return list(dict.fromkeys(found))


async def _try_session(bot: Bot, proxy_url: str) -> bool:
    """Пробует канал связи; при успехе сессия бота уже подменена."""
    new_session = _make_session(proxy_url)
    old_session = bot.session
    if new_session is not None:
        bot.session = new_session
    try:
        await asyncio.wait_for(bot.get_me(), timeout=20)
        logger.info(
            "Telegram API доступен через {}", proxy_url or "прямое соединение"
        )
        if new_session is not None and old_session is not None:
            await old_session.close()
        return True
    except Exception:
        # Возврат исходной сессии, неудачную закрываем
        failed = bot.session
        bot.session = old_session
        if failed is not None and failed is not old_session:
            await failed.close()
        return False


async def resolve_working_session(bot: Bot) -> bool:
    """Проверяет связь бота с Telegram и при сбое ищет рабочий канал.

    Кандидаты по порядку: текущая сессия (проверяется неявно первым
    вызовом), прокси из .env, прямое соединение, свежие публичные SOCKS5.
    Возвращает True, если связь восстановлена.
    """
    # Текущий канал ещё жив?
    try:
        await asyncio.wait_for(bot.get_me(), timeout=20)
        return True
    except Exception:
        logger.warning("Текущий канал связи с Telegram не отвечает, ищу другой")

    candidates: list[str] = []
    if TELEGRAM_PROXY_URL:
        candidates.append(TELEGRAM_PROXY_URL)
    candidates.append("direct")  # вдруг провайдер перестал резать
    try:
        public = await asyncio.to_thread(_fetch_public_proxies)
        candidates.extend(public[:80])  # первые 80 хватит
    except Exception:
        logger.warning("Не удалось скачать списки прокси")

    for proxy_url in candidates:
        if await _try_session(bot, proxy_url):
            return True

    logger.error("Рабочий канал связи с Telegram не найден — повторю позже")
    return False


def create_dispatcher() -> Dispatcher:
    """Создаёт диспетчер с FSM-хранилищем и подключает роутер хендлеров.

    MemoryStorage хранит состояния в памяти: после перезапуска бота
    незавершённый ввод ссылки сбрасывается — на практике это не страшно.
    """
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(handlers.router)
    return dp
