"""Замер №2: этот ли самый запрос прогрева выдаёт сессионную куку WAF.

Сравниваем две независимые сессии:
  A) сразу на поисковую выдачу (без прогрева);
  B) сначала GET / (прогрев), потом на выдачу.
Если куки различаются — прогрев не декоративный, а реально нужен.
Плюс печатаем заголовки ответа 403, чтобы понять, кто именно режет.
"""

from __future__ import annotations

import asyncio

from curl_cffi import AsyncSession

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
SEARCH = "https://m.avito.ru/moskva?q=hollister"


async def session_a() -> None:
    print("\n=== A) БЕЗ прогрева: сразу на выдачу")
    async with AsyncSession(impersonate="chrome120", timeout=30) as s:
        s.headers.update({"User-Agent": UA})
        r = await s.get(SEARCH)
        print(f"    HTTP {r.status_code} | куки: {sorted(s.cookies.keys())}")
        print(f"    значения: {dict(s.cookies)}")


async def session_b() -> None:
    print("\n=== B) С прогревом: GET / → пауза → выдача")
    async with AsyncSession(impersonate="chrome120", timeout=30) as s:
        s.headers.update({"User-Agent": UA})
        r0 = await s.get("https://m.avito.ru/")
        print(f"    прогрев: HTTP {r0.status_code} | куки: {sorted(s.cookies.keys())}")
        await asyncio.sleep(1.5)
        r1 = await s.get(SEARCH)
        print(f"    выдача:  HTTP {r1.status_code} | куки: {sorted(s.cookies.keys())}")
        print(f"    значения: {dict(s.cookies)}")

        print("\n    Заголовки ответа 403 (кто режет):")
        for k, v in sorted(r1.headers.items()):
            if k.lower() in ("server", "x-cache", "x-srv", "cf-ray", "x-waf",
                             "x-avito", "content-type", "set-cookie", "via",
                             "x-request-id", "x-id", "date", "connection",
                             "strict-transport-security"):
                print(f"      {k}: {v[:120]}")


async def main() -> None:
    await session_a()
    await session_b()


if __name__ == "__main__":
    asyncio.run(main())
