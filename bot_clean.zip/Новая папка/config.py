"""Конфигурация проекта: загрузка переменных окружения из .env."""

import os

from dotenv import load_dotenv

# Подгружаем переменные из .env (если файла нет — сработают значения по умолчанию)
load_dotenv()

# Токен бота, полученный у @BotFather
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")

# Путь к файлу базы данных SQLite
DB_PATH: str = os.getenv("DB_PATH", "avito_bot.db")

# Интервал мониторинга, минуты (можно дробное, например 1.5).
# ВАЖНО: чем чаще — тем выше риск блокировки IP со стороны Авито.
CHECK_INTERVAL_MINUTES: float = float(os.getenv("CHECK_INTERVAL_MINUTES", "1"))

# Жёсткий интервал опроса в секундах — цикл мониторинга запускается
# ровно раз в минуту. Считается от НАЧАЛА предыдущего цикла, поэтому
# длительная обработка не «съедает» интервал и накопления задержки нет.
POLL_INTERVAL_SECONDS: float = float(
    os.getenv("POLL_INTERVAL_SECONDS", str(int(CHECK_INTERVAL_MINUTES * 60)))
)

# Сколько первых объявлений из выдачи проверять за один проход
MAX_ITEMS_PER_QUERY: int = int(os.getenv("MAX_ITEMS_PER_QUERY", "8"))

# Сколько страниц объявлений парсить одновременно (1-5).
# Больше — быстрее доставка, но выше нагрузка на Авито.
PARSE_CONCURRENCY: int = max(1, min(5, int(os.getenv("PARSE_CONCURRENCY", "3"))))

# Отправлять ли объявления, существовавшие на момент первой проверки запроса:
#   0 — при первом проходе выдача только запоминается (нет спама старыми объявлениями);
#   1 — при первом проходе вся найденная выдача сразу отправляется пользователю.
SEND_BASELINE: bool = os.getenv("SEND_BASELINE", "0") == "1"

# ---------- Прокси и обход блокировок (curl_cffi) ----------

# Отпечаток TLS для curl_cffi. "chrome120" — запрошенный по умолчанию;
# "chrome131_android" даёт полностью мобильный отпечаток (TLS + заголовки).
IMPERSONATE: str = os.getenv("IMPERSONATE", "chrome120").strip() or "chrome120"

# Мобильные прокси с авторизацией, формат http://user:pass@ip:port
# Несколько адресов — через запятую: перебираются по кругу при блокировке.
# При ЗАБЛОКИРОВАННОМ IP это обязательный параметр: подмена TLS-отпечатка
# против бана по IP бессильна.
PROXY_URL: str = os.getenv("PROXY_URL", "").strip()
PROXY_URLS: list[str] = [
    p.strip() for p in PROXY_URL.replace(";", ",").split(",") if p.strip()
]

# Ссылка ротации внешнего IP у провайдера мобильных прокси.
# Парсер делает по ней GET (через сам прокси) при 403/капче/таймауте.
PROXY_ROTATION_URL: str = os.getenv("PROXY_ROTATION_URL", "").strip()

# Таймаут одного запроса к Авито, секунды
REQUEST_TIMEOUT: float = float(os.getenv("REQUEST_TIMEOUT", "30"))

# Сколько раз повторять запрос при блокировке/таймауте
RETRY_ATTEMPTS: int = max(1, int(os.getenv("RETRY_ATTEMPTS", "4")))

# База экспоненциальной паузы между повторами, секунды (5 → 10 → 20 → 40)
RETRY_BASE_DELAY: float = float(os.getenv("RETRY_BASE_DELAY", "5"))

# Минимальная пауза между двумя ротациями IP у провайдера, секунды
ROTATION_COOLDOWN: float = float(os.getenv("ROTATION_COOLDOWN", "10"))

# ---------- Прогрев сессии и имитация поведения (обход WAF) ----------

# Сколько живёт прогретая сессия, секунды. Прогрев — это GET на главную
# мобильной версии, который выдаёт куку антифрода: без неё поиск упирается
# в 403 на первом же запросе. По истечении TTL сессия прогревается заново.
WARMUP_TTL_SECONDS: float = float(os.getenv("WARMUP_TTL_SECONDS", "900"))

# Границы случайной паузы между запросами цепочки, секунды.
# Ровные интервалы — главный признак бота.
JITTER_MIN: float = float(os.getenv("JITTER_MIN", "1.2"))
JITTER_MAX: float = float(os.getenv("JITTER_MAX", "3.4"))

# Вероятность промежуточного перехода «главная → раздел → поиск с
# фильтрами». Реальный человек почти никогда не прыгает с главной сразу
# на отфильтрованную выдачу. 0 — отключить, 1 — всегда.
SIGHTSEEING_CHANCE: float = float(os.getenv("SIGHTSEEING_CHANCE", "0.35"))

# Тянуть ли полную карточку (описание, вся галерея) по каждому НОВОМУ
# объявлению. 1 — в алерте есть описание; 0 — экономим запросы к Авито.
FETCH_DETAILS: bool = os.getenv("FETCH_DETAILS", "1") == "1"

# Фоновый режим браузера (headless) — оставлено для совместимости со
# старым .env; новый парсер работает без браузера.
HEADLESS: bool = os.getenv("HEADLESS", "1") == "1"

# Отдельный прокси ТОЛЬКО для соединения с Telegram API (http:// или socks5://).
# Нужен, если api.telegram.org недоступен с вашего провайдера, при этом
# браузер (Авито) продолжает ходить напрямую с вашего IP.
TELEGRAM_PROXY_URL: str = os.getenv("TELEGRAM_PROXY_URL", "").strip()

# ---------- Подписка и оплата (ЮMoney, полуавтомат) ----------

# Telegram ID администратора (владельца бота): ему доступна /grant,
# заявки на подписку прилетают ему, у него самого подписка не требуется
ADMIN_ID: int = int(os.getenv("ADMIN_ID", "0") or 0)

# Ссылка на перевод по СБП: в приложении банка найдите «получить перевод
# по QR» и скопируйте ССЫЛКУ QR-кода (выглядит как https://qr.nspk.ru/...).
# По кнопке «Оплатить» у покупателя откроется его приложение банка.
PAYMENT_URL: str = os.getenv("PAYMENT_URL", "")

# Имя получателя перевода (для подсказки покупателю, кому уходят деньги)
PAYMENT_RECEIVER: str = os.getenv("PAYMENT_RECEIVER", "")

# Пробный период для новых пользователей, дней (0 — отключить)
TRIAL_DAYS: int = int(os.getenv("TRIAL_DAYS", "7") or 0)

# Цены тарифов, ₽ (длительности фиксированы: 7 / 30 / 90 / 365 дней)
PLAN_WEEK_PRICE: int = int(os.getenv("PLAN_WEEK_PRICE", "99") or 99)
PLAN_MONTH_PRICE: int = int(os.getenv("PLAN_MONTH_PRICE", "299") or 299)
PLAN_QUARTER_PRICE: int = int(os.getenv("PLAN_QUARTER_PRICE", "799") or 799)
PLAN_YEAR_PRICE: int = int(os.getenv("PLAN_YEAR_PRICE", "3299") or 3299)

# Ночная пауза: в это окно (часы локального времени) Авито не проверяется.
# Ночная активность — главный признак бота, а у многих провайдеров именно
# ночью Авито блокирует жёстче. Утром мониторинг возобновляется сам.
NIGHT_MODE: bool = os.getenv("NIGHT_MODE", "1") == "1"
NIGHT_MODE_START: int = int(os.getenv("NIGHT_MODE_START", "3") or 3)   # с 03:00
NIGHT_MODE_END: int = int(os.getenv("NIGHT_MODE_END", "10") or 10)     # до 10:00

# Требовать ли подписку для мониторинга (1 = да, 0 = бот бесплатный).
# Администратору подписка не нужна в любом случае.
SUBSCRIPTION_REQUIRED: bool = os.getenv("SUBSCRIPTION_REQUIRED", "0") == "1"
