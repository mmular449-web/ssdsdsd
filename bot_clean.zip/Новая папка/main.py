"""Точка входа: Telegram-бот (long polling) + мониторинг Авито раз в минуту.

Запуск: python main.py (после заполнения .env).

Устройство мониторинга
----------------------
Вместо планировщика (APScheduler) здесь нативный asyncio-цикл: он даёт
точный контроль над интервалом, которого требует задача. Цикл запускается
ровно раз в POLL_INTERVAL_SECONDS (по умолчанию 60 с), причём отсчёт
идёт от НАЧАЛА предыдущего прохода, а не от его конца — иначе длинный
цикл «съедал» бы интервал и опрос постепенно уезжал.

    t0 ──── работа цикла ──── t1          sleep(60 - (t1 - t0))
                                    t2 ──── работа цикла ──── ...

Так частота обращений к Авито остаётся строго фиксированной: ровно один
проход в минуту — не чаще (риск бана) и не реже (алерты теряют смысл).

Защита от блокировок распределена по двум уровням:
  * парсер (parser.py) — сам ротирует IP и повторяет запрос при
    403/капче/таймауте;
  * этот модуль — если цикл целиком провалился, держит нарастающую
    штрафную паузу, чтобы не долбить Авито каждую минуту впустую.
"""

import asyncio
import os
import random
from datetime import datetime, timedelta
from html import escape

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramNetworkError
from aiogram.utils.media_group import MediaGroupBuilder
from loguru import logger

from bot import create_bot, create_dispatcher, resolve_working_session
from config import (
    ADMIN_ID,
    BOT_TOKEN,
    CHECK_INTERVAL_MINUTES,
    DB_PATH,
    FETCH_DETAILS,
    IMPERSONATE,
    JITTER_MAX,
    JITTER_MIN,
    MAX_ITEMS_PER_QUERY,
    NIGHT_MODE,
    NIGHT_MODE_END,
    NIGHT_MODE_START,
    PARSE_CONCURRENCY,
    POLL_INTERVAL_SECONDS,
    PROXY_ROTATION_URL,
    PROXY_URLS,
    REQUEST_TIMEOUT,
    RETRY_ATTEMPTS,
    RETRY_BASE_DELAY,
    ROTATION_COOLDOWN,
    SEND_BASELINE,
    SIGHTSEEING_CHANCE,
    SUBSCRIPTION_REQUIRED,
    WARMUP_TTL_SECONDS,
)
from db import Database
from handlers import build_item_keyboard
from parser import AvitoItem, AvitoParser

# Логи: консоль (стандартный sink loguru) + файл с ротацией
os.makedirs("logs", exist_ok=True)
logger.add(
    "logs/bot_{time:YYYY-MM-DD}.log",
    rotation="10 MB",
    retention=5,
    encoding="utf-8",
    level="INFO",
)

MAX_PHOTOS_PER_ALBUM = 10  # жёсткое ограничение Telegram на размер media group
MAX_CAPTION_LEN = 1000     # лимит подписи Telegram — 1024, держим запас

# Минимальная пауза между циклами. Страховка от «сумасшедшего» цикла:
# если проход по какой-то причине выполнится мгновенно (или отработает
# дольше интервала), мониторинг не должен крутиться без пауз.
MIN_CYCLE_GAP = 0.5


def build_caption(item: dict) -> str:
    """Подпись к альбому: название, цена, описание, место, ссылка (HTML)."""
    title = escape(" ".join(item["title"].split())[:150])
    price = escape(item["price"])
    parts = [
        "📢 <b>Новое объявление</b>",
        "",
        f"📱 {title}",
        f"💰 <b>{price}</b>",
    ]

    if item.get("location"):
        parts.append(f"📍 {escape(item['location'])}")
    if item.get("seller"):
        parts.append(f"👤 {escape(item['seller'])}")

    description = " ".join((item.get("description") or "").split())
    if description:
        if len(description) > 300:
            description = description[:300].rsplit(" ", 1)[0] + "…"
        parts += ["", f"📝 <i>{escape(description)}</i>"]

    parts += ["", f'🔗 <a href="{item["item_url"]}">Открыть на Авито</a>']

    caption = "\n".join(parts)
    if len(caption) > MAX_CAPTION_LEN:
        caption = caption[:MAX_CAPTION_LEN].rsplit("\n", 1)[0] + "\n…"
    return caption


async def send_item(
    bot: Bot, db: Database, chat_id: int, item: dict, photo_mode: str
) -> bool:
    """Отправляет объявление с учётом режима фото пользователя.

    photo_mode:
        'all' — альбом из всех фото (максимум 10, ограничение Telegram);
        'one' — только первая фотография объявления.
    Если фото нет (или не спарсились) — отправляет текстовое сообщение.
    """
    caption = build_caption(item)
    images = item["images"][:MAX_PHOTOS_PER_ALBUM]
    # Сохраняем объявление: по row_id работает кнопка «В избранное»
    row_id = await db.upsert_item(
        item["item_url"], item["title"], item["price"], images[0] if images else None
    )
    markup = build_item_keyboard(row_id, item["item_url"], in_favorites=False)
    actions_text = (
        f"💬 <b>{escape(' '.join(item['title'].split())[:120])}</b> — "
        f"{escape(item['price'])}"
    )
    try:
        if photo_mode == "one":
            if images:
                # Одиночное фото — кнопки крепятся прямо к нему
                await bot.send_photo(
                    chat_id=chat_id, photo=images[0], caption=caption,
                    reply_markup=markup,
                )
            else:
                await bot.send_message(chat_id, caption, reply_markup=markup)
        elif images:
            album = MediaGroupBuilder(caption=caption)
            for image_url in images:
                album.add_photo(image_url)
            # У альбомов Bot API не позволяет задать кнопки — отправляем
            # их отдельным сообщением сразу под альбомом
            await bot.send_media_group(chat_id=chat_id, media=album.build())
            await bot.send_message(chat_id, actions_text, reply_markup=markup)
        else:
            await bot.send_message(chat_id, caption, reply_markup=markup)
        return True
    except TelegramForbiddenError:
        # Пользователь заблокировал бота — деактивируем, чтобы не слать в пустоту
        logger.warning("Пользователь {} заблокировал бота", chat_id)
        await db.deactivate_user(chat_id)
    except Exception:
        # Например, битые ссылки на фото у Telegram — логируем и не падаем
        logger.exception(
            "Не удалось отправить объявление {} пользователю {}",
            item["item_url"],
            chat_id,
        )
    return False


async def process_query(
    bot: Bot,
    db: Database,
    parser: AvitoParser,
    query_id: int,
    user_id: int,
    search_url: str,
) -> None:
    """Мониторинг одной ссылки: сбор объявлений и рассылка новых пользователю."""
    items = await parser.fetch_search_items(search_url, limit=MAX_ITEMS_PER_QUERY)
    if not items:
        return

    seen = await db.get_seen_urls(query_id)
    fresh = [item for item in items if item.item_url not in seen]

    if not fresh:
        logger.info("По запросу #{} новых объявлений нет", query_id)
        return

    # Первый проход по новому запросу: только фиксируем текущую выдачу,
    # чтобы не заваливать пользователя уже существующими объявлениями.
    # Поведение можно изменить через SEND_BASELINE=1 в .env.
    if not seen and not SEND_BASELINE:
        for item in fresh:
            await db.mark_seen(query_id, item.item_url)
        logger.info(
            "Запрос #{}: зафиксирована базовая выдача ({} шт.)",
            query_id,
            len(fresh),
        )
        return

    logger.info("Запрос #{}: {} новых объявлений", query_id, len(fresh))
    # Режим фото может поменяться в любой момент — читаем один раз за проход
    photo_mode = await db.get_photo_mode(user_id)

    # Дотягиваем детали (описание, полную галерею) параллельно,
    # но не более PARSE_CONCURRENCY одновременных запросов к Авито
    semaphore = asyncio.Semaphore(PARSE_CONCURRENCY)

    async def enrich(item: AvitoItem) -> AvitoItem:
        if not FETCH_DETAILS:
            return item
        async with semaphore:
            detail = await parser.fetch_item_detail(item.item_url)
        return detail or item  # нет деталей — шлём то, что есть из выдачи

    tasks = [asyncio.create_task(enrich(item)) for item in fresh]
    for done in asyncio.as_completed(tasks):
        item = await done
        payload = item.to_dict()
        if await send_item(bot, db, user_id, payload, photo_mode):
            # Пауза, чтобы не упереться в лимиты Telegram на media group
            await asyncio.sleep(random.uniform(0.8, 2.0))
        await db.mark_seen(query_id, item.item_url)


# Штрафной режим: пока действует пауза после блокировок Авито, циклы пропускаются
_block_skip_until: datetime | None = None
_block_streak = 0
_night_paused = False  # для однократного лога и сброса штрафов утром


def _is_night(hour: int, start: int, end: int) -> bool:
    """True, если час попадает в окно паузы. Поддерживает окно через полночь."""
    if start == end:
        return False
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end


async def run_cycle(bot: Bot, db: Database, parser: AvitoParser) -> None:
    """Один проход мониторинга: проверяет все сохранённые запросы по очереди."""
    global _block_skip_until, _block_streak, _night_paused

    # Ночная пауза: ночью Авито не проверяем (главный признак бота —
    # активность в 5 утра). Лог пишем один раз за ночь, а не каждую минуту.
    if NIGHT_MODE and _is_night(
        datetime.now().hour, NIGHT_MODE_START, NIGHT_MODE_END
    ):
        if not _night_paused:
            logger.info(
                "Ночная пауза: Авито не проверяю с {:02d}:00 до {:02d}:00",
                NIGHT_MODE_START,
                NIGHT_MODE_END,
            )
            _night_paused = True
        return
    if _night_paused:
        # Ночь прошла — долгая тишина могла снять блокировку, штрафы обнуляем
        _night_paused = False
        _block_streak = 0
        _block_skip_until = None
        logger.info("Ночная пауза закончена — возобновляю мониторинг")

    if _block_skip_until is not None and datetime.now() < _block_skip_until:
        logger.debug(
            "Авито блокирует запросы — пропуск цикла до {}",
            _block_skip_until.strftime("%H:%M"),
        )
        return

    logger.info("Запуск цикла мониторинга")
    queries = await db.get_all_queries()
    if not queries:
        logger.info("Активных запросов нет — пропуск цикла")
        return

    # Проверка подписки: если включена — пропускаем запросы пользователей
    # без активной подписки (администратору подписка не нужна)
    if SUBSCRIPTION_REQUIRED:
        checked = []
        for query_id, user_id, url in queries:
            if user_id != ADMIN_ID and not await db.has_active_subscription(user_id):
                logger.info(
                    "Запрос #{} пропущен: у пользователя {} нет подписки",
                    query_id,
                    user_id,
                )
                continue
            checked.append((query_id, user_id, url))
        queries = checked
        if not queries:
            logger.info("Все запросы без подписки — пропуск цикла")
            return

    for query_id, user_id, url in queries:
        try:
            await process_query(bot, db, parser, query_id, user_id, url)
        except Exception:
            # Ошибка одного запроса не должна останавливать остальные
            logger.exception("Ошибка обработки запроса #{}", query_id)

        if parser.blocked:
            # Дальше идти бессмысленно: пока IP не сменится, каждый лишний
            # заход только продлевает блокировку
            break
        # Пауза между запросами — бережём IP от блокировки
        await asyncio.sleep(random.uniform(2, 4))

    if parser.blocked:
        # Нарастающий штраф: 2, 4, 8, 16, 30 минут. Потолок снижен до
        # получаса: ротация IP часто снимает бан уже к следующему циклу,
        # и держать долгую паузу означало бы терять алерты зря.
        _block_streak += 1
        penalty_minutes = min(30, 2**_block_streak)
        _block_skip_until = datetime.now() + timedelta(minutes=penalty_minutes)
        logger.warning(
            "Авито блокирует запросы — пауза мониторинга {} мин. "
            "(серия блокировок подряд: {}, ротаций IP: {})",
            penalty_minutes,
            _block_streak,
            parser._pool.rotations,
        )
    else:
        # Успешный цикл сбрасывает штраф
        _block_streak = 0
        _block_skip_until = None


async def monitoring_loop(bot: Bot, db: Database, parser: AvitoParser) -> None:
    """Бесконечный цикл: ровно один проход в POLL_INTERVAL_SECONDS секунд.

    Отсчёт идёт от начала предыдущего прохода (компенсация дрейфа), поэтому
    частота обращений к Авито не зависит от длительности обработки.
    """
    logger.info(
        "Мониторинг запущен: один проход каждые {} с "
        "(жёсткий интервал, без джиттера по расписанию)",
        int(POLL_INTERVAL_SECONDS),
    )
    while True:
        started = asyncio.get_running_loop().time()
        try:
            await run_cycle(bot, db, parser)
        except asyncio.CancelledError:
            raise  # завершение по сигналу — пробрасываем, не глушим
        except Exception:
            # Любая ошибка цикла не должна убивать мониторинг
            logger.exception("Необработанная ошибка цикла мониторинга")

        # Спим остаток интервала: отсчёт от НАЧАЛА прохода, а не от конца,
        # поэтому задержка обработки не накапливается и период остаётся
        # ровно POLL_INTERVAL_SECONDS.
        elapsed = asyncio.get_running_loop().time() - started
        delay = POLL_INTERVAL_SECONDS - elapsed
        if delay < MIN_CYCLE_GAP:
            # Проход длился дольше интервала — берём минимальную паузу,
            # иначе цикл завертится без остановки
            logger.warning(
                "Цикл занял {:.1f} с — больше интервала {} с, "
                "пауза сокращена до {} с",
                elapsed,
                POLL_INTERVAL_SECONDS,
                MIN_CYCLE_GAP,
            )
            delay = MIN_CYCLE_GAP
        logger.debug("Цикл занял {:.1f} с, следующий через {:.1f} с", elapsed, delay)
        await asyncio.sleep(delay)


async def telegram_health_watcher(bot: Bot) -> None:
    """Следит за связью с Telegram: прокси умер — сам находит рабочий.

    Публичные SOCKS5 живут часы, поэтому периодически щупаем соединение
    коротким запросом и при сбое подбираем новый канал (см. bot.py).
    """
    while True:
        await asyncio.sleep(120)
        try:
            await asyncio.wait_for(bot.get_me(), timeout=25)
        except Exception:
            logger.warning("Связь с Telegram потеряна — подбираю обходной канал")
            try:
                await resolve_working_session(bot)
            except Exception:
                logger.exception("Ошибка восстановления связи с Telegram")


async def main() -> None:
    """Инициализация БД, парсера и запуск long polling."""
    if not BOT_TOKEN or BOT_TOKEN == "your_token_here":
        logger.error("BOT_TOKEN не задан. Получите токен у @BotFather и заполните .env")
        return

    bot = create_bot(BOT_TOKEN)
    dp = create_dispatcher()

    db = Database(DB_PATH)
    await db.connect()
    dp["db"] = db  # DI: хендлеры получат объект БД как параметр `db`

    parser = AvitoParser(
        proxies=PROXY_URLS,
        rotation_url=PROXY_ROTATION_URL,
        impersonate=IMPERSONATE,
        timeout=REQUEST_TIMEOUT,
        attempts=RETRY_ATTEMPTS,
        base_delay=RETRY_BASE_DELAY,
        warmup_ttl=WARMUP_TTL_SECONDS,
        jitter=(JITTER_MIN, JITTER_MAX),
        sightseeing_chance=SIGHTSEEING_CHANCE,
    )
    await parser.start()

    # Прогрев сессии до старта мониторинга: получаем куку антифрода и
    # проходим TLS-рукопожатие. Провал НЕ считается фатальным — парсер
    # прогреется сам перед первым поиском, здесь это просто экономия
    # времени на первом цикле.
    try:
        await parser.warmup()
    except Exception:
        logger.warning("Прогрев сессии при старте не удался — повторим в цикле")

    logger.info(
        "Бот запущен (проверка каждые {} мин., отпечаток TLS: {})",
        CHECK_INTERVAL_MINUTES,
        IMPERSONATE,
    )

    monitor = asyncio.create_task(monitoring_loop(bot, db, parser))
    watcher = asyncio.create_task(telegram_health_watcher(bot))

    try:
        # До старта polling гарантируем живой канал (прокси мог умереть,
        # пока бот был выключен) — иначе polling упадёт на первом запросе
        while not await resolve_working_session(bot):
            logger.warning("Живой канал связи с Telegram не найден, повтор через 60 c")
            await asyncio.sleep(60)

        # Самовосстанавливающийся polling: сетевой сбой не должен валить
        # процесс — лечим связь и запускаем опрос заново
        while True:
            try:
                await dp.start_polling(bot)
                break  # штатное завершение (Ctrl+C / закрытие окна)
            except TelegramNetworkError:
                logger.warning("Polling упал из-за сети — лечу связь и рестартую")
                await asyncio.sleep(15)
                await resolve_working_session(bot)
    finally:
        # Graceful shutdown: останавливаем фоновые задачи и закрываем ресурсы
        for task in (monitor, watcher):
            task.cancel()
        await asyncio.gather(monitor, watcher, return_exceptions=True)
        await parser.stop()
        await db.close()
        await bot.session.close()
        logger.info("Бот остановлен")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Остановлено пользователем (Ctrl+C)")
