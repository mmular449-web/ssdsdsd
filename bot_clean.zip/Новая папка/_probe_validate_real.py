"""Валидация нового парсера на РЕАЛЬНОЙ странице выдачи (офлайн, по файлу)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from parser import AvitoParser  # noqa: E402

HTML = Path("_search_real.html").read_text(encoding="utf-8")
HOST = "https://m.avito.ru"


def main() -> int:
    failed = 0

    def check(name: str, ok: bool, detail: str = "") -> None:
        nonlocal failed
        if not ok:
            failed += 1
        print(f"  {'✓' if ok else '✗'} {name}" + (f" — {detail}" if detail and not ok else ""))

    print("=== 1. Потоковый JSON каталога")
    cat = AvitoParser._extract_catalog_json(HTML)
    check("каталог найден", bool(cat), f"получено {len(cat) if cat else 0}")
    check("объявлений больше 20", bool(cat) and len(cat) > 20,
          f"{len(cat) if cat else 0}")

    print("\n=== 2. Маркеры вёрстки (страховка)")
    marks = AvitoParser._items_from_markers(HTML, HOST)
    check("маркеры найдены", len(marks) > 20, f"{len(marks)}")
    check("маркеров не меньше, чем в JSON",
          bool(cat) and len(marks) >= len(cat), f"{len(marks)} vs {len(cat) if cat else 0}")

    print("\n=== 3. Сводный источник + нормализация")
    raw = AvitoParser._items_from_html(HTML, HOST)
    items = AvitoParser._normalize_many(raw, limit=50, host=HOST)
    check("объявления нормализованы", len(items) > 20, f"{len(items)}")

    with_title = sum(1 for i in items if i.title)
    with_price = sum(1 for i in items if i.price_value)
    with_img = sum(1 for i in items if i.images)
    with_url = sum(1 for i in items if i.item_url.startswith("https://"))
    with_loc = sum(1 for i in items if i.location)
    # Мобильный CDN (*.img.avito.st) не несёт размер в URL — максимальный
    # размер выбирается ключом словаря в JSON (_largest_size_url уже выбрал
    # 636x636). Для десктопного CDN (images.avito.ru) проверяем 1280x960.
    import re as _re
    mobile_cdn = _re.compile(r"https?://\d+\.img\.avito\.st/")
    big_img = sum(
        1 for i in items
        if i.images and (
            mobile_cdn.match(i.images[0])  # мобильный CDN — уже максимум
            or "1280x960" in i.images[0]    # десктопный — проверяем размер
        )
    )
    no_query = sum(1 for i in items if "?context=" not in i.item_url)

    n = len(items)
    print(f"\n  качество по {n} объявлениям:")
    for label, cnt in (("заголовок", with_title), ("цена", with_price),
                       ("фото", with_img), ("ссылка", with_url),
                       ("город", with_loc), ("фото макс. размера", big_img),
                       ("ссылка без ?context", no_query)):
        print(f"    {label}: {cnt}/{n}")

    check("у всех есть заголовок", with_title == n, f"{with_title}/{n}")
    check("у всех есть цена", with_price == n, f"{with_price}/{n}")
    check("у всех есть фото", with_img == n, f"{with_img}/{n}")
    check("у всех есть ссылка", with_url == n, f"{with_url}/{n}")
    check("город извлекается", with_loc > 0, f"{with_loc}/{n}")
    check("фото максимального размера", big_img > 0, f"{big_img}/{n}")
    check("ссылка без мусорного ?context", no_query == n, f"{no_query}/{n}")

    ids = [i.item_id for i in items]
    check("id уникальны", len(set(ids)) == len(ids),
          f"{len(set(ids))} из {len(ids)}")

    print("\n=== 4. Примеры")
    for it in items[:3]:
        print(f"  • {it.title[:55]}")
        print(f"    цена: {it.price} | город: {it.location!r} | дата: {it.published_at!r}")
        print(f"    фото: {(it.images[0][:78] if it.images else 'нет')}")
        print(f"    ссылка: {it.item_url}")
        d = it.to_dict()
        assert {"title", "price", "item_url", "images"} <= set(d)
    check("to_dict() отдаёт контракт бота", True)

    print(f"\nИтого: {'ВСЁ ПРОЙДЕНО' if not failed else f'провалов: {failed}'}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
