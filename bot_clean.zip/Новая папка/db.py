"""Модуль работы с базой данных (aiosqlite).

Три таблицы:
    users      — пользователи бота (Telegram ID + признак активности);
    queries    — поисковые запросы (ссылки на выдачу Авито), принадлежат пользователю;
    seen_items — уже отправленные объявления, чтобы не дублировать их в чат.
"""

from datetime import datetime, timedelta
from typing import Optional

import aiosqlite
from loguru import logger

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY,              -- Telegram user id
    active     INTEGER NOT NULL DEFAULT 1,       -- 1 = активен, 0 = заблокировал бота
    photo_mode TEXT    NOT NULL DEFAULT 'all'    -- 'all' = альбом фото, 'one' = первая фотка
);

CREATE TABLE IF NOT EXISTS queries (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    url        TEXT    NOT NULL,       -- ссылка на страницу поиска Авито
    created_at TEXT    NOT NULL,       -- дата добавления (ISO-формат)
    UNIQUE (user_id, url)              -- одна и та же ссылка не добавляется дважды
);

CREATE TABLE IF NOT EXISTS seen_items (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    item_url TEXT    NOT NULL,         -- ссылка на конкретное объявление
    query_id INTEGER NOT NULL REFERENCES queries(id) ON DELETE CASCADE,
    UNIQUE (item_url, query_id)
);

CREATE TABLE IF NOT EXISTS items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    url     TEXT NOT NULL UNIQUE,      -- ссылка на объявление
    title   TEXT NOT NULL,             -- название
    price   TEXT NOT NULL,             -- цена (текстом)
    image   TEXT                       -- первая фотография (для карточек избранного)
);

CREATE TABLE IF NOT EXISTS favorites (
    user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_id  INTEGER NOT NULL REFERENCES items(item_id) ON DELETE CASCADE,
    added_at TEXT    NOT NULL,
    UNIQUE (user_id, item_id)
);
"""


class Database:
    """Асинхронная обёртка над aiosqlite.

    Использование:
        db = Database("avito_bot.db")
        await db.connect()
        ...
        await db.close()
    """

    def __init__(self, path: str):
        self._path = path
        self._conn: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        """Открывает соединение и создаёт таблицы, если их ещё нет."""
        self._conn = await aiosqlite.connect(self._path)
        # Без этой прагмы внешние ключи (ON DELETE CASCADE) работать не будут
        await self._conn.execute("PRAGMA foreign_keys = ON")
        await self._conn.executescript(SCHEMA)
        # Мягкая миграция: в базе, созданной старой версией, нет колонки photo_mode
        cursor = await self._conn.execute("PRAGMA table_info(users)")
        columns = {row[1] for row in await cursor.fetchall()}
        if "photo_mode" not in columns:
            await self._conn.execute(
                "ALTER TABLE users ADD COLUMN photo_mode TEXT NOT NULL DEFAULT 'all'"
            )
        # И колонки подписки (subscribed_until, ISO-дата окончания)
        if "subscribed_until" not in columns:
            await self._conn.execute(
                "ALTER TABLE users ADD COLUMN subscribed_until TEXT"
            )
        await self._conn.commit()
        logger.info("База данных готова: {}", self._path)

    async def close(self) -> None:
        """Аккуратно закрывает соединение."""
        if self._conn:
            await self._conn.close()
            self._conn = None
            logger.info("Соединение с БД закрыто")

    # ----------------------------- users -----------------------------

    async def add_user(self, user_id: int, active: bool = True) -> None:
        """Добавляет пользователя или обновляет его статус активности."""
        await self._conn.execute(
            "INSERT INTO users (id, active) VALUES (?, ?) "
            "ON CONFLICT(id) DO UPDATE SET active = excluded.active",
            (user_id, int(active)),
        )
        await self._conn.commit()

    async def deactivate_user(self, user_id: int) -> None:
        """Помечает пользователя неактивным (например, он заблокировал бота)."""
        await self._conn.execute("UPDATE users SET active = 0 WHERE id = ?", (user_id,))
        await self._conn.commit()

    async def get_photo_mode(self, user_id: int) -> str:
        """Текущий режим фото пользователя: 'all' (альбом) или 'one' (первая)."""
        cursor = await self._conn.execute(
            "SELECT photo_mode FROM users WHERE id = ?", (user_id,)
        )
        row = await cursor.fetchone()
        return row[0] if row else "all"

    async def set_photo_mode(self, user_id: int, mode: str) -> None:
        """Сохраняет режим фото ('all' | 'one')."""
        await self._conn.execute(
            "UPDATE users SET photo_mode = ? WHERE id = ?", (mode, user_id)
        )
        await self._conn.commit()

    # --------------------------- подписка ---------------------------

    async def user_exists(self, user_id: int) -> bool:
        cursor = await self._conn.execute(
            "SELECT 1 FROM users WHERE id = ?", (user_id,)
        )
        return await cursor.fetchone() is not None

    async def get_subscription(self, user_id: int) -> Optional[str]:
        """Дата окончания подписки (ISO) или None."""
        cursor = await self._conn.execute(
            "SELECT subscribed_until FROM users WHERE id = ?", (user_id,)
        )
        row = await cursor.fetchone()
        return row[0] if row else None

    async def has_active_subscription(self, user_id: int) -> bool:
        until = await self.get_subscription(user_id)
        return (
            until is not None
            and until >= datetime.now().isoformat(timespec="seconds")
        )

    async def extend_subscription(self, user_id: int, days: int) -> str:
        """Продлевает подписку на N дней (от текущего конца или от сейчас).

        Возвращает новую дату окончания в ISO-формате.
        """
        now = datetime.now()
        current = await self.get_subscription(user_id)
        base = (
            datetime.fromisoformat(current)
            if current and current > now.isoformat(timespec="seconds")
            else now
        )
        new_until = (base + timedelta(days=days)).isoformat(timespec="seconds")
        await self._conn.execute(
            "UPDATE users SET subscribed_until = ? WHERE id = ?", (new_until, user_id)
        )
        await self._conn.commit()
        return new_until

    # ---------------------------- queries -----------------------------

    async def add_query(self, user_id: int, url: str) -> Optional[int]:
        """Добавляет ссылку на поиск.

        Возвращает id новой записи или None, если такая ссылка
        у этого пользователя уже отслеживается.
        """
        cursor = await self._conn.execute(
            "INSERT OR IGNORE INTO queries (user_id, url, created_at) VALUES (?, ?, ?)",
            (user_id, url, datetime.now().isoformat(timespec="seconds")),
        )
        await self._conn.commit()
        if cursor.rowcount == 0:  # INSERT OR IGNORE пропустил дубликат
            return None
        return cursor.lastrowid

    async def get_all_queries(self) -> list[tuple[int, int, str]]:
        """Все запросы активных пользователей для мониторинга.

        Возвращает список кортежей (query_id, user_id, url).
        """
        cursor = await self._conn.execute(
            "SELECT q.id, q.user_id, q.url FROM queries q "
            "JOIN users u ON u.id = q.user_id WHERE u.active = 1"
        )
        return [(row[0], row[1], row[2]) for row in await cursor.fetchall()]

    async def get_user_queries(self, user_id: int) -> list[tuple[int, str, str]]:
        """Запросы конкретного пользователя: [(query_id, url, created_at), ...]."""
        cursor = await self._conn.execute(
            "SELECT id, url, created_at FROM queries WHERE user_id = ? ORDER BY id",
            (user_id,),
        )
        return [(row[0], row[1], row[2]) for row in await cursor.fetchall()]

    async def delete_query(self, user_id: int, query_id: int) -> bool:
        """Удаляет запрос (вместе с seen_items каскадом).

        Удаляет только если запрос принадлежит этому пользователю.
        """
        cursor = await self._conn.execute(
            "DELETE FROM queries WHERE id = ? AND user_id = ?", (query_id, user_id)
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    # --------------------------- seen_items ---------------------------

    async def get_seen_urls(self, query_id: int) -> set[str]:
        """Множество ссылок, уже отправленных по данному запросу."""
        cursor = await self._conn.execute(
            "SELECT item_url FROM seen_items WHERE query_id = ?", (query_id,)
        )
        return {row[0] for row in await cursor.fetchall()}

    async def mark_seen(self, query_id: int, item_url: str) -> None:
        """Помечает объявление как уже отправленное (защита от дублей)."""
        await self._conn.execute(
            "INSERT OR IGNORE INTO seen_items (item_url, query_id) VALUES (?, ?)",
            (item_url, query_id),
        )
        await self._conn.commit()

    # ------------------ items / favorites (избранное) ------------------

    async def upsert_item(
        self, url: str, title: str, price: str, image: Optional[str]
    ) -> int:
        """Сохраняет объявление (обновляя данные) и возвращает его item_id."""
        await self._conn.execute(
            "INSERT INTO items (url, title, price, image) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(url) DO UPDATE SET title=excluded.title, "
            "price=excluded.price, image=excluded.image",
            (url, title, price, image),
        )
        cursor = await self._conn.execute(
            "SELECT item_id FROM items WHERE url = ?", (url,)
        )
        row = await cursor.fetchone()
        await self._conn.commit()
        return row[0]

    async def get_item(self, item_id: int) -> Optional[tuple]:
        """(item_id, url, title, price, image) по id — для callback-кнопок."""
        cursor = await self._conn.execute(
            "SELECT item_id, url, title, price, image FROM items WHERE item_id = ?",
            (item_id,),
        )
        return await cursor.fetchone()

    async def toggle_favorite(self, user_id: int, item_id: int) -> bool:
        """Ставит/снимает избранное. Возвращает True, если добавлено."""
        cursor = await self._conn.execute(
            "DELETE FROM favorites WHERE user_id = ? AND item_id = ?",
            (user_id, item_id),
        )
        if cursor.rowcount:
            await self._conn.commit()
            return False
        await self._conn.execute(
            "INSERT OR IGNORE INTO favorites (user_id, item_id, added_at) "
            "VALUES (?, ?, ?)",
            (user_id, item_id, datetime.now().isoformat(timespec="seconds")),
        )
        await self._conn.commit()
        return True

    async def remove_favorite(self, user_id: int, item_id: int) -> bool:
        """Точечно убирает из избранного (в отличие от toggle — не добавит)."""
        cursor = await self._conn.execute(
            "DELETE FROM favorites WHERE user_id = ? AND item_id = ?",
            (user_id, item_id),
        )
        await self._conn.commit()
        return cursor.rowcount > 0

    async def get_favorites(self, user_id: int, limit: int = 10) -> list[tuple]:
        """Последние избранное: [(item_id, url, title, price, image, added_at), ...]."""
        cursor = await self._conn.execute(
            "SELECT i.item_id, i.url, i.title, i.price, i.image, f.added_at "
            "FROM favorites f JOIN items i ON i.item_id = f.item_id "
            "WHERE f.user_id = ? ORDER BY f.added_at DESC LIMIT ?",
            (user_id, limit),
        )
        return list(await cursor.fetchall())
