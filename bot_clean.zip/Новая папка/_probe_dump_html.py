"""Снимает реальный HTML поисковой выдачи после прогрева и разбирает его.

Прогрев обязателен: без него выдача не отдаётся. Сохраняем HTML в файл и
печатаем структуру — какие маркеры есть, сколько ссылок на карточки,
где лежит стейт.
"""

from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path

import parser as avito_parser
from parser import AvitoParser, ITEM_LINK_RE

OUT = Path("_search_dump.html")


async def fetch_html(url: str) -> str:
    # IP жёстко троттлится (429), поэтому: сначала остываем, потом
    # долбимся терпеливо и по-человечески. Задача — добыть HTML, а не
    # уложиться в секунду.
    import random
    print("Остываем перед серией запросов...")
    await asyncio.sleep(random.uniform(35, 50))

    parser = AvitoParser(attempts=6, base_delay=8.0, max_delay=25.0,
                         jitter=(1.0, 3.0), sightseeing_chance=0.0)
    try:
        if not await parser.warmup():
            print("ПРОГРЕВ НЕ УДАЛСЯ")
            return ""
        await parser._human_pause(1.5, 4.0)
        session = parser._session()
        response = await session.get(
            url, headers=parser._nav_headers(referer=parser._referer))
        print(f"HTTP {response.status_code}, {len(response.text)} байт")
        return response.text or ""
    finally:
        await parser.stop()


def analyze(html: str) -> None:
    print("\n=== Разбор структуры выдачи")
    print(f"длина HTML: {len(html)} байт")
    print(f"заголовок: {re.search(r'<title>(.*?)</title>', html, re.S).group(1)[:100] if re.search(r'<title>(.*?)</title>', html, re.S) else 'нет'}")

    markers = [
        "__initialState__", "initial-state", "__NEXT_DATA__", "__NUXT__",
        "application/ld+json", "data-marker=\"item\"", "data-marker",
        "iva-item", "item-card", "items-catalog", "catalog-items",
        "Доступ ограничен", "captcha", "h-captcha", "js-catalog",
        "window.__", "data-item-id", "js-item", "b-item",
    ]
    print("\n--- маркеры:")
    for m in markers:
        count = html.count(m)
        if count:
            print(f"    {m}: {count}")

    print("\n--- ссылки на карточки (по ITEM_LINK_RE):")
    hrefs = re.findall(r'href="([^"]+)"', html)
    matched = [h for h in hrefs if ITEM_LINK_RE.match(h.split("?")[0])]
    print(f"    всего href: {len(hrefs)}, похожих на карточку: {len(matched)}")
    for h in matched[:8]:
        print(f"      {h}")

    print("\n--- встроенные <script> (первые 12, длина >200):")
    scripts = re.findall(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>",
                         html, re.S)
    big = [s for s in scripts if len(s) > 200]
    print(f"    встроенных скриптов: {len(scripts)}, из них >200 симв.: {len(big)}")
    for s in big[:12]:
        print(f"      [{len(s)}] {re.sub(r'\s+', ' ', s)[:160]}")

    print("\n--- JSON-LD блоки:")
    for block in re.findall(
            r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>',
            html, re.S)[:3]:
        print(f"      [{len(block)}] {re.sub(r'\s+', ' ', block)[:200]}")


async def main() -> None:
    html = await fetch_html("https://m.avito.ru/moskva/odezhda?q=hollister")
    if not html:
        return
    OUT.write_text(html, encoding="utf-8")
    print(f"\nHTML сохранён: {OUT.resolve()}")
    analyze(html)


if __name__ == "__main__":
    asyncio.run(main())
