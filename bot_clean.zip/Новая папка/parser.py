"""Парсер Авито: мобильная поисковая выдача + обязательный прогрев сессии.

Архитектура (почему именно так — проверено замерами, не чтением кода)
--------------------------------------------------------------------
1. **Отказ от внутренних API.** Старые вызовы `/api/{v}/items` и
   `/api/1/locations` удалены: замерено 2026-09-03, что WAF Авито
   (``server: QRATOR``) режет их на сетевом уровне —
   ``/api/30/items`` и ``/api/29/items`` → **HTTP 403** с заголовком
   «Доступ ограничен», ``/api/1/locations`` → **404** от nginx.
   Единственный рабочий источник — публичная поисковая выдача
   мобильной версии ``https://m.avito.ru/...`` со встроенным
   JSON-стейтом и микроразметкой.

2. **Обязательный warm-up.** Прогрев — не декоративная пауза, а
   необходимый шаг получения куки WAF. Замерено: при прямом заходе на
   выдачу сессия содержит ``_adcc, _avisc, srv_id``; если предварительно
   сделать GET ``https://m.avito.ru/`` — в сессии появляется кука
   антифрода (в этом прогоне — ``gMltIuegZN2COuSe``, имя генерируется
   сервером и каждый раз новое). Имя куки нельзя хардкодить — поэтому
   прогрев считается успешным по факту получения ЛЮБОЙ куки, а не по
   конкретному имени.

3. **Одна сессия на всю цепочку.** Используется один persistent-объект
   ``curl_cffi.AsyncSession(impersonate="chrome120")`` (асинхронный
   аналог ``requests.Session`` — проект целиком на asyncio). Куки,
   User-Agent, Sec-Ch-Ua и Referer накапливаются и передаются
   последовательно: прогрев → (возможный заход в категорию) → выдача →
   карточка. Замерено на локальном echo-сервере: куки реально едут во
   втором и последующих запросах, заголовки сессии не задваиваются с
   отпечатком impersonate (User-Agent уходит ровно один раз), порядок
   заголовков совпадает с браузерным.

4. **Блокировка — это состояние, а не исключение.** Qrator отдаёт
   страницу с заголовком «Доступ ограничен: проблема с IP» + hCaptcha.
   Такой ответ классифицируется, поднимает флаг `blocked`, крутит
   прокси и уходит в экспоненциальную паузу. Наружу парсер НИКОГДА не
   бросает исключение из-за блокировки: вызывающий код получает пустой
   список.

   ВАЖНО: блокировка стоит на edge ДО прикладной логики, поэтому
   подмена TLS-отпечатка против заблокированного IP бессильна. Без
   PROXY_URL парсер предупреждает и всё равно пытается, но шансов нет.

Схема обхода блокировок
-----------------------
    прогрев ──► 200 + куки ──► пауза с джиттером ──► выдача ──► 200 ──► результат
       │                                                │
       └─► 403/429/503 или капча                        └─► капча/пусто
              └─► ротация IP + экспоненциальная пауза        └─► десктоп-фолбэк
                     └─► сброс сессии и ПОВТОРНЫЙ прогрев

Каскад источников данных (каждая ступень страхует предыдущую)
------------------------------------------------------------
    1. mobile_html   — GET https://m.avito.ru/<путь>?<параметры>
                       из HTML: встроенный JSON-стейт → разбор DOM → JSON-LD
    2. desktop_html  — GET https://www.avito.ru/<путь>?<параметры>
                       тот же разбор + микроразметка schema.org

Авито регулярно меняет вёрстку, поэтому извлечение сделано
ТРЁХУРОВНЕВЫМ: JSON-стейт → DOM (data-marker/href) → JSON-LD. Плюс
универсальный обход JSON-дерева (`_walk_items`) как последняя страховка.

Точки обслуживания при поломке: константы MOBILE_HOST / ITEM_LINK_RE /
BLOCK_MARKERS / SESSION_IDENTITIES и функции _extract_* / _items_from_dom.
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from dataclasses import dataclass, field
from html import unescape
from typing import Any, Optional
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

from curl_cffi import AsyncSession, CurlError
from loguru import logger

# ============================== константы ==============================

MOBILE_HOST = "https://m.avito.ru"
DESKTOP_HOST = "https://www.avito.ru"

# Отпечаток TLS. "chrome120" запрошен явно; "chrome131_android" даёт
# полностью мобильный отпечаток (и TLS, и заголовки).
DEFAULT_IMPERSONATE = "chrome120"

# Ссылка на объявление: /<город>[/<категория>...]/<слаг>_<числовой id>
ITEM_LINK_RE = re.compile(r"^/(?:ru/)?[a-z0-9\-]+/.+_(\d{6,})$", re.IGNORECASE)

# Сегмент размера картинки в URL CDN Авито. Внимание: хост во
# множественном числе (images.avito.ru), а путь — в единственном
# (…/image/640x480/…), поэтому "images?" с необязательной s.
# Размер выделен группой: при подстановке форма пути сохраняется как есть,
# чтобы не сломать URL на CDN, где используется другой вариант.
IMAGE_SIZE_RE = re.compile(r"/images?/(\d{2,4}x\d{2,4})/")

# Ключи, под которыми Авито кладёт изображения
IMAGE_CONTAINER_KEYS = ("images", "imageUrls", "gallery", "photos", "pictures")

# Ключи цены
PRICE_KEYS = ("price", "priceDetailed", "formattedPrice", "priceString", "cost")

# Ключи описания
DESCRIPTION_KEYS = ("description", "text", "descriptionText")

# HTTP-статусы, которые означают блокировку или ограничение
BLOCK_STATUSES = frozenset({403, 429, 503})

# Маркеры страницы блокировки в теле ответа.
# «проблема с IP» — дословный заголовок страницы Qrator: это жёсткий бан
# по IP, капчу решать бессмысленно, нужен новый выходной адрес.
BLOCK_MARKERS = (
    "доступ ограничен",
    "проверка безопасности",
    "captcha",
    "не робот",
    "firewall",
    "access denied",
    "are you a robot",
)

# Маркеры именно капчи (hCaptcha Авито) — отличаем от «тихого» 429
CAPTCHA_MARKERS = (
    "h-captcha",
    "hcaptcha",
    "sethcaptcharesponse",
    "js-form-captcha",
    "my_canvas",
)

# Маркеры жёсткого бана по IP (заголовок страницы Qrator)
HARD_BAN_MARKERS = (
    "проблема с ip",
    "problem with ip",
    "доступ ограничен: проблема",
)

# Шаблоны встроенного JSON-стейта в HTML
STATE_PATTERNS = (
    r'<script[^>]+id="initial-state"[^>]*>(.*?)</script>',
    r"window\.__initialState__\s*=\s*(\{.*?\});?\s*</script>",
    r"window\.__APP_INITIAL_STATE__\s*=\s*(\{.*?\});?\s*</script>",
    r"window\.__NEXT_DATA__\s*=\s*(\{.*?\});?\s*</script>",
    r'<script[^>]+type="application/json"[^>]*>(\{.*?\})</script>',
)

JSON_LD_RE = re.compile(
    r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>',
    re.IGNORECASE | re.DOTALL,
)

# Любой встроенный (без src) <script> — запасной источник стейта
INLINE_SCRIPT_RE = re.compile(
    r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>",
    re.IGNORECASE | re.DOTALL,
)

# --------------------------- разбор DOM (фолбэк) ---------------------------
# Если встроенного JSON-стейта нет (Авито меняет вёрстку), вытаскиваем
# объявления прямо из разметки: ссылка на карточку + цена/заголовок рядом.

# Ссылка на карточку: href="/moskva/odezhda/kurtka_hollister_3987654321"
ITEM_HREF_RE = re.compile(
    r'<a\b[^>]*href="(?P<href>[^"]*?_(?P<id>\d{6,}))"[^>]*>(?P<inner>.*?)</a>',
    re.IGNORECASE | re.DOTALL,
)

# Цена в микроразметке: itemprop="price" content="2500"
PRICE_CONTENT_RE = re.compile(
    r'itemprop="price"[^>]*content="\s*(?P<v>\d+)', re.IGNORECASE
)

# Цена текстом: «2 500 ₽» (неразрывные пробелы — обычное дело в вёрстке)
PRICE_TEXT_RE = re.compile(
    r"(?P<v>\d[\d\s\xa0\u202f]{0,14})\s*(?:₽|руб|RUB)", re.IGNORECASE
)

# Первая картинка внутри блока карточки
IMG_SRC_RE = re.compile(
    r'(?:data-src|data-original|src)="(?P<src>[^"]+)"', re.IGNORECASE
)

# Заголовок: либо itemprop="name", либо атрибут title
TITLE_ATTR_RE = re.compile(
    r'(?:itemprop="name"[^>]*>|alt="|title=")(?P<t>[^"<]{3,200})', re.IGNORECASE
)

TAG_RE = re.compile(r"<[^>]+>")

# --------------------- разметка живой выдачи (замерено) ---------------------
# Структура снята с реальной страницы m.avito.ru (2026-09-03):
#   <div data-marker="item" data-item-id="8320321365" id="i8320321365">
#     <a data-marker="item-photo-sliderLink" href="/moskva/.../slug_8320321365?context=...">
#       <img src="https://90.img.avito.st/image/1/1.RpFw-...">
#     <a data-marker="item-title" href="...">Женская куртка Hollister</a>
#     <p data-marker="item-price"><meta itemProp="price" content="1911">
#        <span data-marker="item-price-value">1 911<!-- --> ₽</span></p>
#     <p data-marker="item-date">3 дня назад</p>
#   </div>
#
# Токен разделителя — с закрывающей кавычкой. Он НЕ является префиксом
# data-marker="item-title", поэтому split по нему безопасен.
ITEM_MARKER = 'data-marker="item"'

RE_ITEM_ID = re.compile(r'data-item-id="(?P<id>\d+)"')
RE_ITEM_HREF = re.compile(r'href="(?P<href>[^"]*?_\d{6,}[^"]*)"')
RE_ITEM_TITLE = re.compile(
    r'data-marker="item-title"[^>]*>(?P<t>.*?)</a>', re.IGNORECASE | re.DOTALL
)
# В вёрстке атрибуты пишутся как itemProp (camelCase), поэтому без учета регистра
RE_PRICE_META = re.compile(r'itemprop="price"\s+content="(?P<v>\d+)"', re.IGNORECASE)
RE_PRICE_VALUE = re.compile(
    r'data-marker="item-price-value"[^>]*>(?P<t>.*?)</span>',
    re.IGNORECASE | re.DOTALL,
)
RE_ITEM_DATE = re.compile(
    r'data-marker="item-date"[^>]*>(?P<t>.*?)</p>', re.IGNORECASE | re.DOTALL
)
# Фото лежит прямо в маркере слайдера — это надёжнее, чем первый попавшийся img
RE_ITEM_IMG = re.compile(r'data-marker="slider-image/image-(?P<src>https?://[^"]+)"')
RE_ANY_IMG = re.compile(r'<img[^>]+src="(?P<src>https?://[^"]+)"')

# Ключи размеров в JSON: {"208x208": url, "636x636": url, ...}
RE_SIZE_KEY = re.compile(r"^(?P<w>\d{2,4})x(?P<h>\d{2,4})$")

# ------------------------------ прогрев сессии ------------------------------

# Сколько живёт прогретая сессия. Куки Авито долгоживущие, но «личность»
# полезно освежать: слишком старая сессия сама по себе выглядит подозрительно.
WARMUP_TTL_SECONDS = 900.0

# Сколько раз пытаться прогреться, прежде чем признать IP мёртвым
WARMUP_ATTEMPTS = 3

# После провала прогрева не дёргаем Авито чаще раза в это время, секунд.
# Иначе каждый цикл мониторинга (60 с) тратил бы ~20 с на безнадёжные
# ретраи против заведомо заблокированного IP.
WARMUP_RETRY_COOLDOWN = 120.0

# --------------------------- поведение «как человек» ---------------------------

# Обычная пауза между запросами цепочки, секунды
JITTER_MIN = 1.2
JITTER_MAX = 3.4

# Вероятность «задуматься»: редкая длинная пауза поверх обычной
LONG_PAUSE_CHANCE = 0.15
LONG_PAUSE_MIN = 4.0
LONG_PAUSE_MAX = 9.0

# Вероятность промежуточного перехода (главная → категория → выдача).
# Реальный пользователь почти никогда не прыгает с главной сразу на
# отфильтрованный поиск — это и есть главный признак бота.
SIGHTSEEING_CHANCE = 0.35

# Бюджет узлов на обход JSON-дерева (защита от огромных стейтов)
MAX_WALK_NODES = 25_000

# Заголовки «как у браузера» для навигационных GET-запросов.
# Кладём на СЕССИЮ один раз: замерено, что они не задваиваются с
# отпечатком impersonate (User-Agent уходит ровно один раз) и
# сохраняются во всех последующих запросах цепочки.
BASE_NAV_HEADERS: dict[str, str] = {
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,image/apng,*/*;q=0.8,"
        "application/signed-exchange;v=b3;q=0.7"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    "Upgrade-Insecure-Requests": "1",
}

# Идентичность браузера под конкретный профиль impersonate. User-Agent и
# Sec-Ch-Ua обязаны совпадать с TLS-отпечатком: расхождение (например,
# Windows-UA при мобильном TLS) — мгновенный признак подделки.
SESSION_IDENTITIES: dict[str, dict[str, str]] = {
    "chrome120": {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        ),
        "Sec-Ch-Ua": (
            '"Chromium";v="120", "Not(A:Brand";v="24", "Google Chrome";v="120"'
        ),
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
    },
    "chrome131_android": {
        "User-Agent": (
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        ),
        "Sec-Ch-Ua": (
            '"Chromium";v="131", "Not(A:Brand";v="24", "Google Chrome";v="131"'
        ),
        "Sec-Ch-Ua-Mobile": "?1",
        "Sec-Ch-Ua-Platform": '"Android"',
    },
}

# Резервная идентичность, если профиль не знаком
FALLBACK_IDENTITY: dict[str, str] = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Sec-Ch-Ua": (
        '"Chromium";v="120", "Not(A:Brand";v="24", "Google Chrome";v="120"'
    ),
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
}


# ============================== исключения ==============================

class AvitoError(Exception):
    """Базовая ошибка парсера."""


class AvitoBlocked(AvitoError):
    """Авито заблокировал запрос (403/429/503/капча) — нужен новый IP."""


class AvitoNoData(AvitoError):
    """Ответ получен, но объявлений в нём нет (выдача пуста или вёрстка новая)."""


class AvitoNotWarmed(AvitoError):
    """Прогрев не удался — сессия без куки WAF, поиск начнётся с 403."""


# ============================== пул прокси ==============================

class ProxyPool:
    """Пул мобильных прокси с авторизацией и ротацией внешнего IP.

    Поддерживаются два механизма смены IP:
      * переключение на следующий прокси из списка (round-robin);
      * GET по ссылке ротации ПРОВАЙДЕРА ЧЕРЕЗ САМ ПРОКСИ — так работают
        мобильные прокси: адрес шлюза не меняется, меняется выходной IP.

    Если заданы оба механизма, сначала пробуется ссылка ротации (она
    дешевле: не рвёт сессию и не тратит второй прокси), затем —
    переключение на следующий адрес.
    """

    def __init__(
        self,
        proxies: Optional[list[str]] = None,
        rotation_url: str = "",
        rotation_cooldown: float = 10.0,
        timeout: float = 20.0,
    ) -> None:
        self._proxies: list[str] = [p.strip() for p in (proxies or []) if p.strip()]
        self._index = 0
        self._rotation_url = rotation_url.strip()
        self._rotation_cooldown = rotation_cooldown
        self._timeout = timeout
        self._last_rotation_at = 0.0
        self.rotations = 0

    def __len__(self) -> int:
        return len(self._proxies)

    @property
    def current(self) -> Optional[str]:
        """Текущий прокси или None, если трафик идёт напрямую."""
        return self._proxies[self._index] if self._proxies else None

    @property
    def has_rotation_url(self) -> bool:
        return bool(self._rotation_url)

    def switch_next(self) -> Optional[str]:
        """Переключается на следующий прокси в списке (round-robin)."""
        if not self._proxies:
            return None
        self._index = (self._index + 1) % len(self._proxies)
        self.rotations += 1
        logger.info("Прокси переключён: {}", self._mask(self.current))
        return self.current

    async def rotate_ip(self) -> bool:
        """Меняет внешний IP. Возвращает True, если что-то изменилось."""
        if self._rotation_url:
            if await self._rotate_via_url():
                return True
        if len(self._proxies) > 1:
            return self.switch_next() is not None
        return False

    async def _rotate_via_url(self) -> bool:
        """GET по ссылке ротации через текущий прокси."""
        # Провайдеры штрафуют за слишком частую ротацию — держим паузу
        since = asyncio.get_running_loop().time() - self._last_rotation_at
        if since < self._rotation_cooldown:
            wait = self._rotation_cooldown - since
            logger.debug("Ротация IP слишком частая, ждём {:.1f} с", wait)
            await asyncio.sleep(wait)

        try:
            async with AsyncSession(
                impersonate=DEFAULT_IMPERSONATE,
                timeout=self._timeout,
                proxy=self.current,
            ) as session:
                response = await session.get(self._rotation_url)
                self._last_rotation_at = asyncio.get_running_loop().time()
                self.rotations += 1
                logger.info(
                    "Ротация IP по ссылке провайдера: HTTP {} — {}",
                    response.status_code,
                    response.text.strip()[:80],
                )
                return response.status_code < 500
        except CurlError as exc:
            logger.warning("Ссылка ротации IP недоступна: {}", exc)
            return False
        except Exception:
            logger.exception("Неожиданная ошибка ротации IP")
            return False

    @staticmethod
    def _mask(proxy: Optional[str]) -> str:
        """Прокси без пароля — чтобы секреты не утекали в логи."""
        if not proxy:
            return "без прокси"
        parts = urlsplit(proxy)
        if parts.username or parts.password:
            host = parts.hostname or ""
            port = f":{parts.port}" if parts.port else ""
            return f"{parts.scheme}://***:***@{host}{port}"
        return proxy


# ============================ нормализация ============================

@dataclass
class Budget:
    """Счётчик узлов для обхода JSON-дерева."""

    limit: int = MAX_WALK_NODES
    used: int = 0

    def spend(self) -> bool:
        """Тратит один узел; False — бюджет исчерпан."""
        self.used += 1
        return self.used <= self.limit


def _as_int(value: Any) -> Optional[int]:
    """Безопасное приведение к int (цены, id)."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        digits = re.sub(r"[^\d]", "", value)
        return int(digits) if digits else None
    return None


# Мобильный CDN Авито: хост вида NN.img.avito.st, размер НЕ в URL,
# а выбирается ключом из словаря в JSON (максимальный — 636x636).
# Старый десктопный CDN: images.avito.ru/image/640x480/... — размер в URL,
# и его можно заменить на 1280x960.
MOBILE_CDN_RE = re.compile(r"https?://\d+\.img\.avito\.st/", re.IGNORECASE)


def _upgrade_image(url: str) -> str:
    """Приводит картинку к максимальному размеру и абсолютному URL.

    Два формата CDN Авито:
      * Десктопный (images.avito.ru/image/640x480/...): размер в URL,
        заменяем на 1280x960.
      * Мобильный (NN.img.avito.st/image/1/...): размер НЕ в URL — он
        выбирается ключом словаря в JSON. ``_largest_size_url`` уже выбрал
        максимум (636x636), URL не нуждается в модификации.
    """
    url = url.strip()
    if url.startswith("//"):
        url = "https:" + url
    elif url.startswith("/"):
        url = urljoin(MOBILE_HOST, url)
    # Мобильный CDN: размер не в URL — ничего не подменяем
    if MOBILE_CDN_RE.match(url):
        return url
    # Десктопный CDN: меняем размер, форму сегмента сохраняем
    return IMAGE_SIZE_RE.sub(lambda m: m.group(0).replace(m.group(1), "1280x960"), url)


def _fill_template(url: str, entry: dict) -> str:
    """Подставляет значения в шаблон вида .../image/{imageId}_{width}x{height}.jpg."""
    if "{" not in url:
        return url
    replacements = {
        "{imageId}": str(entry.get("id") or entry.get("imageId") or ""),
        "{width}": "1280",
        "{height}": "960",
    }
    for token, value in replacements.items():
        url = url.replace(token, value)
    return url


def _strip_tags(text: str) -> str:
    """Текст без тегов и HTML-комментариев.

    Комментарии обязательно убирать: в живой вёрстке цена приходит как
    «1 911<!-- --> ₽», и без этого цена рвётся на части.
    """
    text = re.sub(r"<!--.*?-->", "", text, flags=re.DOTALL)
    return " ".join(unescape(TAG_RE.sub(" ", text)).split())


def _largest_size_url(entry: dict) -> Optional[str]:
    """URL самого большого размера из словаря вида {"208x208": ..., "636x636": ...}.

    Живой Авито кладёт фото именно так — списком размеров, а не по ключу
    "url", поэтому старый разбор по именованным ключам их промахивался.
    """
    best_url: Optional[str] = None
    best_area = -1
    for key, value in entry.items():
        if not isinstance(value, str) or not value.strip():
            continue
        match = RE_SIZE_KEY.match(str(key))
        if not match:
            continue
        area = int(match.group("w")) * int(match.group("h"))
        if area > best_area:
            best_area, best_url = area, value
    return best_url


def _extract_images(raw: Any) -> list[str]:
    """Собирает все фото объявления, без дублей, в максимальном размере.

    Авито кладёт картинки по-разному: списком строк, списком словарей
    с ключами url/src/image, либо вложенным объектом галереи.
    """
    if raw is None:
        return []
    if isinstance(raw, str):
        return [_upgrade_image(raw)] if raw.strip() else []

    candidates: list[Any] = []
    if isinstance(raw, list):
        candidates = raw
    elif isinstance(raw, dict):
        for key in IMAGE_CONTAINER_KEYS:
            value = raw.get(key)
            if isinstance(value, list):
                candidates = value
                break
        else:
            candidates = [raw]

    images: list[str] = []
    seen: set[str] = set()
    for entry in candidates:
        url: Optional[str] = None
        if isinstance(entry, str):
            url = entry
        elif isinstance(entry, dict):
            # Сначала словарь размеров ({"636x636": url}) — так реально
            # отдаёт живой Авито, и это даёт максимальное разрешение.
            url = _largest_size_url(entry)
            if not url:
                for key in ("url", "src", "image", "original", "640x480",
                            "1280x960"):
                    value = entry.get(key)
                    if isinstance(value, str) and value.strip():
                        url = _fill_template(value, entry)
                        break
        if not url or "{" in url:
            continue  # шаблон, который не удалось раскрыть — Telegram не примет
        url = _upgrade_image(url)
        if url not in seen:
            seen.add(url)
            images.append(url)
    return images


def _extract_price(raw: dict) -> tuple[str, Optional[int]]:
    """Достаёт цену: (текст для подписи, число для сортировки/фильтров)."""
    detailed = raw.get("priceDetailed")
    if isinstance(detailed, dict):
        value = _as_int(detailed.get("value") or detailed.get("amount"))
        # fullString — «1 911 ₽» со знаком валюты, string — просто «1 911».
        # Для подписи в Telegram нужен полный вариант.
        text = (
            detailed.get("fullString")
            or detailed.get("string")
            or detailed.get("text")
        )
        if isinstance(text, str) and text.strip():
            return " ".join(text.split()), value
        if value is not None:
            currency = detailed.get("currency") or ""
            symbol = "₽" if str(currency).upper() in ("RUR", "RUB", "₽", "") else ""
            return f"{value:,} {symbol}".replace(",", " ").strip(), value

    for key in PRICE_KEYS:
        if key == "priceDetailed":
            continue
        value = raw.get(key)
        if isinstance(value, (str, int, float)) and str(value).strip():
            text = " ".join(str(value).split())
            if text.lower() in ("0", "цена не указана", "не указана"):
                continue
            return text, _as_int(value)

    nested = raw.get("priceInfo") or raw.get("prices")
    if isinstance(nested, dict):
        return _extract_price(nested)
    return "Цена не указана", None


def _extract_description(raw: dict) -> str:
    """Описание объявления (в выдаче мобильной версии лежит в details)."""
    for key in DESCRIPTION_KEYS:
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            text = unescape(value)
            text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
            text = re.sub(r"<[^>]+>", "", text)
            return " ".join(text.split())
    return ""


def _extract_location(raw: dict) -> str:
    """Город/адрес объявления.

    В живой выдаче поле `location` приходит null, зато город есть в alt
    галереи в формате «Название товара, Город» — отсюда и достаём.
    """
    location = raw.get("location")
    if isinstance(location, dict):
        name = location.get("name") or location.get("title") or location.get("city")
        if isinstance(name, str) and name.strip():
            return name.strip()
    if isinstance(location, str) and location.strip():
        return location.strip()

    detailed = raw.get("addressDetailed")
    if isinstance(detailed, dict):
        name = detailed.get("locationName")
        if isinstance(name, str) and name.strip():
            return name.strip()

    for key in ("address", "city", "region"):
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    gallery = raw.get("gallery")
    if isinstance(gallery, dict):
        alt = gallery.get("imageAlt")
        # «Женская куртка Hollister, Москва» → «Москва»
        if isinstance(alt, str) and "," in alt:
            tail = alt.rsplit(",", 1)[-1].strip()
            if 0 < len(tail) <= 60:
                return tail
    return ""


def _extract_seller(raw: dict) -> str:
    """Имя продавца."""
    for key in ("seller", "contacts", "user"):
        value = raw.get(key)
        if isinstance(value, dict):
            name = value.get("name") or value.get("title")
            if isinstance(name, str) and name.strip():
                return name.strip()
    return ""


def _looks_like_item(node: dict) -> bool:
    """Похож ли узел JSON-дерева на объявление."""
    if not isinstance(node, dict) or "id" not in node:
        return False
    title = node.get("title") or node.get("name") or node.get("subject")
    if not isinstance(title, str) or not title.strip():
        return False
    price_hints = ("price", "priceDetailed", "formattedPrice", "priceString", "cost")
    other_hints = ("images", "imageUrls", "urlPath", "url", "categoryId", "location")
    return any(k in node for k in price_hints) and any(
        k in node for k in other_hints
    )


def _walk_items(node: Any, budget: Optional[Budget] = None) -> list[dict]:
    """Универсальный поиск объявлений в произвольном JSON-дереве.

    Спасает, когда Авито сменил формат встроенного стейта: ищем объекты,
    у которых есть id + название + цена, не завязываясь на путь в JSON.
    """
    budget = budget or Budget()
    found: list[dict] = []

    if isinstance(node, dict):
        if _looks_like_item(node):
            return [node]  # глубже не идём: там дубли и мусор
        for value in node.values():
            if not budget.spend():
                return found
            found.extend(_walk_items(value, budget))
    elif isinstance(node, list):
        for value in node:
            if not budget.spend():
                return found
            found.extend(_walk_items(value, budget))
    return found


@dataclass
class AvitoItem:
    """Нормализованное объявление — контракт между парсером и ботом."""

    item_id: str
    title: str
    price: str
    price_value: Optional[int]
    item_url: str
    images: list[str] = field(default_factory=list)
    description: str = ""
    location: str = ""
    seller: str = ""
    published_at: str = ""
    raw: dict = field(default_factory=dict, repr=False)

    def to_dict(self) -> dict:
        return {
            "item_id": self.item_id,
            "title": self.title,
            "price": self.price,
            "price_value": self.price_value,
            "item_url": self.item_url,
            "images": self.images,
            "description": self.description,
            "location": self.location,
            "seller": self.seller,
            "published_at": self.published_at,
        }


def _normalize_item(raw: dict, host: str = DESKTOP_HOST) -> Optional[AvitoItem]:
    """Приводит сырой словарь Авито к AvitoItem. None — если это не объявление."""
    item_id = raw.get("id")
    item_id = str(item_id) if item_id is not None else ""
    if not item_id:
        return None

    title = raw.get("title") or raw.get("name") or raw.get("subject") or ""
    title = " ".join(unescape(str(title)).split())
    if not title:
        return None

    # Ссылка: в JSON-стейте это urlPath (/moskva/.../slug_id),
    # в DOM-разборе — готовый url.
    url_path = raw.get("urlPath") or raw.get("url") or raw.get("uri") or ""
    if isinstance(url_path, str) and url_path.strip():
        item_url = (
            url_path if url_path.startswith("http") else urljoin(host, url_path)
        )
        # Ссылки приходят с мусорным хвостом (?context=H4sIAA...&slocation=...).
        # Он уникален на каждый проход и ломает дедупликацию, поэтому
        # срезаем query: каноническая ссылка на объявление без него работает.
        parts = urlsplit(item_url)
        if parts.query:
            item_url = urlunsplit(
                (parts.scheme, parts.netloc, parts.path, "", "")
            )
    else:
        item_url = f"{host}/item/{item_id}"

    price, price_value = _extract_price(raw)
    images = _extract_images(raw)

    return AvitoItem(
        item_id=item_id,
        title=title,
        price=price,
        price_value=price_value,
        item_url=item_url,
        images=images,
        description=_extract_description(raw),
        location=_extract_location(raw),
        seller=_extract_seller(raw),
        published_at=str(raw.get("time") or raw.get("date") or ""),
        raw=raw,
    )


# ============================== сам парсер ==============================

class AvitoParser:
    """Асинхронный парсер мобильной выдачи Авито на curl_cffi.

    Использование:
        parser = AvitoParser(proxies=["http://user:pass@ip:port"],
                             rotation_url="https://provider/rotate")
        async with parser:
            await parser.warmup()   # прогрев можно сделать заранее, один раз
            items = await parser.fetch_search_items(
                "https://www.avito.ru/moskva?q=hollister")

    Прогрев обязателен и вызывается автоматически перед первым поиском:
    если `warm` не поднят, `fetch_search_items` прогреет сессию сам.

    Состояние `blocked` выставляется в True, если последний заход уткнулся
    в блокировку, — main.py по нему уходит в штрафную паузу.
    """

    def __init__(
        self,
        proxies: Optional[list[str]] = None,
        rotation_url: str = "",
        impersonate: str = DEFAULT_IMPERSONATE,
        timeout: float = 30.0,
        attempts: int = 4,
        base_delay: float = 5.0,
        max_delay: float = 60.0,
        warmup_ttl: float = WARMUP_TTL_SECONDS,
        jitter: tuple[float, float] = (JITTER_MIN, JITTER_MAX),
        sightseeing_chance: float = SIGHTSEEING_CHANCE,
    ) -> None:
        self._impersonate = impersonate
        self._timeout = timeout
        self._attempts = max(1, attempts)
        self._base_delay = base_delay
        self._max_delay = max_delay
        self._warmup_ttl = warmup_ttl
        self._jitter = jitter
        self._sightseeing_chance = sightseeing_chance

        self._pool = ProxyPool(proxies, rotation_url, timeout=timeout)
        # ОДИН persistent-объект сессии на прокси: куки и заголовки живут
        # во всей цепочке (прогрев → категория → выдача → карточка).
        # Сессия одна на прокси, а не глобально: у разных выходных IP не
        # должно быть общей «личности» и общих куки.
        self._sessions: dict[Optional[str], AsyncSession] = {}

        # Состояние прогрева
        self._warm = False          # сессия прогрета и получила куки WAF
        self._warm_at = 0.0         # когда прогрели (для TTL)
        self._warm_failed_at = 0.0  # когда прогрев провалился (для кулдауна)
        self._referer: Optional[str] = None  # цепочка переходов браузера
        self.warmups = 0            # счётчик прогревов (для диагностики)

        self.blocked = False   # True, если упёрлись в бан/капчу
        self.block_streak = 0  # сколько блокировок подряд

        if not self._pool.current and not self._pool.has_rotation_url:
            logger.warning(
                "PROXY_URL не задан: трафик пойдёт напрямую. Если IP уже "
                "заблокирован Авито, ни TLS-отпечаток, ни прогрев не помогут "
                "— укажите прокси в .env"
            )

    # --------------------------- жизненный цикл ---------------------------

    async def start(self) -> None:
        """Проверяет доступность отпечатка и печатает конфигурацию."""
        logger.info(
            "Парсер готов: impersonate={}, прокси={}, ссылка ротации={}",
            self._impersonate,
            len(self._pool) or "нет",
            "есть" if self._pool.has_rotation_url else "нет",
        )

    async def stop(self) -> None:
        """Закрывает все открытые сессии."""
        for proxy, session in list(self._sessions.items()):
            try:
                await session.close()
            except Exception:
                pass
            self._sessions.pop(proxy, None)
        self._warm = False
        self._referer = None

    async def __aenter__(self) -> "AvitoParser":
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.stop()

    # ------------------------- низкоуровневый слой -------------------------

    def _identity(self) -> dict[str, str]:
        """User-Agent и Sec-Ch-Ua строго под выбранный TLS-отпечаток.

        Расхождение идентичности с отпечатком (например, десктопный UA при
        мобильном TLS) — мгновенный признак подделки, поэтому профили
        заданы парой, а не по отдельности.
        """
        return SESSION_IDENTITIES.get(self._impersonate, FALLBACK_IDENTITY)

    def _session(self) -> AsyncSession:
        """Persistent-сессия для текущего прокси.

        Создаётся один раз, переиспользуется всей цепочкой запросов.
        Заголовки (UA, Sec-Ch-Ua, Accept-Language) вешаются на САМУ
        СЕССИЮ, а не на отдельный запрос: замерено, что они при этом не
        задваиваются с отпечатком impersonate и сохраняются в каждом
        последующем запросе.
        """
        proxy = self._pool.current
        session = self._sessions.get(proxy)
        if session is None:
            session = AsyncSession(
                impersonate=self._impersonate,
                timeout=self._timeout,
                proxy=proxy,
            )
            # Идентичность + базовые навигационные заголовки — один раз,
            # дальше они едут сами на каждом запросе этой сессии
            session.headers.update(self._identity())
            session.headers.update(BASE_NAV_HEADERS)
            self._sessions[proxy] = session
            logger.debug(
                "Создана сессия: impersonate={}, прокси={}",
                self._impersonate,
                ProxyPool._mask(proxy),
            )
        return session

    async def _drop_session(self) -> None:
        """Закрывает сессию текущего прокси.

        Вызывается после ротации IP: новый выходной адрес — новая
        «личность», старые куки WAF к нему не привязаны.
        """
        proxy = self._pool.current
        session = self._sessions.pop(proxy, None)
        if session is not None:
            try:
                await session.close()
            except Exception:
                pass
        self._invalidate_warm()

    def _invalidate_warm(self) -> None:
        """Сбрасывает состояние прогрева — сессия больше не валидна."""
        self._warm = False
        self._warm_at = 0.0
        self._referer = None

    def _nav_headers(
        self,
        *,
        referer: Optional[str] = None,
        dest: str = "document",
        mode: str = "navigate",
        site: str = "same-origin",
        user: Optional[str] = "?1",
    ) -> dict[str, str]:
        """Заголовки навигации под конкретный переход.

        Referer выставляется вручную: libcurl его не проставляет сам, и
        без него цепочка «главная → выдача» выглядит как набор
        несвязанных запросов.
        """
        headers: dict[str, str] = {
            "Sec-Fetch-Dest": dest,
            "Sec-Fetch-Mode": mode,
            "Sec-Fetch-Site": site,
        }
        if user is not None:
            headers["Sec-Fetch-User"] = user
        if referer:
            headers["Referer"] = referer
        return headers

    # ---------------------- имитация поведения человека ----------------------

    async def _human_pause(
        self,
        minimum: Optional[float] = None,
        maximum: Optional[float] = None,
    ) -> float:
        """Случайная пауза между запросами. Возвращает фактическую длину.

        Ровные интервалы — главный признак бота: реальный пользователь
        «думает» неравномерно. Поверх обычной паузы иногда добавляется
        длинная (LONG_PAUSE_CHANCE) — imitation of "отвлёкся".
        """
        low = self._jitter[0] if minimum is None else minimum
        high = self._jitter[1] if maximum is None else maximum
        delay = random.uniform(low, high)
        if random.random() < LONG_PAUSE_CHANCE:
            delay += random.uniform(LONG_PAUSE_MIN, LONG_PAUSE_MAX)
        logger.debug("Пауза «как человек»: {:.1f} с", delay)
        await asyncio.sleep(delay)
        return delay

    # ----------------------------- детектор банa -----------------------------

    @staticmethod
    def _is_blocked(status: int, body: str) -> bool:
        """Похоже ли это на блокировку/капчу."""
        if status in BLOCK_STATUSES:
            return True
        if status >= 400:
            return False
        head = body[:20000].lower()
        return any(marker in head for marker in BLOCK_MARKERS)

    @staticmethod
    def _classify_block(status: int, body: str) -> Optional[str]:
        """Чем именно заблокирован запрос: 'captcha' / 'ban' / 'rate' / 'http'.

        Нужно только для диагностики: «ban» означает, что капчу решать
        бессмысленно и поможет лишь новый IP, а «rate» — что стоит
        просто замедлиться.

        Порядок проверок важен: маркеры в теле точнее кода ответа, потому
        что Qrator отдаёт страницу бана с HTTP 200 в части сценариев.
        """
        head = (body or "")[:20000].lower()
        if any(m in head for m in HARD_BAN_MARKERS):
            return "ban"
        if any(m in head for m in CAPTCHA_MARKERS):
            return "captcha"
        if status == 429:
            return "rate"
        if status >= 400:
            return "http"
        if any(m in head for m in BLOCK_MARKERS):
            return "captcha"
        return None

    async def _sleep_backoff(self, attempt: int) -> None:
        """Экспоненциальная пауза с джиттером (не бьём ровно по секундам)."""
        delay = min(self._max_delay, self._base_delay * (2**attempt))
        delay += random.uniform(0, self._base_delay)
        logger.info("Пауза перед повтором: {:.1f} с", delay)
        await asyncio.sleep(delay)

    async def _request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[dict] = None,
        json_body: Optional[dict] = None,
        headers: Optional[dict] = None,
        allow_statuses: tuple[int, ...] = (200,),
        attempts: Optional[int] = None,
    ) -> Optional[str]:
        """Один запрос с ретраями и ротацией IP при блокировке.

        Низкоуровневый слой: прогрев здесь НЕ делается — он управляется
        отдельно (`_ensure_warm_session`), чтобы этот метод оставался
        пригодным и для служебных одиночных запросов.

        `attempts` переопределяет число попыток для вспомогательных
        запросов: там цена ошибки низкая, и тратить на неё полный бюджет
        ретраев незачем.

        Возвращает тело ответа или None, если все попытки провалились.
        """
        last_error = ""
        total_attempts = max(1, attempts or self._attempts)

        for attempt in range(total_attempts):
            session = self._session()
            try:
                response = await session.request(
                    method,
                    url,
                    params=params,
                    json=json_body,
                    headers=headers,
                    timeout=self._timeout,
                )
            except CurlError as exc:
                last_error = f"сеть/прокси: {exc}"
                logger.warning(
                    "Попытка {}/{}: {} не отвечает ({})",
                    attempt + 1,
                    total_attempts,
                    url,
                    last_error,
                )
                await self._handle_block(attempt, total_attempts)
                continue
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                logger.warning(
                    "Попытка {}/{}: непредвиденная ошибка {} — {}",
                    attempt + 1,
                    total_attempts,
                    url,
                    last_error,
                )
                await self._handle_block(attempt, total_attempts)
                continue

            body = response.text or ""

            if response.status_code in allow_statuses and not self._is_blocked(
                response.status_code, body
            ):
                # Успех — сбрасываем серию блокировок
                self.blocked = False
                self.block_streak = 0
                return body

            if self._is_blocked(response.status_code, body):
                kind = self._classify_block(response.status_code, body)
                last_error = f"блокировка/{kind} (HTTP {response.status_code})"
                logger.warning(
                    "Попытка {}/{}: Авито вернул {} [{}] для {}",
                    attempt + 1,
                    total_attempts,
                    response.status_code,
                    kind,
                    url,
                )
                await self._handle_block(attempt, total_attempts)
                continue

            if response.status_code == 404:
                logger.debug("404 для {} — страница не существует", url)
                return None

            last_error = f"HTTP {response.status_code}"
            logger.warning("Попытка {}/{}: {} — {}", attempt + 1,
                           total_attempts, url, last_error)
            if attempt + 1 < total_attempts:
                await self._sleep_backoff(attempt)

        logger.error("Запрос {} провален после {} попыток: {}",
                     url, total_attempts, last_error)
        return None

    async def _handle_block(self, attempt: int, total_attempts: int) -> None:
        """Реакция на блокировку: ротация IP + пауза. Обновляет счётчики."""
        self.blocked = True
        self.block_streak += 1

        rotated = await self._pool.rotate_ip()
        if rotated:
            # Новый IP — старые куки к нему не привязаны: сессию и прогрев
            # сбрасываем, чтобы следующий заход начался с чистого warm-up.
            await self._drop_session()

        if attempt + 1 < total_attempts:
            await self._sleep_backoff(attempt)

    # ------------------------------- прогрев -------------------------------

    def _warm_expired(self) -> bool:
        """Пора ли перепрогревать сессию."""
        if not self._warm:
            return True
        if self._warm_at <= 0:
            return True
        return (time.monotonic() - self._warm_at) > self._warmup_ttl

    async def warmup(self, force: bool = False) -> bool:
        """Прогрев сессии: GET на главную мобильной версии.

        Зачем: именно этот запрос выдаёт куку антифрода WAF (Qrator).
        Замерено — при заходе сразу на выдачу такой куки в сессии нет,
        а после GET «/» она появляется. Имя куки каждый раз новое,
        поэтому успех проверяется по факту получения ЛЮБЫХ куки, а не по
        конкретному имени.

        Возвращает True, если сессия прогрета (или уже была прогрета и
        ещё жива). Наружу исключения не бросает: при неудаче просто
        возвращает False и поднимает флаг `blocked`.
        """
        if not force and not self._warm_expired():
            return True

        # Прогрев только что провалился — не долбим Авито по новой:
        # на заблокированном IP это заведомо пустой расход времени.
        if not force and self._warm_failed_at:
            since = time.monotonic() - self._warm_failed_at
            if since < WARMUP_RETRY_COOLDOWN:
                logger.debug(
                    "Прогрев недавно провалился — пропускаем ещё {:.0f} с",
                    WARMUP_RETRY_COOLDOWN - since,
                )
                self.blocked = True
                return False

        logger.info("Прогрев сессии: GET {}", MOBILE_HOST + "/")
        for attempt in range(WARMUP_ATTEMPTS):
            session = self._session()
            cookies_before = set(session.cookies.keys())
            try:
                response = await session.get(
                    MOBILE_HOST + "/",
                    headers=self._nav_headers(
                        referer=None,      # вход «из ниоткуда», как новая вкладка
                        dest="document",
                        mode="navigate",
                        site="none",
                        user="?1",
                    ),
                    timeout=self._timeout,
                )
            except CurlError as exc:
                logger.warning("Прогрев {}/{}: сеть/прокси — {}",
                               attempt + 1, WARMUP_ATTEMPTS, exc)
                await self._handle_block(attempt, WARMUP_ATTEMPTS)
                continue
            except Exception as exc:
                logger.warning("Прогрев {}/{}: {} — {}",
                               attempt + 1, WARMUP_ATTEMPTS,
                               type(exc).__name__, exc)
                await self._handle_block(attempt, WARMUP_ATTEMPTS)
                continue

            body = response.text or ""
            if self._is_blocked(response.status_code, body):
                kind = self._classify_block(response.status_code, body)
                logger.warning(
                    "Прогрев {}/{}: HTTP {} [{}] — {}",
                    attempt + 1, WARMUP_ATTEMPTS, response.status_code, kind,
                    "бан по IP: нужен новый прокси" if kind == "ban"
                    else "капча: нужен новый IP или пауза",
                )
                await self._handle_block(attempt, WARMUP_ATTEMPTS)
                continue

            cookies_after = set(session.cookies.keys())
            fresh = cookies_after - cookies_before
            if not cookies_after:
                # Куки не получили — сессия «пустая». Не фатально, но
                # шансы пройти WAF резко падают; пробуем ещё раз.
                logger.warning(
                    "Прогрев {}/{}: HTTP {} без единой куки — сессия пустая",
                    attempt + 1, WARMUP_ATTEMPTS, response.status_code,
                )
                await self._handle_block(attempt, WARMUP_ATTEMPTS)
                continue

            self._warm = True
            self._warm_at = time.monotonic()
            self._warm_failed_at = 0.0
            self._referer = MOBILE_HOST + "/"
            self.warmups += 1
            self.blocked = False
            self.block_streak = 0
            logger.info(
                "Сессия прогрета: HTTP {}, куки ({}){}, новых: {}",
                response.status_code, len(cookies_after),
                "".join(sorted(cookies_after)), ", ".join(sorted(fresh)) or "нет",
            )
            return True

        self._warm_failed_at = time.monotonic()
        logger.error(
            "Прогрев не удался после {} попыток — поиск начнётся с 403. "
            "Повторная попытка через {:.0f} с",
            WARMUP_ATTEMPTS, WARMUP_RETRY_COOLDOWN,
        )
        return False

    async def _ensure_warm_session(self) -> bool:
        """Прогревает сессию, если она не прогрета или протухла.

        Вызывается перед каждым поисковым заходом: прогрев ОБЯЗАТЕЛЕН.
        """
        return await self.warmup()

    async def _maybe_sightseeing(self, path: str, query: list[tuple[str, str]]) -> None:
        """Имитация живого маршрута: иногда заходим в категорию перед поиском.

        Реальный человек с главной почти никогда не прыгает сразу на
        отфильтрованную выдачу — обычно он сначала открывает раздел.
        Прыжок «главная → поиск с фильтрами» и есть главный признак бота.

        Поэтому иногда заходим на тот же путь, но БЕЗ параметров:
        /moskva/odezhda?q=hollister ← предварительно /moskva/odezhda.
        """
        if not query:
            return  # фильтров нет — сам поиск и есть вход в раздел
        if not path or path == "/":
            return
        if random.random() >= self._sightseeing_chance:
            return

        target = MOBILE_HOST + path

        logger.debug("Промежуточный переход (как человек): {}", target)
        referer = self._referer
        try:
            await self._request(
                "GET",
                target,
                headers=self._nav_headers(
                    referer=referer, dest="document", mode="navigate",
                    site="same-origin",
                ),
                attempts=1,
            )
            self._referer = target
        except Exception:
            logger.debug("Промежуточный переход не удался — не критично")
        await self._human_pause(0.6, 2.0)

    # ------------------------- разбор JSON/HTML -------------------------

    @staticmethod
    def _json_from_text(text: str) -> Optional[Any]:
        """Пытается распознать JSON в тексте: целиком или по границам {...}."""
        text = text.strip()
        try:
            return json.loads(text)
        except (json.JSONDecodeError, TypeError):
            pass
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end > start:
            try:
                return json.loads(text[start : end + 1])
            except (json.JSONDecodeError, TypeError):
                return None
        return None

    @classmethod
    def _extract_state_json(cls, html: str) -> Optional[Any]:
        """Вытаскивает встроенный JSON-стейт из HTML.

        Сначала известные имена переменных (быстро и точно), затем —
        перебор всех встроенных <script>: если Авито переименует
        переменную стейта, парсер всё равно найдёт JSON.
        """
        for pattern in STATE_PATTERNS:
            match = re.search(pattern, html, re.DOTALL)
            if not match:
                continue
            data = cls._json_from_text(match.group(1))
            if data is not None:
                return data

        for block in INLINE_SCRIPT_RE.findall(html):
            if len(block) < 40:  # короткие служебные скрипты не интересны
                continue
            data = cls._json_from_text(block)
            if data is not None:
                return data
        return None

    @staticmethod
    def _extract_json_ld(html: str) -> list[dict]:
        """Микроразметка schema.org — надёжный источник полей карточки."""
        blocks: list[dict] = []
        for match in JSON_LD_RE.finditer(html):
            try:
                data = json.loads(match.group(1).strip())
            except json.JSONDecodeError:
                continue
            if isinstance(data, list):
                blocks.extend(d for d in data if isinstance(d, dict))
            elif isinstance(data, dict):
                if "@graph" in data and isinstance(data["@graph"], list):
                    blocks.extend(d for d in data["@graph"] if isinstance(d, dict))
                blocks.append(data)
        return blocks

    @staticmethod
    def _items_from_dom(html: str, host: str) -> list[dict]:
        """Объявления прямо из разметки — если встроенного JSON-стейта нет.

        Опираемся на самое стабильное в вёрстке Авито: ссылку на карточку
        вида /<город>/<категория>/<слаг>_<id>. Всё остальное (цена,
        заголовок, фото) ищем внутри этой ссылки и в окне сразу после неё.
        """
        items: list[dict] = []
        seen: set[str] = set()

        for match in ITEM_HREF_RE.finditer(html):
            href = match.group("href")
            item_id = match.group("id")
            if item_id in seen:
                continue

            # Отсекаем мусор: путь обязан быть похож на карточку
            path = urlsplit(href).path
            if not ITEM_LINK_RE.match(path or ""):
                continue

            inner = match.group("inner")
            # Цена и фото могут лежать и за пределами <a> — берём окно
            tail_start = match.end()
            window = html[tail_start : tail_start + 900]

            # Заголовок: сначала атрибуты, потом текст ссылки без тегов.
            # unescape обязателен: в разметке сплошь и рядом сущности
            # (&amp; &quot; &#8381;), и без раскрытия они ломают и текст,
            # и поиск цены.
            title = ""
            attr = TITLE_ATTR_RE.search(inner)
            if attr:
                title = " ".join(unescape(attr.group("t")).split())
            if not title:
                plain = " ".join(unescape(TAG_RE.sub(" ", inner)).split())
                if 3 <= len(plain) <= 200:
                    title = plain
            if not title:
                continue

            # Цена: микроразметка, иначе первый «число ₽»
            price_value: Optional[int] = None
            price_text = ""
            content = PRICE_CONTENT_RE.search(inner) or PRICE_CONTENT_RE.search(window)
            if content:
                price_value = _as_int(content.group("v"))
                price_text = f"{int(content.group('v')):,} ₽".replace(",", " ")
            if not price_text:
                # Сущности вида &#8381; раскрываем до поиска — иначе знак
                # рубля в тексте просто не находится
                inner_text = unescape(TAG_RE.sub(" ", inner))
                window_text = unescape(TAG_RE.sub(" ", window))
                found = (PRICE_TEXT_RE.search(inner_text)
                         or PRICE_TEXT_RE.search(window_text))
                if found:
                    price_text = " ".join(found.group(0).split())
                    price_value = _as_int(found.group("v"))

            # Фото: первый src внутри карточки
            images: list[str] = []
            src = IMG_SRC_RE.search(inner)
            if src:
                images = _extract_images([src.group("src")])

            item_url = href if href.startswith("http") else urljoin(host, href)
            seen.add(item_id)
            items.append({
                "id": item_id,
                "title": title,
                "price": price_text or None,
                "price_value": price_value,
                "images": images,
                "url": item_url,
            })
        return items

    @classmethod
    def _extract_catalog_json(cls, html: str) -> Optional[list[dict]]:
        """Каталог из потокового JSON-чанка React SSR.

        Живая мобильная выдача не рендерит объявления в HTML — она
        стримит их отдельным <script> с JSON, где лежит
        `loaderData.data.catalog.items` (замерено: 51 объявление на
        странице, с ценой, галереей, geo и продавцом). Это самый полный и
        структурированный источник, поэтому он первый.
        """
        for block in INLINE_SCRIPT_RE.findall(html):
            text = block.strip()
            if not text.startswith("{") or "loaderData" not in text:
                continue
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                continue
            if not isinstance(data, dict):
                continue

            node = (data.get("loaderData") or {}).get("data")
            if not isinstance(node, dict):
                continue

            items = (node.get("catalog") or {}).get("items")
            if isinstance(items, list) and items:
                return [i for i in items if isinstance(i, dict)]

            # Карточка объявления: путь до items может отличаться —
            # ищем структуру, похожую на объявление, обходом дерева.
            found = _walk_items(node)
            if found:
                return found
        return None

    @classmethod
    def _items_from_markers(cls, html: str, host: str) -> list[dict]:
        """Объявления по data-marker блокам живой вёрстки.

        Страхует потоковый JSON: в разметке объявлений больше (замерено
        82 против 51 в JSON — туда попадают и продвигаемые), а сами
        маркеры живут дольше, чем формат встроенного стейта.
        """
        items: list[dict] = []
        seen: set[str] = set()

        for chunk in html.split(ITEM_MARKER)[1:]:
            head = chunk[:600]
            match = RE_ITEM_ID.search(head)
            if not match:
                continue
            item_id = match.group("id")
            if item_id in seen:
                continue

            href = RE_ITEM_HREF.search(chunk)
            if not href:
                continue
            url = urljoin(host, href.group("href"))

            title_match = RE_ITEM_TITLE.search(chunk)
            title = _strip_tags(title_match.group("t")) if title_match else ""
            if not title:
                continue

            price_value: Optional[int] = None
            price_text = ""
            meta = RE_PRICE_META.search(chunk)
            if meta:
                price_value = _as_int(meta.group("v"))
            value = RE_PRICE_VALUE.search(chunk)
            if value:
                price_text = _strip_tags(value.group("t"))
                if price_value is None:
                    price_value = _as_int(price_text)

            image = RE_ITEM_IMG.search(chunk) or RE_ANY_IMG.search(chunk)
            images = _extract_images([image.group("src")]) if image else []

            date_match = RE_ITEM_DATE.search(chunk)
            published = _strip_tags(date_match.group("t")) if date_match else ""

            seen.add(item_id)
            items.append({
                "id": item_id,
                "title": title,
                "price": price_text or None,
                "price_value": price_value,
                "images": images,
                "url": url,
                "time": published,
            })
        return items

    @classmethod
    def _items_from_html(cls, html: str, host: str) -> list[dict]:
        """Объявления из HTML: потоковый JSON → маркеры → стейт → DOM → JSON-LD.

        Пять независимых источников: Авито регулярно меняет и формат
        встроенного стейта, и вёрстку, поэтому каждый следующий уровень
        страхует предыдущий.
        """
        catalog = cls._extract_catalog_json(html)
        if catalog:
            return catalog

        marker_items = cls._items_from_markers(html, host)
        if marker_items:
            return marker_items

        state = cls._extract_state_json(html)
        if state is not None:
            found = _walk_items(state)
            if found:
                return found

        dom_items = cls._items_from_dom(html, host)
        if dom_items:
            return dom_items

        items: list[dict] = []
        for block in cls._extract_json_ld(html):
            block_type = str(block.get("@type") or "")
            if "Product" not in block_type and "Offer" not in block_type:
                continue
            offers = block.get("offers") or {}
            if isinstance(offers, list) and offers:
                offers = offers[0]
            item_id = ""
            url = str(block.get("url") or "")
            match = ITEM_LINK_RE.search(urlsplit(url).path)
            if match:
                item_id = match.group(1)
            items.append(
                {
                    "id": item_id or block.get("sku") or len(items) + 1,
                    "title": block.get("name") or "",
                    "price": (offers or {}).get("price")
                    if isinstance(offers, dict)
                    else None,
                    "description": block.get("description") or "",
                    "images": block.get("image"),
                    "url": url,
                }
            )
        return items

    # --------------------- преобразование ссылки поиска ---------------------

    @staticmethod
    def _split_search_url(search_url: str) -> tuple[str, str, list[tuple[str, str]]]:
        """Разбирает ссылку пользователя на (хост, путь, параметры)."""
        parts = urlsplit(search_url.strip())
        host = f"{parts.scheme or 'https'}://{parts.netloc or 'www.avito.ru'}"
        return host, parts.path or "/", parse_qsl(parts.query, keep_blank_values=True)

    @staticmethod
    def _build_url(host: str, path: str, query: list[tuple[str, str]]) -> str:
        """Собирает URL поиска из частей."""
        scheme, _, netloc = host.partition("://")
        return urlunsplit((scheme or "https", netloc, path, urlencode(query), ""))

    # ---------------------------- публичный API ----------------------------

    async def fetch_search_items(
        self, search_url: str, limit: int = 8
    ) -> list[AvitoItem]:
        """Возвращает до `limit` объявлений из выдачи по ссылке пользователя.

        Цепочка: обязательный прогрев → (возможный заход в категорию) →
        мобильная выдача → при неудаче десктопная. Если источников молчат
        — возвращает пустой список (main.py по нему просто пропустит цикл,
        не падая).
        """
        self.blocked = False
        _, path, query = self._split_search_url(search_url)

        # 1. Прогрев ОБЯЗАТЕЛЕН: без куки WAF поиск упрется в 403 на первом
        #    же запросе, сколько ни подменяй отпечаток.
        if not await self._ensure_warm_session():
            return []  # прогрев не прошёл — IP мёртв, дёргать Авито бессмысленно

        # 2. Имитация живого маршрута (иногда заходим в категорию)
        await self._maybe_sightseeing(path, query)
        if self.blocked:
            return []

        # 3. Мобильная выдача — основной источник
        items = await self._fetch_search_html(MOBILE_HOST, path, query, limit)
        if items:
            return items[:limit]
        if self.blocked:
            return []

        # 4. Десктопная выдача — страховка
        await self._human_pause()
        if self.blocked:
            return []
        items = await self._fetch_search_html(DESKTOP_HOST, path, query, limit)
        return items[:limit]

    async def _fetch_search_html(
        self,
        host: str,
        path: str,
        query: list[tuple[str, str]],
        limit: int,
    ) -> list[AvitoItem]:
        """Выдача из HTML-страницы поиска (мобильной или десктопной)."""
        url = self._build_url(host, path, query)
        referer = self._referer
        try:
            body = await self._request(
                "GET",
                url,
                headers=self._nav_headers(
                    referer=referer,
                    dest="document",
                    mode="navigate",
                    site="same-origin",
                ),
            )
        except Exception as exc:
            # Любая ошибка разбора не должна валить мониторинг
            logger.warning("Ошибка запроса выдачи {}: {}", url, exc)
            return []

        if not body:
            return []

        # Успешный переход — продолжаем цепочку Referer
        self._referer = url

        raw_items = self._items_from_html(body, host)
        if not raw_items:
            logger.warning(
                "{}: объявления не найдены (ни JSON-стейт, ни DOM, ни "
                "микроразметка) — проверить селекторы",
                url,
            )
            return []
        logger.info("{}: {} объявлений из HTML", host, len(raw_items))
        return self._normalize_many(raw_items, limit, host)

    async def fetch_item_detail(self, item_url: str) -> Optional[AvitoItem]:
        """Детальная карточка объявления (описание, полная галерея).

        Только публичные страницы: мобильная карточка, затем десктопная.
        Внутренние API-ручки не используются.
        """
        if not await self._ensure_warm_session():
            return None

        parts = urlsplit(item_url.strip())
        path = parts.path

        for host in (MOBILE_HOST, DESKTOP_HOST):
            url = f"{host}{path}"
            referer = self._referer
            try:
                body = await self._request(
                    "GET",
                    url,
                    headers=self._nav_headers(
                        referer=referer,
                        dest="document",
                        mode="navigate",
                        site="same-origin",
                    ),
                )
            except Exception as exc:
                logger.warning("Ошибка запроса карточки {}: {}", url, exc)
                continue

            if not body:
                if self.blocked:
                    return None
                continue

            self._referer = url

            raw_items = self._items_from_html(body, host)
            for raw in raw_items:
                item = _normalize_item(raw, host)
                if item:
                    return item

            # Карточка отдаёт одно объявление: если разбор по «виду
            # объявления» не сработал, пробуем микроразметку напрямую
            for block in self._extract_json_ld(body):
                item = _normalize_item(block, host)
                if item:
                    return item

            await self._human_pause()
            if self.blocked:
                return None

        logger.debug("Детали по {} не получены", item_url)
        return None

    # ------------------------------ утилиты ------------------------------

    @staticmethod
    def _dig_items(data: Any) -> list[dict]:
        """Достаёт список объявлений из JSON-структуры, независимо от обёртки.

        Известные варианты: {"result": {"items": [...]}}, {"items": [...]},
        {"data": [...]}, просто список. Всё остальное — обход дерева.
        """
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
        if not isinstance(data, dict):
            return []

        for path in (
            ("result", "items"),
            ("result", "catalog", "items"),
            ("data", "items"),
            ("items",),
            ("catalog", "items"),
        ):
            node: Any = data
            for key in path:
                if isinstance(node, dict):
                    node = node.get(key)
                else:
                    node = None
                    break
            if isinstance(node, list):
                items = [d for d in node if isinstance(d, dict)]
                if items and any(_looks_like_item(d) for d in items):
                    return items

        return _walk_items(data)

    @staticmethod
    def _normalize_many(
        raw_items: list[dict], limit: int, host: str = DESKTOP_HOST
    ) -> list[AvitoItem]:
        """Нормализует и дедублицирует объявления, сохраняя порядок выдачи."""
        result: list[AvitoItem] = []
        seen: set[str] = set()
        for raw in raw_items:
            item = _normalize_item(raw, host)
            if item is None or item.item_id in seen:
                continue
            seen.add(item.item_id)
            result.append(item)
            if len(result) >= limit:
                break
        return result
