# -*- coding: utf-8 -*-
"""Смотрим, как реально устроено поле с фото в живом JSON Авито."""
import json, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

raw = open("_chunk_real.json", encoding="utf-8").read()
data = json.loads(raw)

def walk(node, path=""):
    if isinstance(node, dict):
        for k, v in node.items():
            yield from walk(v, path + "." + k)
    elif isinstance(node, list):
        for i, v in enumerate(node[:3]):
            yield from walk(v, path + f"[{i}]")
    else:
        yield path, node

# найти список items
items = None
def find_items(node):
    if isinstance(node, dict):
        if "items" in node and isinstance(node["items"], list):
            return node["items"]
        for v in node.values():
            r = find_items(v)
            if r: return r
    elif isinstance(node, list):
        for v in node:
            r = find_items(v)
            if r: return r
    return None

items = find_items(data)
print("items:", len(items) if items else 0)
it = items[0]
print("keys:", sorted(it.keys()))
for key in ("images", "gallery", "photo", "image", "imageUrls", "pictures"):
    if key in it:
        print(f"\n--- {key} ---")
        print(json.dumps(it[key], ensure_ascii=False)[:900])
