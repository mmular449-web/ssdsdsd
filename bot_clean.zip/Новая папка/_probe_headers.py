"""Замер №3: как curl_cffi совмещает мои заголовки с отпечатком impersonate.

Поднимаем локальный echo-сервер и смотрим, что реально уходит в провод:
порядок заголовков, не задваивается ли User-Agent, сохраняются ли куки
между запросами одной сессии.
"""

from __future__ import annotations

import asyncio
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from curl_cffi import AsyncSession

RECEIVED: list[dict] = []
HIT = {"n": 0}


class Echo(BaseHTTPRequestHandler):
    def log_message(self, *a) -> None:
        pass

    def do_GET(self) -> None:  # noqa: N802
        HIT["n"] += 1
        RECEIVED.append({
            "n": HIT["n"],
            "path": self.path,
            "headers": dict(self.headers.items()),
            "order": [k for k, _ in self.headers.items()],
            "cookies": self.headers.get("Cookie", ""),
        })
        # Сервер ставит куку — проверяем, что сессия её подхватит и вернёт
        body = json.dumps({"ok": True, "n": HIT["n"]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Set-Cookie", f"srv_cookie_{HIT['n']}=value{HIT['n']}; Path=/")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def start() -> int:
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Echo)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv.server_address[1]


CUSTOM_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")


async def main() -> None:
    port = start()
    base = f"http://127.0.0.1:{port}"

    async with AsyncSession(impersonate="chrome120", timeout=15) as s:
        # Заголовки вешаем на СЕССИЮ — они должны жить во всей цепочке
        s.headers.update({
            "User-Agent": CUSTOM_UA,
            "Sec-Ch-Ua": '"Chromium";v="120", "Not(A:Brand";v="24", '
                         '"Google Chrome";v="120"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
        })

        await s.get(f"{base}/warmup")
        await asyncio.sleep(0.2)
        await s.get(f"{base}/search?q=hollister")

    for rec in RECEIVED:
        print(f"\n=== Запрос #{rec['n']} → {rec['path']}")
        print(f"    Куки, ушедшие на сервер: {rec['cookies'] or 'нет (первый запрос)'}")
        print(f"    Порядок заголовков ({len(rec['order'])}): {rec['order']}")
        for key in ("User-Agent", "Sec-Ch-Ua", "Sec-Ch-Ua-Mobile",
                    "Sec-Ch-Ua-Platform", "Accept", "Referer"):
            vals = [v for k, v in rec["headers"].items() if k.lower() == key.lower()]
            if vals:
                print(f"    {key}: {vals}  ({len(vals)} шт.)")

    print("\n=== Куки, накопленные сессией:")
    print("   ", dict(RECEIVED and s.cookies) if RECEIVED else "n/a")


if __name__ == "__main__":
    asyncio.run(main())
