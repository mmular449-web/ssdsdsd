# MEMORY.md — AvitoBot

## Проект
Telegram-бот для мониторинга новых объявлений на Авито.
Стек: Python 3.13, curl_cffi (TLS-impersonate), aiogram 3, SQLite, asyncio.

## Архитектура парсера (parser.py)
- **Без внутренних API**: `/api/{v}/items` и `/api/1/locations` мертвы
  (WAF Qrator режет на edge → 403/404). Только мобильная выдача
  `m.avito.ru` с парсингом HTML и встроенного JSON.
- **Обязательный warm-up**: GET `https://m.avito.ru/` перед поиском —
  выдаёт куку WAF. Без неё → 403 на первом же запросе.
- **curl_cffi AsyncSession** с `impersonate="chrome120"`, одна сессия
  на прокси, куки и заголовки накапливаются.
- **Каскад источников**: потоковый JSON (loaderData.data.catalog.items)
  → DOM-маркеры (data-marker="item") → встроенный стейт → DOM-фолбэк
  → JSON-LD.

## CDN картинок: два формата
- **Мобильный**: `NN.img.avito.st/image/1/hash` — размер НЕ в URL,
  выбирается ключом словаря в JSON (`{"636x636": url, ...}`). Максимум —
  636x636. `_largest_size_url` выбирает, `_upgrade_image` не трогает.
- **Десктопный**: `images.avito.ru/image/640x480/hash` — размер в URL,
  `_upgrade_image` заменяет на 1280x960.

## Тестирование
- `tests/test_parser_offline.py` — 114 офлайн-проверок (без обращений
  к Авито). Для запуска нужен venv с curl_cffi, loguru, python-dotenv.
  Тесты с aiogram (test_poll_interval, test_caption_formatting) падают
  без установленного aiogram — это ожидаемо.
- `_probe_validate_real.py` — валидация на реальной HTML-странице
  (`_search_real.html`, 3.6 МБ). Все проверки проходят.

## Жёсткие правила
- Базовое ядро парсера (warm-up, сессии, каскад источников) — работает
  и не должно переписываться без эмпирического подтверждения.
- Спорные вопросы о рендере/производительности — решаются замером,
  не чтением кода.
- Версия статики `?v=N` поднимается при каждой правке (требование
  Яндекс Игр — не для этого проекта, но привычка осталась).
