"""Офлайн-проверки парсера Авито (без обращений к самому Авито).

Зачем это нужно: основной парсер нельзя проверить «вживую», пока IP
заблокирован или пока не куплен мобильный прокси. Здесь проверяется
всё остальное, что гарантированно обязано работать:

    1. разбор JSON мобильного API и нормализация объявления;
    2. извлечение объявлений из HTML (встроенный стейт + JSON-LD);
    3. ретраи и экспоненциальный backoff против локального сервера,
       который сначала отдаёт 403, а потом 200;
    4. ротация IP по ссылке провайдера и перебор прокси по кругу;
    5. интервал цикла мониторинга — ровно 60 секунд от старта к старту.

Запуск:  python tests/test_parser_offline.py
"""

from __future__ import annotations

import ast
import asyncio
import json
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import parser as avito_parser  # noqa: E402
from parser import (  # noqa: E402
    AvitoParser,
    ProxyPool,
    _extract_images,
    _extract_price,
    _normalize_item,
    _upgrade_image,
    _walk_items,
)

PASSED: list[str] = []
FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    """Фиксирует результат одной проверки."""
    if condition:
        PASSED.append(name)
        print(f"  ✓ {name}")
    else:
        FAILED.append(f"{name}: {detail}")
        print(f"  ✗ {name} — {detail}")


# ============================ фикстуры ============================

# Типичный ответ мобильного API Авито (/api/N/items)
API_RESPONSE = {
    "status": "ok",
    "result": {
        "items": [
            {
                "id": 3987654321,
                "title": "Куртка Hollister California",
                "priceDetailed": {"value": 2500, "currency": "RUR",
                                  "string": "2 500 ₽"},
                "images": [
                    {"id": "img1", "url": "//images.avito.ru/image/640x480/a.jpg"},
                    {"id": "img2", "url": "//images.avito.ru/image/640x480/b.jpg"},
                ],
                "urlPath": "/moskva/odezhda/kurtka_hollister_3987654321",
                "location": {"name": "Москва"},
                "seller": {"name": "Анна"},
                "time": 1690000000,
            },
            {
                "id": 3987654322,
                "title": "Худи Hollister",
                "price": "1 200 ₽",
                "imageUrls": ["https://images.avito.ru/image/1280x960/c.jpg"],
                "url": "https://www.avito.ru/moskva/hudi_hollister_3987654322",
                "location": {"name": "Химки"},
                "description": "Состояние <b>новое</b>, бирка на месте.",
            },
        ],
        "count": 2,
    },
}

# Встроенный JSON-стейт мобильной страницы
HTML_WITH_STATE = """
<html><body><div id="app"></div>
<script>window.__initialState__ = {"catalog":{"items":[
  {"id": 111222333, "title": "Джинсы Hollister", "price": "900 ₽",
   "images": [{"url": "//images.avito.ru/image/640x480/d.jpg"}],
   "urlPath": "/moskva/dzhinsy_hollister_111222333"}
]}};</script>
</body></html>
"""

# Микроразметка schema.org со страницы объявления
HTML_WITH_JSON_LD = """
<html><head>
<script type="application/ld+json">
{"@type":"Product","name":"Пальто Hollister","sku":"555666777",
 "description":"Тёплое пальто, размер M",
 "image":["//images.avito.ru/image/640x480/e.jpg"],
 "url":"https://www.avito.ru/moskva/palto_hollister_555666777",
 "offers":{"@type":"Offer","price":"3400","priceCurrency":"RUB"}}
</script>
</head><body></body></html>
"""


# ===================== 1. Нормализация JSON =====================

def test_api_normalization() -> None:
    print("\n[1] Разбор JSON мобильного API")
    raw_items = AvitoParser._dig_items(API_RESPONSE)
    check("объявления найдены по пути result.items", len(raw_items) == 2,
          f"найдено {len(raw_items)}")

    items = AvitoParser._normalize_many(raw_items, limit=10)
    check("обе карточки нормализованы", len(items) == 2, f"получено {len(items)}")

    first = items[0]
    check("id извлечён", first.item_id == "3987654321", first.item_id)
    check("название извлечено", first.title == "Куртка Hollister California",
          first.title)
    check("цена текстом из priceDetailed", first.price == "2 500 ₽", first.price)
    check("цена числом", first.price_value == 2500, str(first.price_value))
    check("ссылка собрана из urlPath",
          first.item_url == "https://www.avito.ru/moskva/odezhda/"
                            "kurtka_hollister_3987654321",
          first.item_url)
    check("два фото", len(first.images) == 2, str(first.images))
    check("фото доведены до 1280x960",
          first.images[0] == "https://images.avito.ru/image/1280x960/a.jpg",
          first.images[0])
    check("город извлечён", first.location == "Москва", first.location)
    check("продавец извлечён", first.seller == "Анна", first.seller)

    second = items[1]
    check("цена из строкового price", second.price == "1 200 ₽", second.price)
    check("альтернативный ключ imageUrls", len(second.images) == 1,
          str(second.images))
    check("описание очищено от HTML-тегов",
          second.description == "Состояние новое, бирка на месте.",
          second.description)

    payload = first.to_dict()
    check("to_dict() содержит ключи для бота",
          {"title", "price", "images", "item_url", "description"} <= set(payload),
          str(sorted(payload)))


def test_price_and_images_helpers() -> None:
    print("\n[2] Помощники: цена и картинки")
    text, value = _extract_price({"priceDetailed": {"value": 9990,
                                                    "currency": "RUB"}})
    check("цена из value+currency", value == 9990 and "9 990" in text, f"{text}")

    text, value = _extract_price({})
    check("пустая цена → 'Цена не указана'", text == "Цена не указана", text)

    images = _extract_images([
        {"id": "x", "url": "//images.avito.ru/image/{imageId}_{width}x{height}.jpg"}
    ])
    check("шаблон {imageId} раскрыт",
          images == ["https://images.avito.ru/image/x_1280x960.jpg"], str(images))

    images = _extract_images([{"id": "y", "url": "https://cdn.tld/pic.jpg"}])
    check("обычный URL не искажён", images == ["https://cdn.tld/pic.jpg"],
          str(images))

    check("дубли отсекаются",
          len(_extract_images(["//a.ru/1.jpg", "//a.ru/1.jpg"])) == 1)
    check("битые шаблоны отбрасываются",
          _extract_images([{"url": "//a.ru/{unknown}.jpg"}]) == [])
    got = _upgrade_image("//images.avito.ru/image/640x480/z.jpg")
    check("_upgrade_image поднимает размер",
          got == "https://images.avito.ru/image/1280x960/z.jpg", got)


# ===================== 2. Разбор HTML =====================

def test_html_strategies() -> None:
    print("\n[3] Извлечение объявлений из HTML")

    items = AvitoParser._items_from_html(HTML_WITH_STATE, "https://m.avito.ru")
    check("объявление из встроенного стейта", len(items) == 1, f"найдено {len(items)}")
    if items:
        check("id из стейта", str(items[0].get("id")) == "111222333",
              str(items[0].get("id")))

    # Стейта нет — должен сработать запасной обход дерева
    items = AvitoParser._items_from_html(
        '<html><script>var x = {"deep":{"nested":{"items":'
        '[{"id":777,"title":"Тест","price":"10 ₽",'
        '"urlPath":"/msk/t_777"}]}}};</script></html>',
        "https://m.avito.ru",
    )
    check("обход дерева находит вложенные объявления", len(items) == 1,
          f"найдено {len(items)}")

    items = AvitoParser._items_from_html(HTML_WITH_JSON_LD,
                                         "https://www.avito.ru")
    check("объявление из JSON-LD", len(items) == 1, f"найдено {len(items)}")
    if items:
        normalized = _normalize_item(items[0], "https://www.avito.ru")
        check("JSON-LD: название", normalized is not None
              and normalized.title == "Пальто Hollister",
              normalized.title if normalized else "None")
        check("JSON-LD: описание",
              normalized is not None and normalized.description == "Тёплое пальто, размер M",
              normalized.description if normalized else "None")

    check("мусор без объявлений → пусто",
          AvitoParser._items_from_html("<html><body>капча</body></html>",
                                       "https://m.avito.ru") == [])

    check("обход дерева не падает на не-объектах",
          _walk_items([1, "a", None, {"a": [{"b": 2}]}]) == [])


# ============ 3. Ретраи, блокировки и ротация IP ============

class _FlakyHandler(BaseHTTPRequestHandler):
    """Отдаёт 403 первые `fail_times` раз, потом 200 с JSON."""

    fail_times = 2
    hits = 0
    rotate_hits = 0

    def log_message(self, *args) -> None:  # глушим штатный лог сервера
        pass

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/rotate"):
            type(self).rotate_hits += 1
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK new ip 10.0.0.7")
            return

        type(self).hits += 1
        if type(self).hits <= type(self).fail_times:
            body = "<html>Доступ ограничен</html>".encode("utf-8")
            self.send_response(403)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        body = json.dumps(API_RESPONSE).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def _start_server() -> tuple[ThreadingHTTPServer, int]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), _FlakyHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, server.server_address[1]


def test_retry_and_backoff() -> None:
    print("\n[4] Ретраи при 403 и экспоненциальный backoff")
    server, port = _start_server()
    try:
        # --- сценарий 1: два 403, затем 200 ---
        _FlakyHandler.hits = 0
        _FlakyHandler.fail_times = 2
        parser = AvitoParser(attempts=4, base_delay=0.05, max_delay=0.2)

        async def scenario_ok() -> None:
            body = await parser._request("GET", f"http://127.0.0.1:{port}/items")
            check("после 403 парсер достучался до 200", body is not None)
            check("сделано ровно 3 попытки (2 провала + успех)",
                  _FlakyHandler.hits == 3, f"попыток: {_FlakyHandler.hits}")
            check("флаг blocked сброшен после успеха", parser.blocked is False)
            if body:
                data = json.loads(body)
                check("ответ распарсился в объявления",
                      len(AvitoParser._dig_items(data)) == 2)
            await parser.stop()

        asyncio.run(scenario_ok())

        # --- сценарий 2: вечный 403 → сдача после RETRY_ATTEMPTS ---
        _FlakyHandler.hits = 0
        _FlakyHandler.fail_times = 10_000
        parser2 = AvitoParser(attempts=3, base_delay=0.05, max_delay=0.2)

        async def scenario_blocked() -> None:
            body = await parser2._request("GET", f"http://127.0.0.1:{port}/items")
            check("при постоянном 403 ответ None", body is None)
            check("выдержано ровно 3 попытки", _FlakyHandler.hits == 3,
                  f"попыток: {_FlakyHandler.hits}")
            check("флаг blocked выставлен", parser2.blocked is True)
            check("серия блокировок учтена", parser2.block_streak == 3,
                  f"streak={parser2.block_streak}")
            await parser2.stop()

        asyncio.run(scenario_blocked())

        # --- сценарий 3: таймаут прокси ловится как сетевая ошибка ---
        parser3 = AvitoParser(proxies=["http://user:pass@10.255.255.1:9999"],
                              attempts=2, base_delay=0.05, max_delay=0.1)

        async def scenario_timeout() -> None:
            body = await parser3._request("GET", f"http://127.0.0.1:{port}/items")
            check("недоступный прокси → None, без падения", body is None)
            check("недоступный прокси помечен как блокировка",
                  parser3.blocked is True)
            await parser3.stop()

        asyncio.run(scenario_timeout())
    finally:
        server.shutdown()


def test_proxy_pool() -> None:
    print("\n[5] Пул прокси: ротация IP и перебор адресов")
    server, port = _start_server()
    try:
        _FlakyHandler.rotate_hits = 0

        # Ротация по ссылке провайдера
        pool = ProxyPool(proxies=[], rotation_url=f"http://127.0.0.1:{port}/rotate",
                         rotation_cooldown=0)
        rotated = asyncio.run(pool.rotate_ip())
        check("GET по ссылке ротации выполнен", rotated is True)
        check("счётчик ротаций увеличен", pool.rotations == 1, str(pool.rotations))
        check("сервер получил запрос на /rotate",
              _FlakyHandler.rotate_hits == 1, str(_FlakyHandler.rotate_hits))

        # Перебор по кругу
        pool = ProxyPool(proxies=["http://u:p@1.1.1.1:8000",
                                  "http://u:p@2.2.2.2:8000",
                                  "http://u:p@3.3.3.3:8000"])
        check("текущий — первый", pool.current == "http://u:p@1.1.1.1:8000")
        pool.switch_next()
        check("после переключения — второй",
              pool.current == "http://u:p@2.2.2.2:8000")
        pool.switch_next()
        pool.switch_next()
        check("круг замкнулся на первый",
              pool.current == "http://u:p@1.1.1.1:8000")

        # Пароль не должен утекать в логи
        check("маскирование прокси в логах",
              "p@" not in ProxyPool._mask("http://u:p@1.1.1.1:8000")
              and "***:***@1.1.1.1:8000" in ProxyPool._mask("http://u:p@1.1.1.1:8000"),
              ProxyPool._mask("http://u:p@1.1.1.1:8000"))

        # Пустой пул не ломает логику
        empty = ProxyPool()
        check("пустой пул: current=None", empty.current is None)
        check("пустой пул: rotate_ip()=False",
              asyncio.run(empty.rotate_ip()) is False)
    finally:
        server.shutdown()


def test_block_detection() -> None:
    print("\n[6] Детектор блокировки")
    check("403 → блокировка", AvitoParser._is_blocked(403, ""))
    check("429 → блокировка", AvitoParser._is_blocked(429, ""))
    check("503 → блокировка", AvitoParser._is_blocked(503, ""))
    check("200 → не блокировка", not AvitoParser._is_blocked(200, "<html>ок</html>"))
    check("200 с капчей в теле → блокировка",
          AvitoParser._is_blocked(200, "<html>Проверка безопасности</html>"))
    check("404 → не блокировка", not AvitoParser._is_blocked(404, ""))


# ============ 4. Тайминг цикла мониторинга ============

def test_poll_interval() -> None:
    print("\n[7] Интервал цикла мониторинга")
    import main as bot_main

    calls: list[float] = []

    async def fake_cycle(bot, db, parser) -> None:
        calls.append(time.monotonic())
        await asyncio.sleep(0.25)  # имитация работы цикла

    bot_main.run_cycle = fake_cycle          # подменяем реальный проход
    bot_main.POLL_INTERVAL_SECONDS = 1.0     # минуту сжимаем до секунды
    bot_main.NIGHT_MODE = False

    async def scenario() -> None:
        task = asyncio.create_task(bot_main.monitoring_loop(None, None, None))
        await asyncio.sleep(3.3)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    asyncio.run(scenario())

    # Старты: 0.0, 1.0, 2.0, 3.0 — то есть 4 вызова за окно 3.3 с.
    check("цикл стартует раз в 1 с (4 вызова за 3.3 с)", 3 <= len(calls) <= 4,
          f"выполнено {len(calls)}")
    if len(calls) >= 3:
        periods = [round(b - a, 2) for a, b in zip(calls, calls[1:])]
        # Работа цикла — 0.25 с, значит спать надо 0.75 с, и старт к старту
        # выходит ровно 1.00 с, а не 1.25 с (как было бы без компенсации).
        check("период между стартами ~1.00 с (компенсация дрейфа)",
              all(0.95 <= p <= 1.15 for p in periods), f"периоды: {periods}")


def test_caption_formatting() -> None:
    print("\n[8] Форматирование подписи для Telegram")
    import main as bot_main

    item = {
        "title": "Куртка Hollister California " * 20,  # заведомо длинное
        "price": "2 500 ₽",
        "item_url": "https://www.avito.ru/moskva/kurtka_1",
        "images": ["https://images.avito.ru/image/1280x960/a.jpg"],
        "description": "Отличное состояние " * 60,
        "location": "Москва",
        "seller": "Анна",
    }
    caption = bot_main.build_caption(item)
    check("подпись уложена в лимит Telegram (1024)",
          len(caption) <= 1024, f"длина {len(caption)}")
    check("цена в подписи", "2 500 ₽" in caption)
    check("ссылка на объявление в подписи", item["item_url"] in caption)
    check("описание обрезано", "…" in caption)

    # HTML-инъекция не должна ломать разметку
    hostile = dict(item, title="<script>alert(1)</script>",
                   description="", location="", seller="")
    caption = bot_main.build_caption(hostile)
    check("спецсимволы экранированы", "<script>" not in caption, caption[:80])


# ===== 5. Прогрев сессии (архитектура без внутренних API) =====

# Главная мобильной версии: сервер ставит куку WAF
HOME_HTML = """<!doctype html><html><head><title>Авито</title></head>
<body><h1>Авито — объявления</h1></body></html>"""

# Поисковая выдача со встроенным JSON-стейтом
SEARCH_HTML = """<!doctype html><html><head><title>Объявления</title></head>
<body>
<script>window.__initialState__ = {"catalog":{"items":[
  {"id": 555000111, "title": "Куртка Hollister", "price": "2 500 ₽",
   "images": [{"url": "//images.avito.ru/image/640x480/k.jpg"}],
   "urlPath": "/moskva/odezhda/kurtka_hollister_555000111"},
  {"id": 555000222, "title": "Худи Hollister", "price": "1 200 ₽",
   "images": [{"url": "//images.avito.ru/image/640x480/h.jpg"}],
   "urlPath": "/moskva/odezhda/hudi_hollister_555000222"}
]}};</script>
</body></html>"""

# Страница бана Qrator — та самая, что замерена на реальном Авито
BAN_HTML = """<!doctype html><html><head>
<title>Доступ ограничен: проблема с IP</title></head><body>
<div class="js-form-captcha"><img class="js-form-captcha-image"></div>
<script>function sethCaptchaResponse(response){}</script>
<canvas id="my_Canvas"></canvas>
</body></html>"""

# Выдача без JSON-стейта — только разметка (проверка DOM-фолбэка)
DOM_ONLY_HTML = """<!doctype html><html><body>
<div data-marker="item">
  <a href="/moskva/odezhda/kurtka_hollister_3987654321">
    <img src="//images.avito.ru/image/640x480/k1.jpg">
    <h3 itemprop="name">Куртка Hollister California</h3>
  </a>
  <span itemprop="price" content="2500">2 500 &#8381;</span>
</div>
<a href="/moskva/odezhda/hudi_hollister_3987654322">
  <img data-src="//images.avito.ru/image/640x480/h1.jpg">
  Худи Hollister
</a>
<span>1 200 &#8381;</span>
</body></html>"""


class _WarmHandler(BaseHTTPRequestHandler):
    """Имитирует мобильную версию Авито: главная, выдача и страница бана."""

    requests: list[dict] = []
    home_cookie = "waf_session"

    def log_message(self, *args) -> None:
        pass

    def do_GET(self) -> None:  # noqa: N802
        path = self.path
        type(self).requests.append({
            "path": path,
            "referer": self.headers.get("Referer"),
            "cookie": self.headers.get("Cookie", "") or "",
            "ua": self.headers.get("User-Agent", ""),
            "sec_ch_ua": self.headers.get("Sec-Ch-Ua", ""),
        })

        # ВАЖНО: Set-Cookie можно отправлять только ПОСЛЕ send_response —
        # иначе BaseHTTPRequestHandler его молча теряет.
        if path.startswith("/ban"):
            body = BAN_HTML.encode("utf-8")
            code = 403
        elif path.startswith("/moskva"):
            body = SEARCH_HTML.encode("utf-8")
            code = 200
        else:
            body = HOME_HTML.encode("utf-8")
            code = 200

        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        if code == 200 and path == "/":
            self.send_header("Set-Cookie", f"{self.home_cookie}=abc123xyz; Path=/")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def _start_warm_server() -> tuple[ThreadingHTTPServer, int]:
    _WarmHandler.requests = []
    server = ThreadingHTTPServer(("127.0.0.1", 0), _WarmHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, server.server_address[1]


def test_warmup_session_chain() -> None:
    print("\n[9] Обязательный прогрев и единая сессия на всю цепочку")
    server, port = _start_warm_server()
    base = f"http://127.0.0.1:{port}"
    original_host = avito_parser.MOBILE_HOST
    avito_parser.MOBILE_HOST = base
    try:
        parser = AvitoParser(attempts=2, base_delay=0.01, max_delay=0.05,
                             jitter=(0.01, 0.02), sightseeing_chance=0.0)

        async def scenario() -> None:
            # Persistent-сессия: один и тот же объект на всю цепочку
            first = parser._session()
            check("сессия переиспользуется (persistent)", first is parser._session())

            check("прогрев вернул True", await parser.warmup() is True)
            check("куки WAF получены", len(first.cookies) > 0,
                  str(dict(first.cookies)))
            check("флаг прогрева поднят", parser._warm is True)
            check("счётчик прогревов = 1", parser.warmups == 1, str(parser.warmups))

            # Заголовки идентичности висят на сессии, а не на одном запросе
            check("User-Agent на сессии", "Chrome" in first.headers.get(
                "User-Agent", ""), first.headers.get("User-Agent", ""))
            check("Sec-Ch-Ua на сессии",
                  "Chromium" in first.headers.get("Sec-Ch-Ua", ""),
                  first.headers.get("Sec-Ch-Ua", ""))

            # Повторный прогрев при живом TTL не должен дёргать Авито
            check("повторный прогрев бесплатный",
                  await parser.warmup() is True and parser.warmups == 1,
                  f"прогревов: {parser.warmups}")

            # Переход на выдачу: Referer и куки должны поехать по цепочке
            body = await parser._request(
                "GET",
                f"{base}/moskva/odezhda?q=hollister",
                headers=parser._nav_headers(referer=parser._referer),
            )
            check("выдача получена", body is not None)

            home = [r for r in _WarmHandler.requests if r["path"] == "/"]
            search = [r for r in _WarmHandler.requests
                      if r["path"].startswith("/moskva")]
            check("прогрев ушёл на главную", len(home) >= 1, str(len(home)))
            check("у прогрева нет Referer (вход из ниоткуда)",
                  bool(home) and not home[0]["referer"], str(home[0]["referer"]))
            check("Referer передан на выдачу по цепочке",
                  bool(search) and search[0]["referer"] == base + "/",
                  str(search[0]["referer"]) if search else "нет запроса")
            check("куки отправлены на выдачу",
                  bool(search) and _WarmHandler.home_cookie in search[0]["cookie"],
                  str(search[0]["cookie"]) if search else "нет запроса")
            check("User-Agent доехал до выдачи",
                  bool(search) and "Chrome" in search[0]["ua"])
            check("Sec-Ch-Ua доехал до выдачи",
                  bool(search) and "Chromium" in search[0]["sec_ch_ua"])

            # Ротация IP → новый выходной адрес → прогрев обязателен заново
            await parser._drop_session()
            check("после сброса сессии прогрев снят", parser._warm is False)

            # Протухший по TTL прогрев обязан обновляться
            parser._warm = True
            parser._warm_at = time.monotonic() - 9999.0
            check("протухший прогрев перепрогревается",
                  parser._warm_expired() is True)
            await parser.stop()

        asyncio.run(scenario())
    finally:
        avito_parser.MOBILE_HOST = original_host
        server.shutdown()


def test_warmup_failure_is_not_fatal() -> None:
    print("\n[10] Прогрев при бане: не падаем, а поднимаем флаг")
    server, port = _start_warm_server()
    original_host = avito_parser.MOBILE_HOST
    avito_parser.MOBILE_HOST = f"http://127.0.0.1:{port}/ban"
    try:
        parser = AvitoParser(attempts=2, base_delay=0.01, max_delay=0.03,
                             jitter=(0.001, 0.002), sightseeing_chance=0.0)

        async def scenario() -> None:
            try:
                ok = await parser.warmup()
                check("прогрев вернул False", ok is False)
                check("флаг blocked поднят", parser.blocked is True)
                check("прогрев не считается успешным", parser._warm is False)
                check("сделано несколько попыток (WARMUP_ATTEMPTS)",
                      parser.warmups == 0, str(parser.warmups))
                # Поиск при мёртвом IP не должен бросать исключение
                items = await parser.fetch_search_items(
                    "https://www.avito.ru/moskva?q=hollister", limit=5)
                check("поиск при бане вернул пустой список", items == [],
                      str(items))
            except Exception as exc:
                check("прогрев при бане не бросает исключений", False,
                      f"{type(exc).__name__}: {exc}")
            await parser.stop()

        asyncio.run(scenario())
    finally:
        avito_parser.MOBILE_HOST = original_host
        server.shutdown()


def test_human_pause_jitter() -> None:
    print("\n[11] Рандомизация задержек между запросами")
    original = (avito_parser.LONG_PAUSE_CHANCE, avito_parser.LONG_PAUSE_MIN,
                avito_parser.LONG_PAUSE_MAX)
    avito_parser.LONG_PAUSE_CHANCE = 0.0
    try:
        delays: list[float] = []
        probe = AvitoParser(attempts=1, base_delay=0.01, max_delay=0.02)

        async def scenario() -> None:
            for _ in range(25):
                t0 = time.perf_counter()
                await probe._human_pause(0.01, 0.05)
                delays.append(time.perf_counter() - t0)

        asyncio.run(scenario())
        check("все паузы в границах (0.01–0.05 с)",
              all(0.005 <= d <= 0.30 for d in delays),
              f"min={min(delays):.4f} max={max(delays):.4f}")
        check("паузы разные (есть джиттер)", len(set(round(d, 4) for d in delays)) > 5,
              f"уникальных: {len(set(round(d, 4) for d in delays))}")

        # Редкая длинная пауза должна уметь срабатывать
        avito_parser.LONG_PAUSE_CHANCE = 1.0
        avito_parser.LONG_PAUSE_MIN = 0.05
        avito_parser.LONG_PAUSE_MAX = 0.06

        async def long_scenario() -> None:
            t0 = time.perf_counter()
            await probe._human_pause(0.001, 0.002)
            check("длинная пауза добавляется поверх обычной",
                  time.perf_counter() - t0 >= 0.05)

        asyncio.run(long_scenario())
    finally:
        (avito_parser.LONG_PAUSE_CHANCE, avito_parser.LONG_PAUSE_MIN,
         avito_parser.LONG_PAUSE_MAX) = original


def test_dom_fallback() -> None:
    print("\n[12] DOM-фолбэк: выдача без встроенного JSON-стейта")
    items = AvitoParser._items_from_html(DOM_ONLY_HTML, "https://m.avito.ru")
    check("объявления найдены в разметке", len(items) == 2, f"найдено {len(items)}")
    if len(items) == 2:
        check("id первой карточки", str(items[0].get("id")) == "3987654321",
              str(items[0].get("id")))
        check("заголовок из itemprop=name",
              items[0].get("title") == "Куртка Hollister California",
              str(items[0].get("title")))
        check("цена из микроразметки content=2500",
              str(items[0].get("price")).replace("\xa0", " ").strip() == "2 500 ₽",
              str(items[0].get("price")))
        check("фото из src", bool(items[0].get("images")),
              str(items[0].get("images")))
        check("id второй карточки", str(items[1].get("id")) == "3987654322",
              str(items[1].get("id")))
        check("заголовок из текста ссылки",
              items[1].get("title") == "Худи Hollister",
              str(items[1].get("title")))
        check("цена текстом из окна после ссылки",
              str(items[1].get("price")).replace("\xa0", " ").strip() == "1 200 ₽",
              str(items[1].get("price")))

    # Нормализация до контракта бота
    normalized = AvitoParser._normalize_many(items, limit=5,
                                             host="https://m.avito.ru")
    check("DOM-объявления нормализуются", len(normalized) == 2)
    if normalized:
        check("ссылка абсолютная",
              normalized[0].item_url.startswith("https://m.avito.ru/"),
              normalized[0].item_url)
        check("фото доведено до 1280x960",
              any("1280x960" in img for img in normalized[0].images),
              str(normalized[0].images))


def test_block_classification() -> None:
    print("\n[13] Классификация блокировки: бан / капча / лимит")
    check("403 + заголовок Qrator → бан по IP",
          AvitoParser._classify_block(403, BAN_HTML) == "ban",
          str(AvitoParser._classify_block(403, BAN_HTML)))
    check("200 с маркерами бана → бан (маркеры важнее кода)",
          AvitoParser._classify_block(200, BAN_HTML) == "ban",
          str(AvitoParser._classify_block(200, BAN_HTML)))
    check("429 → лимит запросов",
          AvitoParser._classify_block(429, "") == "rate")
    check("200 чистая → без блокировки",
          AvitoParser._classify_block(200, "<html>ок</html>") is None)
    check("200 с 'Проверка безопасности' → капча",
          AvitoParser._classify_block(200, "<html>Проверка безопасности</html>")
          == "captcha")
    check("503 → http-ошибка",
          AvitoParser._classify_block(503, "") == "http")
    check("страница бана детектится как блокировка",
          AvitoParser._is_blocked(200, BAN_HTML) is True)


def test_no_internal_api() -> None:
    print("\n[14] Архитектурный запрет внутренних API Авито")
    source = Path(avito_parser.__file__).read_text(encoding="utf-8")
    tree = ast.parse(source)

    # Docstring'ы в расчёт не берём: в них как раз описано, ПОЧЕМУ
    # эндпоинты /api/* удалены.
    docstring_ids: set[int] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                             ast.AsyncFunctionDef)):
            body = getattr(node, "body", [])
            if (body and isinstance(body[0], ast.Expr)
                    and isinstance(body[0].value, ast.Constant)
                    and isinstance(body[0].value.value, str)):
                docstring_ids.add(id(body[0].value))

    offenders = [
        node.value for node in ast.walk(tree)
        if isinstance(node, ast.Constant)
        and isinstance(node.value, str)
        and id(node) not in docstring_ids
        and "/api/" in node.value
    ]
    check("в исполняемом коде нет путей /api/*", not offenders, str(offenders))

    for name in ("API_VERSIONS", "MAX_VERSION_PROBES", "API_HEADERS"):
        check(f"константа {name} удалена",
              not hasattr(avito_parser, name))

    for name in ("_fetch_via_mobile_api", "_resolve_location_id"):
        check(f"метод {name} удалён",
              not hasattr(AvitoParser, name))

    probe = AvitoParser(attempts=1, base_delay=0.01, max_delay=0.02)
    for name in ("_api_version", "_location_cache"):
        check(f"состояние {name} удалено", not hasattr(probe, name))
    check("прогрев обязателен: есть метод warmup",
          callable(getattr(AvitoParser, "warmup", None)))


def test_end_to_end_mobile_search() -> None:
    print("\n[15] Сквозной поиск через мобильную выдачу")
    server, port = _start_warm_server()
    original_host = avito_parser.MOBILE_HOST
    avito_parser.MOBILE_HOST = f"http://127.0.0.1:{port}"
    try:
        parser = AvitoParser(attempts=2, base_delay=0.01, max_delay=0.05,
                             jitter=(0.001, 0.005), sightseeing_chance=0.0)

        async def scenario() -> None:
            # Ссылку пользователь даёт десктопную — парсер всё равно идёт
            # на мобильную выдачу и сам прогревает сессию.
            items = await parser.fetch_search_items(
                "https://www.avito.ru/moskva/odezhda?q=hollister", limit=5)
            check("объявления получены", len(items) == 2, f"получено {len(items)}")
            if items:
                check("id из выдачи", items[0].item_id == "555000111",
                      items[0].item_id)
                check("цена нормализована", items[0].price == "2 500 ₽",
                      items[0].price)
                check("фото до 1280x960",
                      items[0].images
                      and "1280x960" in items[0].images[0],
                      str(items[0].images))
            check("сессия прогрета перед поиском", parser._warm is True)
            check("блокировки не было", parser.blocked is False)

            paths = [r["path"] for r in _WarmHandler.requests]
            check("сначала прогрев, потом выдача",
                  paths[:2] == ["/", "/moskva/odezhda?q=hollister"], str(paths))
            await parser.stop()

        asyncio.run(scenario())
    finally:
        avito_parser.MOBILE_HOST = original_host
        server.shutdown()


# ============================ запуск ============================

def main() -> int:
    print("=" * 68)
    print("Офлайн-проверки парсера Авито (curl_cffi)")
    print("=" * 68)
    for test in (
        test_api_normalization,
        test_price_and_images_helpers,
        test_html_strategies,
        test_retry_and_backoff,
        test_proxy_pool,
        test_block_detection,
        test_poll_interval,
        test_caption_formatting,
        test_warmup_session_chain,
        test_warmup_failure_is_not_fatal,
        test_human_pause_jitter,
        test_dom_fallback,
        test_block_classification,
        test_no_internal_api,
        test_end_to_end_mobile_search,
    ):
        try:
            test()
        except Exception as exc:  # тест не должен валить остальные
            FAILED.append(f"{test.__name__}: {type(exc).__name__}: {exc}")
            print(f"  ✗ {test.__name__} упал: {type(exc).__name__}: {exc}")

    print("\n" + "=" * 68)
    print(f"Итого: пройдено {len(PASSED)}, провалено {len(FAILED)}")
    if FAILED:
        print("\nПровалы:")
        for item in FAILED:
            print(f"  • {item}")
    print("=" * 68)
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
