"""Зонд прокси: доступность, выходной IP, меняется ли он, пускает ли на Авито."""
import asyncio
import json
import sys

from curl_cffi import AsyncSession

PROXY = "http://e2rbanfcc0-mobile-country-RU-hold-session-session-6a99816c6736a-ttl-10:NZLpBwD0qtYWSwoC@185.132.133.7:9999"

IP_SERVICES = (
    "https://api.ipify.org?format=json",
    "https://ifconfig.co/json",
)

AVITO_TARGETS = (
    ("mobile api v30", "https://m.avito.ru/api/30/items",
     {"query": "hollister", "page": "1"}),
    ("mobile api v22", "https://m.avito.ru/api/22/items",
     {"query": "hollister", "page": "1"}),
    ("mobile html", "https://m.avito.ru/moskva?q=hollister", None),
    ("desktop html", "https://www.avito.ru/moskva?q=hollister", None),
)

MARKERS = ("доступ ограничен", "проверка безопасности", "captcha",
           "не робот", "firewall", "blocked")


async def main() -> None:
    print("=" * 70)
    print("ПРОВЕРКА ПРОКСИ")
    print("=" * 70)

    async with AsyncSession(impersonate="chrome120", timeout=25,
                            proxy=PROXY) as s:
        # 1. Выходной IP — три раза подряд: общий пул часто ротирует сам
        print("\n[1] Выходной IP (3 запроса подряд):")
        for i in range(3):
            for url in IP_SERVICES:
                try:
                    r = await s.get(url)
                    if r.status_code == 200:
                        try:
                            data = r.json()
                            ip = data.get("ip") or data.get("ip_addr") or data
                        except Exception:
                            ip = r.text.strip()[:40]
                        print(f"    попытка {i+1}: HTTP {r.status_code} → {ip}")
                        break
                except Exception as exc:
                    print(f"    попытка {i+1}: {url} — {type(exc).__name__}: "
                          f"{str(exc)[:70]}")
            else:
                print(f"    попытка {i+1}: все сервисы IP недоступны")
            await asyncio.sleep(1)

        # 2. Авито через прокси
        print("\n[2] Авито через прокси:")
        for name, url, params in AVITO_TARGETS:
            try:
                r = await s.get(url, params=params,
                                headers={"Accept": "application/json, text/html"},
                                allow_redirects=True)
                body = r.text
                low = body[:20000].lower()
                markers = [m for m in MARKERS if m in low]
                kind = "JSON" if body[:1] in "{[" else "HTML"
                print(f"    [{name:14}] HTTP {r.status_code} | {kind} | "
                      f"len={len(body)} | маркеры: {markers or 'нет'}")
                if r.status_code == 200 and not markers:
                    print(f"        начало: {body[:150].replace(chr(10), ' ')}")
            except Exception as exc:
                print(f"    [{name:14}] ОШИБКА {type(exc).__name__}: "
                      f"{str(exc)[:90]}")
            await asyncio.sleep(1)

    print("\n" + "=" * 70)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
