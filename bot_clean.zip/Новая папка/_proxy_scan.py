"""Перебор портов прокси: ищем тот, который реально выдаёт выходной узел."""
import base64
import socket
import concurrent.futures as cf

HOST = "pool.proxy.market"
USER = "PkT1i8kHFL"
PASS = "zeDKjJBNuB"
TARGET = "api.ipify.org:443"

TOKEN = base64.b64encode(f"{USER}:{PASS}".encode()).decode()

PORTS = [
    80, 808, 1080, 1081, 2000, 3000, 3128, 3129, 4000, 5000, 6000, 7000, 8000,
    8001, 8080, 8081, 8085, 8888, 9000, 9090, 9100, 9999,
    10000, 10001, 10002, 10003, 10004, 10005, 10010, 10020, 10050, 10100,
    10200, 10300, 10500, 10800, 11000, 12000, 13000, 15000,
    20000, 21000, 25000, 30000, 31000, 40000, 50000, 60000, 65000,
]


def probe(port: int, timeout: float = 6.0) -> tuple[int, str]:
    try:
        s = socket.create_connection((HOST, port), timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        return port, f"НЕТ СОЕДИНЕНИЯ ({type(exc).__name__})"
    try:
        req = (
            f"CONNECT {TARGET} HTTP/1.1\r\n"
            f"Host: {TARGET}\r\n"
            f"Proxy-Authorization: Basic {TOKEN}\r\n\r\n"
        )
        s.sendall(req.encode())
        s.settimeout(timeout)
        data = s.recv(512)
    except Exception as exc:  # noqa: BLE001
        return port, f"обмен: {type(exc).__name__}: {exc}"
    finally:
        s.close()
    first = data.split(b"\r\n", 1)[0].decode("latin-1")
    return port, first


def main() -> None:
    print(f"Сканирую {len(PORTS)} портов на {HOST} ...\n")
    ok: list[int] = []
    auth_fail: list[int] = []
    with cf.ThreadPoolExecutor(max_workers=24) as pool:
        for port, status in pool.map(probe, PORTS):
            mark = " "
            if status.startswith("HTTP/1.1 200"):
                mark = "+"
                ok.append(port)
            elif "407" in status:
                mark = "A"  # auth rejected
                auth_fail.append(port)
            print(f"{mark} {port:<7} {status}")

    print("\n" + "=" * 60)
    print("РАБОЧИЕ (200 OK):", ok if ok else "не найдено")
    print("Отклонили авторизацию (407):", auth_fail if auth_fail else "нет")
    print("=" * 60)


if __name__ == "__main__":
    main()
