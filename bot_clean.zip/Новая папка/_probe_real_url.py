"""Проверка реального URL выдачи после редиректа: есть ли объявления в HTML."""

from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path

import parser as avito_parser
from parser import AvitoParser, ITEM_LINK_RE

URL = "https://m.avito.ru/moskva/odezhda_obuv_aksessuary?localPriority=0&q=hollister"
OUT = Path("_search_real.html")


async def fetch() -> str:
    parser = AvitoParser(attempts=6, base_delay=8.0, max_delay=25.0,
                         jitter=(1.0, 3.0), sightseeing_chance=0.0)
    try:
        if not await parser.warmup():
            return ""
        await parser._human_pause(2.0, 5.0)
        session = parser._session()
        r = await session.get(URL, headers=parser._nav_headers(
            referer=parser._referer))
        print(f"HTTP {r.status_code}, {len(r.text)} байт")
        return r.text or ""
    finally:
        await parser.stop()


def analyze(html: str) -> None:
    OUT.write_text(html, encoding="utf-8")
    print(f"\nсохранено {OUT.resolve()} ({len(html)} байт)")

    h1 = re.search(r"<h1[^>]*>(.*?)</h1>", html, re.S)
    print("h1:", " ".join(re.sub(r"<[^>]+>", " ", h1.group(1)).split())[:120] if h1 else "—")

    print("\n=== Признаки объявлений в разметке")
    for probe in ("₽", "&#8381;", "hollister", "Hollister", "iva-item",
                  "data-marker=\"item", "item-title", "data-item-id",
                  "Такой страницы не существует"):
        print(f"    {probe!r}: {html.count(probe)}")

    hrefs = re.findall(r'href="([^"]+)"', html)
    cards = [h for h in hrefs if re.search(r"_\d{6,}", h)]
    print(f"\n=== Ссылок на карточки: {len(cards)}")
    for c in cards[:10]:
        print(f"    {c}")

    print("\n=== data-marker значения (топ 20)")
    from collections import Counter
    for v, c in Counter(re.findall(r'data-marker="([^"]+)"', html)).most_common(20):
        print(f"    {v}: {c}")

    print("\n=== Потоковые чанки loaderData")
    for i, s in enumerate(re.findall(
            r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", html, re.S), 1):
        if '"loaderData"' not in s:
            continue
        print(f"    [{i}] {len(s)} симв.")
        try:
            d = json.loads(s)
            ld = d.get("loaderData", {}).get("catalog-or-main-or-item", {})
            print(f"        ключи: {list(ld)}")
            body = json.dumps(ld, ensure_ascii=False)
            print(f"        размер: {len(body)}")
            for key in ("items", "catalog", "offers", "data"):
                print(f"        '{key}' встречается: {body.count(key)}")
            # Ищем любые похожие на объявление объекты
            ids = re.findall(r'"id":(\d{8,})', body)
            print(f"        числовых id: {len(set(ids))} {sorted(set(ids))[:8]}")
            Path("_loader_real.json").write_text(body, encoding="utf-8")
            print("        сохранено: _loader_real.json")
        except Exception as exc:
            print(f"        не JSON: {type(exc).__name__}: {exc}")
            print(f"        начало: {re.sub(r'\\s+', ' ', s)[:300]}")


async def main() -> None:
    html = await fetch()
    if html:
        analyze(html)


if __name__ == "__main__":
    asyncio.run(main())
