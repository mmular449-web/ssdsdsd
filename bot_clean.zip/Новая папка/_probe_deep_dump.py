"""Глубокий разбор поисковой страницы: где лежат объявления.

Ищем, есть ли объявления в серверной разметке вообще, и если нет —
какие сетевые пути страница использует для их дозагрузки.
"""

from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path

import parser as avito_parser
from parser import AvitoParser

URL = "https://m.avito.ru/moskva?q=hollister"
OUT = Path("_search_q.html")


async def fetch() -> str:
    parser = AvitoParser(attempts=6, base_delay=8.0, max_delay=25.0,
                         jitter=(1.0, 3.0), sightseeing_chance=0.0)
    try:
        if not await parser.warmup():
            return ""
        await parser._human_pause(2.0, 5.0)
        session = parser._session()
        r = await session.get(URL, headers=parser._nav_headers(
            referer=parser._referer))
        print(f"HTTP {r.status_code}, {len(r.text)} байт")
        return r.text or ""
    finally:
        await parser.stop()


def analyze(html: str) -> None:
    OUT.write_text(html, encoding="utf-8")
    print(f"сохранено {OUT.resolve()} ({len(html)} байт)")

    print("\n=== Есть ли сами товары в разметке")
    for probe in ("hollister", "Hollister", "₽", "&#8381;", "item-title",
                  "iva-item", "data-item-id", "catalog-item",
                  "items-catalog", "js-catalog"):
        print(f"    {probe!r}: {html.count(probe)}")

    print("\n=== Все встроенные <script> (длина и начало)")
    scripts = re.findall(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", html, re.S)
    for i, s in enumerate(scripts, 1):
        head = re.sub(r"\s+", " ", s)[:200]
        print(f"    [{i}] {len(s):>7} симв. | {head}")

    print("\n=== Сетевые пути, которые страница использует")
    urls = set(re.findall(r'https?://[a-zA-Z0-9._\-]*avito[a-zA-Z0-9._/\-]*', html))
    for u in sorted(urls)[:25]:
        print(f"    {u}")
    print("    --- относительные пути вида /api/ или /web/:")
    for p in sorted(set(re.findall(r'["\'](/(?:api|web|public)[a-zA-Z0-9._/\-]*)',
                                   html)))[:25]:
        print(f"    {p}")

    print("\n=== preloadedState: ключи и поиск каталога")
    m = re.search(r'window\.__preloadedState__\s*=\s*"((?:[^"\\]|\\.)*)"', html)
    if m:
        try:
            decoded = json.loads('"' + m.group(1) + '"')
            Path("_state_q.json").write_text(decoded, encoding="utf-8")
            state = json.loads(decoded)
            print(f"    ключи: {list(state)}")
            dump = json.dumps(state, ensure_ascii=False)
            print(f"    размер: {len(dump)}")
            print(f"    'catalog' встречается: {dump.count('catalog')}")
            print(f"    'items' встречается: {dump.count('items')}")
        except Exception as exc:
            print(f"    ОШИБКА: {type(exc).__name__}: {exc}")

    print("\n=== mfe / hydration")
    m = re.search(r'window\.__mfe__\s*=\s*"((?:[^"\\]|\\.)*)"', html)
    if m:
        try:
            mfe = json.loads(json.loads('"' + m.group(1) + '"'))
            print(f"    __mfe__: {json.dumps(mfe, ensure_ascii=False)[:300]}")
        except Exception as exc:
            print(f"    __mfe__ ошибка: {exc}")

    print("\n=== Блоки вида <template> и скрытые div с JSON")
    for t in re.findall(r"<template[^>]*>(.{0,200})", html, re.S)[:5]:
        print(f"    template: {re.sub(chr(92)+'s+', ' ', t)[:150]}")


async def main() -> None:
    html = await fetch()
    if html:
        analyze(html)


if __name__ == "__main__":
    asyncio.run(main())
