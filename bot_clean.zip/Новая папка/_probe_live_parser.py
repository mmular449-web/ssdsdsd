"""Живая проверка нового парсера на реальном Авито (без прокси).

Цель — не «достать объявления» (IP заблокирован на edge, это известно),
а убедиться, что новая архитектура:
  * реально делает прогрев ПЕРВЫМ запросом;
  * не пытается больше ходить по внутренним /api/*;
  * при бане не падает, а штатно возвращает пустой список;
  * корректно классифицирует блокировку.
"""

from __future__ import annotations

import asyncio
import time

from curl_cffi import AsyncSession

import parser as avito_parser
from parser import AvitoParser

SEARCH = "https://www.avito.ru/moskva/odezhda?q=hollister"


async def main() -> None:
    # Считаем ВСЕ обращения к Авито, чтобы увидеть цепочку запросов
    calls: list[str] = []
    original_request = AsyncSession.request

    async def tracked(self, method, url, *args, **kwargs):
        calls.append(f"{method} {url}")
        return await original_request(self, method, url, *args, **kwargs)

    AsyncSession.request = tracked  # type: ignore[method-assign]

    parser = AvitoParser(
        attempts=2,
        base_delay=0.5,
        max_delay=2.0,
        jitter=(0.1, 0.3),
        sightseeing_chance=0.0,
    )
    t0 = time.perf_counter()
    try:
        items = await parser.fetch_search_items(SEARCH, limit=5)
        elapsed = time.perf_counter() - t0

        print("\n=== Результат живого прогона")
        print(f"    объявлений: {len(items)}")
        print(f"    blocked: {parser.blocked}")
        print(f"    прогревов: {parser.warmups}")
        print(f"    время: {elapsed:.2f} с")
        print(f"    падения: НЕТ (скрипт дошёл до этой строки)")

        print("\n=== Цепочка запросов к Авито")
        for i, call in enumerate(calls, 1):
            print(f"    {i}. {call}")

        api_calls = [c for c in calls if "/api/" in c]
        print(f"\n    обращений к внутренним /api/*: {len(api_calls)} "
              f"{api_calls if api_calls else '(нет — архитектура выдержана)'}")

        if calls:
            print(f"    первый запрос — прогрев: "
                  f"{calls[0].endswith('m.avito.ru/')}")
    finally:
        AsyncSession.request = original_request  # type: ignore[method-assign]
        await parser.stop()


if __name__ == "__main__":
    asyncio.run(main())
