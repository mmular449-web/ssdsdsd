"""Какой именно URL поиска отдаёт выдачу на мобильной версии.

Прогрев делаем ОДИН раз (он дорогой из-за троттлинга), потом обходим
варианты с человеческими паузами.
"""

from __future__ import annotations

import asyncio
import json
import random
import re

import parser as avito_parser
from parser import AvitoParser

VARIANTS = [
    "https://m.avito.ru/moskva?q=hollister",
    "https://www.avito.ru/moskva?q=hollister",
    "https://m.avito.ru/moskva/odezhda",
    "https://www.avito.ru/moskva/odezhda?q=hollister",
]


def describe(label: str, status: int, html: str) -> None:
    h1 = re.search(r"<h1[^>]*>(.*?)</h1>", html, re.S)
    h1_text = " ".join(re.sub(r"<[^>]+>", " ", h1.group(1)).split()) if h1 else "—"
    item_links = [h for h in re.findall(r'href="([^"]+)"', html)
                  if re.search(r"_\d{6,}", h)]
    ids = set(re.findall(r"\b\d{9,12}\b", html))
    hyd = re.search(
        r'window\.__staticRouterHydrationData\s*=\s*JSON\.parse\("((?:[^"\\]|\\.)*)"\)',
        html)
    hyd_keys, has_items = "—", False
    if hyd:
        try:
            data = json.loads(json.loads('"' + hyd.group(1) + '"'))
            ld = data.get("loaderData", {}).get("catalog-or-main-or-item", {})
            hyd_keys = str(list(ld))
            has_items = "items" in json.dumps(ld)[:200000].lower()
        except Exception:
            pass
    pre = re.search(r'window\.__preloadedState__\s*=\s*"((?:[^"\\]|\\.)*)"', html)
    pre_keys = "—"
    if pre:
        try:
            state = json.loads(json.loads('"' + pre.group(1) + '"'))
            pre_keys = str(list(state))
        except Exception:
            pass

    print(f"\n--- {label}")
    print(f"    HTTP {status} | {len(html)} байт")
    print(f"    <h1>: {h1_text[:90]}")
    print(f"    ссылок на карточки: {len(item_links)}")
    print(f"    всего длинных id: {len(ids)}")
    print(f"    404-страница: {'Такой страницы не существует' in html}")
    print(f"    ключи hydration: {hyd_keys[:120]}")
    print(f"    есть 'items' в hydration: {has_items}")
    print(f"    ключи preloadedState: {pre_keys[:160]}")
    for link in item_links[:5]:
        print(f"      → {link}")


async def main() -> None:
    parser = AvitoParser(attempts=6, base_delay=8.0, max_delay=25.0,
                         jitter=(1.0, 3.0), sightseeing_chance=1.0)
    try:
        if not await parser.warmup():
            print("ПРОГРЕВ НЕ УДАЛСЯ — дальше нет смысла")
            return
        session = parser._session()
        for url in VARIANTS:
            await parser._human_pause(3.0, 7.0)
            try:
                r = await session.get(
                    url, headers=parser._nav_headers(referer=parser._referer))
                describe(url, r.status_code, r.text or "")
                parser._referer = url
            except Exception as exc:
                print(f"\n--- {url}\n    ОШИБКА: {type(exc).__name__}: {exc}")
    finally:
        await parser.stop()


if __name__ == "__main__":
    asyncio.run(main())
