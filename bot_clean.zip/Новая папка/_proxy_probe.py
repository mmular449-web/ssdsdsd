"""Диагностика прокси: raw-socket handshake, чтобы понять протокол на порту."""
import json
import socket
import ssl
import sys

HOST = "pool.proxy.market"
PORT = 10000
USER = "PkT1i8kHFL"
PASS = "zeDKjJBNuB"

TARGET_HOST = "api.ipify.org"
TARGET_PORT = 443


def resolve(host: str) -> list[str]:
    try:
        info = socket.getaddrinfo(host, None, socket.AF_INET, socket.SOCK_STREAM)
        ips = sorted({a[4][0] for a in info})
    except Exception as exc:  # noqa: BLE001
        return [f"ОШИБКА DNS: {exc}"]
    return ips


def raw_connect_via_http(use_auth: bool, timeout: float = 15.0) -> str:
    """Ручной CONNECT по протоколу HTTP-прокси."""
    try:
        s = socket.create_connection((HOST, PORT), timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        return f"не удалось подключиться: {exc}"

    try:
        req = f"CONNECT {TARGET_HOST}:{TARGET_PORT} HTTP/1.1\r\nHost: {TARGET_HOST}:{TARGET_PORT}\r\n"
        if use_auth:
            import base64

            token = base64.b64encode(f"{USER}:{PASS}".encode()).decode()
            req += f"Proxy-Authorization: Basic {token}\r\n"
        req += "\r\n"
        s.sendall(req.encode())
        data = s.recv(4096)
        return data.decode("latin-1").replace("\r\n", " | ").strip()
    except Exception as exc:  # noqa: BLE001
        return f"ошибка обмена: {exc}"
    finally:
        s.close()


def raw_socks5(timeout: float = 15.0) -> str:
    """Пробуем SOCKS5-handshake: 0x05 0x01 0x02 (greeting, 2 метода: noauth и user/pass)."""
    try:
        s = socket.create_connection((HOST, PORT), timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        return f"не удалось подключиться: {exc}"
    try:
        s.sendall(bytes([0x05, 0x01, 0x00, 0x02]))
        data = s.recv(16)
        if not data:
            return "пустой ответ (соединение закрыто)"
        if data[0] == 0x05:
            return f"SOCKS5! выбран метод: 0x{data[1]:02x} (0x00=без auth, 0x02=user/pass, 0xff=нет методов)"
        if data[0] == 0x04:
            return "SOCKS4-ответ"
        return f"не SOCKS: первый байт 0x{data[0]:02x}, сырые байты: {data.hex()}"
    except Exception as exc:  # noqa: BLE001
        return f"ошибка обмена: {exc}"
    finally:
        s.close()


def raw_http_get(use_auth: bool, timeout: float = 15.0) -> str:
    """Обычный (не CONNECT) GET через прокси —有些 провайдеры пускают только http:// цели."""
    try:
        s = socket.create_connection((HOST, PORT), timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        return f"не удалось подключиться: {exc}"
    try:
        req = "GET http://api.ipify.org/?format=json HTTP/1.1\r\nHost: api.ipify.org\r\n"
        if use_auth:
            import base64

            token = base64.b64encode(f"{USER}:{PASS}".encode()).decode()
            req += f"Proxy-Authorization: Basic {token}\r\n"
        req += "Connection: close\r\n\r\n"
        s.sendall(req.encode())
        data = s.recv(4096)
        return data.decode("latin-1").replace("\r\n", " | ").strip()[:400]
    except Exception as exc:  # noqa: BLE001
        return f"ошибка обмена: {exc}"
    finally:
        s.close()


def plain_tls_banner(timeout: float = 10.0) -> str:
    """Что вообще слушает порт: пробуем TLS-handshake напрямую."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((HOST, PORT), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=HOST) as tls:
                return f"TLS установлен, версия: {tls.version()}"
    except Exception as exc:  # noqa: BLE001
        return f"не TLS: {type(exc).__name__}: {exc}"


def main() -> None:
    print("=" * 70)
    print("ДИАГНОСТИКА ПРОКСИ pool.proxy.market:10000")
    print("=" * 70)

    print(f"\n[0] DNS {HOST}:")
    for ip in resolve(HOST):
        print(f"    {ip}")

    print("\n[1] Что слушает порт (TLS напрямую):")
    print(f"    {plain_tls_banner()}")

    print("\n[2] CONNECT без авторизации:")
    print(f"    {raw_connect_via_http(use_auth=False)}")

    print("\n[3] CONNECT С авторизацией:")
    print(f"    {raw_connect_via_http(use_auth=True)}")

    print("\n[4] SOCKS5-handshake:")
    print(f"    {raw_socks5()}")

    print("\n[5] Обычный GET http:// через прокси (с auth):")
    print(f"    {raw_http_get(use_auth=True)}")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
