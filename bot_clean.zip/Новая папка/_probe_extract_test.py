"""Прототип извлечения объявлений по data-marker — проверяем на реальном HTML."""

from __future__ import annotations

import re
from html import unescape
from pathlib import Path
from urllib.parse import urlsplit, urljoin

HTML = Path("_search_real.html").read_text(encoding="utf-8")
HOST = "https://m.avito.ru"

SPLIT = 'data-marker="item"'

RE_ITEM_ID = re.compile(r'data-item-id="(\d+)"')
RE_HREF = re.compile(r'href="([^"]*?_(\d{6,})[^"]*)"')
RE_TITLE = re.compile(r'data-marker="item-title"[^>]*>(.*?)</a>', re.S)
RE_PRICE_META = re.compile(r'itemprop="price"\s+content="(\d+)"', re.I)
RE_PRICE_TEXT = re.compile(r'data-marker="item-price-value"[^>]*>(.*?)</span>', re.S)
RE_DATE = re.compile(r'data-marker="item-date"[^>]*>(.*?)</p>', re.S)
RE_IMG = re.compile(r'<img[^>]+src="(https?://[^"]+)"')
RE_IMG_MARKER = re.compile(r'data-marker="slider-image/image-(https?://[^"]+)"')
RE_LOC = re.compile(r'data-marker="item-location"[^>]*>(.*?)</div>', re.S)
TAG = re.compile(r"<[^>]+>")


def clean(text: str) -> str:
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    return " ".join(unescape(TAG.sub(" ", text)).split())


chunks = HTML.split(SPLIT)[1:]
print(f"блоков после разделения: {len(chunks)}")

items = []
for chunk in chunks:
    m = RE_ITEM_ID.search(chunk[:500])
    if not m:
        continue
    item_id = m.group(1)

    href = RE_HREF.search(chunk)
    url = ""
    if href:
        url = href.group(1)
        url = urljoin(HOST, urlsplit(url)._replace(query="").geturl())

    t = RE_TITLE.search(chunk)
    title = clean(t.group(1)) if t else ""

    pm = RE_PRICE_META.search(chunk)
    pt = RE_PRICE_TEXT.search(chunk)
    price_value = int(pm.group(1)) if pm else None
    price_text = clean(pt.group(1)) if pt else ""

    img = RE_IMG_MARKER.search(chunk) or RE_IMG.search(chunk)
    images = [img.group(1)] if img else []

    d = RE_DATE.search(chunk)
    date = clean(d.group(1)) if d else ""

    loc = RE_LOC.search(chunk)
    location = clean(loc.group(1)) if loc else ""

    if not title:
        continue
    items.append({
        "id": item_id, "title": title, "price": price_text,
        "price_value": price_value, "images": images, "url": url,
        "location": location, "published": date,
    })

print(f"извлечено объявлений: {len(items)}")
print("\n=== Первые 5 ===")
for it in items[:5]:
    print(f"\n  id: {it['id']}")
    print(f"  title: {it['title'][:80]}")
    print(f"  price: {it['price']} ({it['price_value']})")
    print(f"  location: {it['location'][:60]!r}")
    print(f"  date: {it['published']!r}")
    print(f"  images: {[i[:70] for i in it['images']]}")
    print(f"  url: {it['url'][:110]}")

print("\n=== Качество выборки ===")
print(f"  с ценой: {sum(1 for i in items if i['price_value'])}/{len(items)}")
print(f"  с фото: {sum(1 for i in items if i['images'])}/{len(items)}")
print(f"  с url: {sum(1 for i in items if i['url'])}/{len(items)}")
print(f"  с датой: {sum(1 for i in items if i['published'])}/{len(items)}")
print(f"  с локацией: {sum(1 for i in items if i['location'])}/{len(items)}")
ids = [i["id"] for i in items]
print(f"  уникальных id: {len(set(ids))}/{len(ids)}")
