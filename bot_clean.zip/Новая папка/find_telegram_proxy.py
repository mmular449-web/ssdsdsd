"""Утилита: найти рабочий SOCKS5-прокси для Telegram API.

Если бот сыплет ошибками «Cannot connect to host api.telegram.org»,
ваш провайдер режет доступ к API Telegram. Эта утилита скачивает свежий
список публичных SOCKS5 (репозиторий kort0881/telegram-proxy-collector,
обновляется ежечасно через GitHub Actions), проверяет, какие прокси
реально открывают api.telegram.org, и печатит готовую строку для .env.

Запуск:
    .venv\\Scripts\\python.exe find_telegram_proxy.py

Найденный прокси вписать в .env:
    TELEGRAM_PROXY_URL=socks5://host:port

Внимание: публичные прокси нестабильны — периодически перезапускайте
утилитy и обновляйте строку. Токен бота в безопасности: трафик к
api.telegram.org защищён TLS, прокси видит только сам факт соединения.
"""

import asyncio
import re
import sys
import urllib.request
from urllib.parse import parse_qs, urlparse

import aiohttp
from aiohttp_socks import ProxyConnector

SOURCE_URLS = (
    # Ежечасно обновляемый список из репозитория-коллектора
    "https://raw.githubusercontent.com/kort0881/telegram-proxy-collector/"
    "main/socks5.txt",
    # Публичный агрегатор SOCKS5
    "https://api.proxyscrape.com/v2/?request=displayproxies"
    "&protocol=socks5&timeout=8000&country=all",
)
TEST_URL = "https://api.telegram.org"
LIMIT = 0  # 0 = проверять весь список
CONCURRENCY = 25


def load_entries() -> list[tuple[str, int]]:
    """Скачивает свежие списки и парсит их в (host, port)."""
    entries: list[tuple[str, int]] = []
    seen: set[tuple[str, int]] = set()
    for url in SOURCE_URLS:
        print(f"Скачиваю список: {url.split('/')[2]} ...")
        try:
            with urllib.request.urlopen(url, timeout=30) as response:
                text = response.read().decode("utf-8", errors="replace")
        except Exception as exc:
            print(f"   [SKIP] источник недоступен: {exc}")
            continue

        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            entry = None
            if line.startswith("tg://"):
                qs = parse_qs(urlparse(line).query)
                entry = (qs["server"][0], int(qs["port"][0]))
            elif "://" in line:
                u = urlparse(line)
                if u.hostname and u.port:
                    entry = (u.hostname, u.port)
            elif re.match(r"^[\d.]+:\d+$", line):
                host, port = line.split(":")
                entry = (host, int(port))
            if entry and entry not in seen:
                seen.add(entry)
                entries.append(entry)
    return entries


async def check(entry: tuple[str, int], sem: asyncio.Semaphore) -> tuple | None:
    """Прокси проходит проверку, если через него отвечает api.telegram.org."""
    host, port = entry
    url = f"socks5://{host}:{port}"
    async with sem:
        try:
            connector = ProxyConnector.from_url(url)
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(
                connector=connector, timeout=timeout
            ) as session:
                async with session.get(TEST_URL) as resp:
                    return (host, port, resp.status)
        except Exception:
            return None


async def main() -> int:
    entries = load_entries()
    if not entries:
        print("[FAIL] список пуст или недоступен")
        return 1

    print(f"Проверяю {len(entries)} прокси ...")
    sem = asyncio.Semaphore(CONCURRENCY)
    results = await asyncio.gather(*(check(e, sem) for e in entries))
    working = [r[:2] for r in results if r]

    # Контрольный повтор: публичные прокси моргают, берём только
    # подтвердивших работоспособность дважды
    if working:
        print(f"Первичный отбор: {len(working)}, перепроверяю ...")
        recheck = await asyncio.gather(*(check(w, sem) for w in working))
        working = [w for w, r in zip(working, recheck) if r]

    if not working:
        print("[FAIL] рабочих прокси не нашлось — попробуйте позже")
        return 1

    print(f"\n[OK] рабочих прокси: {len(working)}")
    for host, port in working[:5]:
        print(f"   socks5://{host}:{port}")

    best = working[0]
    print(
        f"\nВпишите в .env строку:\n"
        f"TELEGRAM_PROXY_URL=socks5://{best[0]}:{best[1]}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
