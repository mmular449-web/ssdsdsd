"""Хендлеры и кнопки бота AvitoChecker (aiogram 3.x).

Главное меню (reply-клавиатура, по образцу платных ботов-мониторов):
    🚀 Добавить отслеживание      — FSM: бот ждёт ссылку от пользователя
    ⚙️ Редактировать отслеживания — список + inline-кнопки удаления
    ⭐ Избранное                  — объявления, сохранённые кнопкой под карточкой
    🖼 Фото: все/одна             — режим фото в объявлениях
    💡 Профиль                    — статистика пользователя
    ℹ️ Инструкция                 — справка

Под каждым новым объявлением — inline-кнопки:
    💬 Написать продавцу (открывает объявление, где первая кнопка «Написать»)
    ⭐ В избранное / ★ В избранном (переключается повторным нажатием)

Объект БД внедряется через workflow data: dp["db"] = db (см. main.py).
"""

import asyncio
import re
from html import escape
from pathlib import Path

from aiogram import F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)

from config import (
    ADMIN_ID,
    CHECK_INTERVAL_MINUTES,
    PAYMENT_RECEIVER,
    PAYMENT_URL,
    PLAN_MONTH_PRICE,
    PLAN_QUARTER_PRICE,
    PLAN_WEEK_PRICE,
    PLAN_YEAR_PRICE,
    TRIAL_DAYS,
)
from db import Database

router = Router()

# Приветственный баннер (сгенерирован скриптом assets/make_banner.py)
WELCOME_IMAGE = Path(__file__).parent / "assets" / "welcome.png"

# Допустимая ссылка на страницу поиска Авито (в т.ч. мобильная m.avito.ru)
AVITO_URL_RE = re.compile(r"^https?://(?:www\.|m\.)?avito\.ru/\S+$", re.IGNORECASE)

# Кнопки главного меню
BTN_ADD = "🚀 Добавить отслеживание"
BTN_LIST = "⚙️ Редактировать отслеживания"
BTN_FAV = "⭐ Избранное"
BTN_PHOTO_ALL = "🖼 Фото: все"
BTN_PHOTO_ONE = "🖼 Фото: одна"
BTN_PROFILE = "💡 Профиль"
BTN_HELP = "ℹ️ Инструкция"
BTN_SUB = "💳 Продлить подписку"
BTN_CANCEL = "🔙 Отмена"

WELCOME_TEXT = (
    "👋 Привет! Я — <b>AvitoChecker</b>.\n\n"
    "Проверяю Авито каждую минуту и присылаю новые объявления "
    "с фото, ценой и кнопками «💬 Написать продавцу» и «⭐ В избранное».\n\n"
    "<b>Главное меню:</b>\n"
    "🚀 <b>Добавить отслеживание</b> — начну следить за выдачей\n"
    "⚙️ <b>Редактировать отслеживания</b> — список с удалением\n"
    "⭐ <b>Избранное</b> — сохранённые объявления\n"
    "🖼 <b>Фото</b> — присылать все фото или только первую\n"
    "💳 <b>Продлить подписку</b> — тарифы от 99 ₽\n"
    "💡 <b>Профиль</b> • ℹ️ <b>Инструкция</b>\n\n"
    "<b>Как добавить поиск:</b>\n"
    "1️⃣ Открой на Авито поиск с нужными фильтрами "
    "(сортировка «Сначала новые»)\n"
    "2️⃣ Нажми «🚀 Добавить отслеживание» и отправь ссылку "
    "из адресной строки (можно и m.avito.ru)"
)

HELP_TEXT = (
    "ℹ️ <b>Как пользоваться AvitoChecker</b>\n\n"
    "1. Открой на сайте Авито поиск с нужными фильтрами "
    "(город, цена, «Сначала новые»).\n"
    "2. Нажми «🚀 Добавить отслеживание» и пришли ссылку — "
    "мобильная (m.avito.ru) тоже подойдёт, я сам приведу её к обычной.\n"
    "3. Дальше всё само: как только в выдаче появится новое объявление, "
    "придёт карточка с фото, названием и ценой.\n\n"
    "Под каждой карточкой две кнопки:\n"
    "💬 <b>Написать продавцу</b> — открывает объявление, кнопка «Написать» "
    "уже перед глазами\n"
    "⭐ <b>В избранное</b> — сохранит объявление (список — кнопка "
    "«⭐ Избранное» в меню)\n\n"
    "💡 Первый проход по новому поиску только запоминает текущую выдачу — "
    "приходить будут только новые объявления.\n"
    f"⏱ Проверяю Авито каждые {CHECK_INTERVAL_MINUTES:g} мин.\n"
    "🖼 Кнопкой «Фото» выбираешь: альбом всех фото или одну первую.\n"
    f"🎁 Новым пользователям — {TRIAL_DAYS} дней бесплатно; дальше тарифы "
    "от 99 ₽ за неделю (кнопка «💳 Продлить подписку»)."
)


class AddSearch(StatesGroup):
    """FSM-состояние «ждём от пользователя ссылку на поиск»."""

    waiting_link = State()


def main_keyboard(photo_mode: str) -> ReplyKeyboardMarkup:
    """Главное меню; подпись кнопки фото отражает текущий режим."""
    photo_btn = BTN_PHOTO_ALL if photo_mode == "all" else BTN_PHOTO_ONE
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_ADD), KeyboardButton(text=BTN_LIST)],
            [KeyboardButton(text=BTN_FAV), KeyboardButton(text=photo_btn)],
            [KeyboardButton(text=BTN_PROFILE), KeyboardButton(text=BTN_HELP)],
            [KeyboardButton(text=BTN_SUB)],
        ],
        resize_keyboard=True,
    )


CANCEL_KEYBOARD = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text=BTN_CANCEL)]],
    resize_keyboard=True,
)


def build_item_keyboard(item_id: int, item_url: str, in_favorites: bool) -> InlineKeyboardMarkup:
    """Кнопки под объявлением: чат с продавцом + избранное.

    Прямой ссылки «сразу в чат» у Авито нет (мессенджер — внутри сайта
    после авторизации), поэтому кнопка открывает страницу объявления,
    где «Написать» — первая кнопка.
    """
    star = "★ В избранном" if in_favorites else "⭐ В избранное"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💬 Написать продавцу", url=item_url),
                InlineKeyboardButton(text=star, callback_data=f"fav:{item_id}"),
            ]
        ]
    )


def build_list_message(
    queries: list[tuple[int, str, str]],
) -> tuple[str, InlineKeyboardMarkup | None]:
    """Формирует текст списка запросов и inline-кнопки удаления."""
    if not queries:
        return "📭 У вас нет отслеживаемых запросов. Нажмите «🚀 Добавить отслеживание».", None
    lines = ["⚙️ <b>Ваши отслеживания:</b>\n"]
    buttons = []
    for query_id, url, created_at in queries:
        lines.append(f"{query_id}. {escape(url)}\n    <i>добавлен {created_at}</i>")
        buttons.append(
            [
                InlineKeyboardButton(
                    text=f"❌ Удалить #{query_id}",
                    callback_data=f"del:{query_id}",
                )
            ]
        )
    return "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=buttons)


# --------------------------- /start и отмена ---------------------------

@router.message(CommandStart())
async def cmd_start(message: Message, db: Database, state: FSMContext) -> None:
    """Приветствие: баннер + текст + главное меню. Регистрация в БД."""
    await state.clear()  # сбрасываем незавершённый ввод ссылки, если был
    is_new = not await db.user_exists(message.from_user.id)
    await db.add_user(message.from_user.id, active=True)
    photo_mode = await db.get_photo_mode(message.from_user.id)
    markup = main_keyboard(photo_mode)
    if WELCOME_IMAGE.exists():
        # Лимит подписи к фото в Telegram — 1024 символа, текст рассчитан под него
        await message.answer_photo(
            FSInputFile(WELCOME_IMAGE), caption=WELCOME_TEXT, reply_markup=markup
        )
    else:
        await message.answer(WELCOME_TEXT, reply_markup=markup)

    # Пробный период — один раз, только новым пользователям (не админу)
    if is_new and message.from_user.id != ADMIN_ID and TRIAL_DAYS > 0:
        until = await db.extend_subscription(message.from_user.id, TRIAL_DAYS)
        await message.answer(
            f"🎁 <b>Пробный период активирован!</b>\n"
            f"{TRIAL_DAYS} дней бесплатного мониторинга — до <b>{until[:10]}</b>.\n\n"
            "Потом — от 99 ₽ за неделю: кнопка «💳 Продлить подписку»."
        )


@router.message(F.text == BTN_CANCEL)
@router.message(Command("cancel"))
async def cancel_action(message: Message, db: Database, state: FSMContext) -> None:
    """Отмена любого незавершённого действия, возврат в главное меню."""
    await state.clear()
    photo_mode = await db.get_photo_mode(message.from_user.id)
    await message.answer("Отменено.", reply_markup=main_keyboard(photo_mode))


# ------------------- добавление отслеживания (FSM) -------------------

@router.message(F.text == BTN_ADD)
@router.message(Command("add"))
async def start_add_search(message: Message, state: FSMContext) -> None:
    """Спрашиваем у пользователя ссылку на страницу поиска Авито."""
    await state.set_state(AddSearch.waiting_link)
    await message.answer(
        "Отправьте ссылку на страницу поиска Авито "
        "(скопируйте её из адресной строки браузера).",
        reply_markup=CANCEL_KEYBOARD,
    )


# Важно: этот хендлер объявлен ДО прочих кнопок, чтобы во время ввода
# ссылки нажатия других кнопок не перехватывались главным меню.
@router.message(AddSearch.waiting_link, F.text & ~F.text.startswith("/"))
async def process_search_link(message: Message, db: Database, state: FSMContext) -> None:
    """Принимает ссылку, валидирует и сохраняет запрос в мониторинг."""
    # Мобильные ссылки (m.avito.ru) сразу приводим к десктопной версии
    url = normalize_avito_url((message.text or "").strip())

    if not AVITO_URL_RE.match(url):
        await message.answer(
            "⚠️ Это не похоже на ссылку на Авито. Ожидается вида "
            "<code>https://www.avito.ru/...</code> или "
            "<code>https://m.avito.ru/...</code>\n"
            "Попробуйте ещё раз или нажмите «🔙 Отмена»."
        )
        return

    # Гарантируем наличие пользователя (вдруг вводят до /start)
    await db.add_user(message.from_user.id, active=True)
    query_id = await db.add_query(message.from_user.id, url)
    await state.clear()

    photo_mode = await db.get_photo_mode(message.from_user.id)
    if query_id is None:
        await message.answer(
            "ℹ️ Эта ссылка уже отслеживается.",
            reply_markup=main_keyboard(photo_mode),
        )
    else:
        await message.answer(
            f"✅ Запрос #{query_id} добавлен.\n"
            "Первый проход запомнит текущую выдачу — дальше будут "
            "приходить только новые объявления.",
            reply_markup=main_keyboard(photo_mode),
        )


def normalize_avito_url(url: str) -> str:
    """Приводит ссылку к десктопной версии (парсер работает по ней).

    Мобильные ссылки из приложения Авито выглядят как https://m.avito.ru/...
    — заменяем поддомен m на www, остальное не трогаем.
    """
    return re.sub(r"^(https?://)m\.", r"\1www.", url, flags=re.IGNORECASE)


# ------------------- список отслеживаний и удаление -------------------

@router.message(F.text == BTN_LIST)
@router.message(Command("list"))
async def show_queries(message: Message, db: Database) -> None:
    """Показывает запросы пользователя с inline-кнопками удаления."""
    text, markup = build_list_message(await db.get_user_queries(message.from_user.id))
    await message.answer(text, reply_markup=markup)


@router.callback_query(F.data.startswith("del:"))
async def cb_delete_query(callback: CallbackQuery, db: Database) -> None:
    """Удаляет запрос по нажатию inline-кнопки и обновляет список."""
    query_id = int(callback.data.split(":", 1)[1])
    if await db.delete_query(callback.from_user.id, query_id):
        await callback.answer(f"Запрос #{query_id} удалён ✅")
    else:
        await callback.answer("Запрос не найден", show_alert=True)
    # Перерисовываем список в этом же сообщении
    text, markup = build_list_message(await db.get_user_queries(callback.from_user.id))
    await callback.message.edit_text(text, reply_markup=markup)


@router.message(Command("delete"))
async def cmd_delete(message: Message, command: CommandObject, db: Database) -> None:
    """Удаление запроса командой (дублирует inline-кнопку)."""
    args = (command.args or "").strip()
    if not args.isdigit():
        await message.answer("⚠️ Укажите числовой id запроса: <code>/delete 3</code>")
        return
    if await db.delete_query(message.from_user.id, int(args)):
        await message.answer(f"🗑 Запрос #{args} удалён.")
    else:
        await message.answer(f"🤷 Запрос #{args} не найден среди ваших.")


# --------------------------- избранное ---------------------------

@router.message(F.text == BTN_FAV)
async def show_favorites(message: Message, db: Database) -> None:
    """Показывает сохранённые объявления карточками с кнопками."""
    favorites = await db.get_favorites(message.from_user.id, limit=10)
    if not favorites:
        await message.answer(
            "⭐ Избранное пусто.\n"
            "Сохраняйте объявления кнопкой «⭐ В избранное» под ними."
        )
        return

    await message.answer(f"⭐ <b>Избранное</b> (последние {len(favorites)}):")
    for item_id, url, title, price, image, added_at in favorites:
        caption = (
            f"📱 <b>{escape(' '.join(title.split())[:180])}</b>\n"
            f"💰 <b>{escape(price)}</b>\n"
            f"<i>в избранном с {added_at}</i>"
        )
        markup = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="💬 Написать продавцу", url=url),
                    InlineKeyboardButton(
                        text="❌ Убрать", callback_data=f"rmfav:{item_id}"
                    ),
                ]
            ]
        )
        if image:
            await message.answer_photo(image, caption=caption, reply_markup=markup)
        else:
            await message.answer(caption, reply_markup=markup)
        await asyncio.sleep(0.3)  # не упираемся в лимиты Telegram


@router.callback_query(F.data.startswith("fav:"))
async def cb_toggle_favorite(callback: CallbackQuery, db: Database) -> None:
    """Переключает «⭐/★» под объявлением и обновляет кнопку."""
    try:
        item_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return

    added = await db.toggle_favorite(callback.from_user.id, item_id)
    item = await db.get_item(item_id)
    if item is None:
        await callback.answer("Объявление не найдено", show_alert=True)
        return

    markup = build_item_keyboard(item_id, item[1], added)
    try:
        await callback.message.edit_reply_markup(reply_markup=markup)
    except Exception:
        pass  # сообщение могло стать слишком старым для редактирования
    await callback.answer(
        "⭐ Добавлено в избранное" if added else "Убрано из избранного"
    )


@router.callback_query(F.data.startswith("rmfav:"))
async def cb_remove_favorite(callback: CallbackQuery, db: Database) -> None:
    """Убирает объявление из избранного с карточки списка."""
    try:
        item_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return

    if await db.remove_favorite(callback.from_user.id, item_id):
        try:
            if callback.message.photo:
                await callback.message.edit_caption("⭐ Убрано из избранного")
            else:
                await callback.message.edit_text("⭐ Убрано из избранного")
        except Exception:
            pass
        await callback.answer("Убрано из избранного")
    else:
        await callback.answer("Не найдено в избранном", show_alert=True)


# --------------------- профиль и инструкция ---------------------

@router.message(F.text == BTN_PROFILE)
async def show_profile(message: Message, db: Database) -> None:
    """Краткая статистика пользователя."""
    queries = await db.get_user_queries(message.from_user.id)
    favorites = await db.get_favorites(message.from_user.id, limit=100)
    photo_mode = await db.get_photo_mode(message.from_user.id)
    photo_label = "все фото (альбом)" if photo_mode == "all" else "одна (первая)"
    if message.from_user.id == ADMIN_ID:
        sub_label = "∞ бессрочная (администратор)"
    elif await db.has_active_subscription(message.from_user.id):
        sub_label = f"до {(await db.get_subscription(message.from_user.id))[:10]}"
    else:
        sub_label = "не активна"
    await message.answer(
        "💡 <b>Профиль</b>\n\n"
        f"🔎 Отслеживаний: <b>{len(queries)}</b>\n"
        f"⭐ В избранном: <b>{len(favorites)}</b>\n"
        f"🖼 Режим фото: <b>{photo_label}</b>\n"
        f"💳 Подписка: <b>{sub_label}</b>\n"
        f"⏱ Проверка Авито: <b>каждые {CHECK_INTERVAL_MINUTES:g} мин.</b>"
    )


@router.message(F.text == BTN_HELP)
async def show_help(message: Message) -> None:
    """Справка по использованию."""
    await message.answer(HELP_TEXT)


# --------------------- подписка и оплата ---------------------

# Тарифы: ключ callback -> (название, дней, цена ₽)
PLANS: dict[str, tuple[str, int, int]] = {
    "week": ("Неделя", 7, PLAN_WEEK_PRICE),
    "month": ("Месяц", 30, PLAN_MONTH_PRICE),
    "quarter": ("3 месяца", 90, PLAN_QUARTER_PRICE),
    "year": ("Год", 365, PLAN_YEAR_PRICE),
}


def _is_http_url(url: str) -> bool:
    """Пригодна ли ссылка оплаты для URL-кнопки Telegram."""
    return (
        url.startswith(("http://", "https://"))
        and url.isascii()
        and " " not in url
    )


@router.message(F.text == BTN_SUB)
async def show_subscription(message: Message, db: Database) -> None:
    """Экран подписки: текущий статус + выбор тарифа."""
    if message.from_user.id == ADMIN_ID:
        await message.answer("👑 Вы администратор — подписка вам не нужна.")
        return

    until = await db.get_subscription(message.from_user.id)
    if await db.has_active_subscription(message.from_user.id):
        current = f"✅ активна до <b>{until[:10]}</b>"
    else:
        current = "❌ не активна"

    await message.answer(
        "💳 <b>Подписка</b>\n\n"
        f"Текущая: {current}\n\n"
        "Выберите тариф:",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text=f"Неделя · {PLAN_WEEK_PRICE} ₽",
                        callback_data="plan:week",
                    ),
                    InlineKeyboardButton(
                        text=f"Месяц · {PLAN_MONTH_PRICE} ₽",
                        callback_data="plan:month",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        text=f"3 месяца · {PLAN_QUARTER_PRICE} ₽",
                        callback_data="plan:quarter",
                    ),
                    InlineKeyboardButton(
                        text=f"Год · {PLAN_YEAR_PRICE} ₽",
                        callback_data="plan:year",
                    ),
                ],
            ]
        ),
    )


@router.callback_query(F.data.startswith("plan:"))
async def cb_select_plan(callback: CallbackQuery) -> None:
    """Показывает выбранный тариф: ссылка на оплату + «Я оплатил»."""
    key = callback.data.split(":", 1)[1]
    plan = PLANS.get(key)
    if plan is None:
        await callback.answer()
        return
    name, days, price = plan
    if not _is_http_url(PAYMENT_URL):
        await callback.answer(
            "Приём платежей пока не настроен, попробуйте позже", show_alert=True
        )
        return

    receiver = (
        f" Получатель: <b>{escape(PAYMENT_RECEIVER)}</b>."
        if PAYMENT_RECEIVER
        else ""
    )
    await callback.message.edit_text(
        f"💳 <b>Тариф: {name}</b> — {price} ₽ ({days} дн.)\n\n"
        "1️⃣ Нажмите «Оплатить по СБП» — откроется приложение вашего банка\n"
        f"2️⃣ Переведите ровно <b>{price} ₽</b>{receiver}\n"
        "3️⃣ Вернитесь в бота и нажмите «✅ Я оплатил»\n"
        "4️⃣ Подписка активируется после подтверждения администратором",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text=f"💳 Оплатить по СБП", url=PAYMENT_URL
                    ),
                    InlineKeyboardButton(
                        text="✅ Я оплатил", callback_data=f"paidreq:{key}"
                    ),
                ]
            ]
        ),
    )


@router.callback_query(F.data.startswith("paidreq"))
async def cb_payment_request(callback: CallbackQuery, db: Database) -> None:
    """Пользователь нажал «Я оплатил» — заявка с тарифом уходит админу."""
    if not ADMIN_ID:
        await callback.answer("Оплата не настроена", show_alert=True)
        return
    key = callback.data.split(":", 1)[1] if ":" in callback.data else ""
    plan = PLANS.get(key)
    if plan is None:
        await callback.answer()
        return
    name, days, price = plan

    user = callback.from_user
    # Админ мог нажать кнопку сам себе — сразу выдаём
    if user.id == ADMIN_ID:
        until = await db.extend_subscription(user.id, days)
        await callback.answer(f"Подписка выдана до {until[:10]}")
        return

    # Юзеру: заявка принята
    await callback.answer("Заявка отправлена, ожидайте подтверждения 🙏")
    # Админу: карточка заявки с кнопками выдачи
    await callback.bot.send_message(
        ADMIN_ID,
        "💰 <b>Заявка на подписку</b>\n\n"
        f"Юзер: {escape(user.full_name)}\n"
        f"ID: <code>{user.id}</code>\n"
        f"Username: @{user.username or '—'}\n\n"
        f"Тариф: <b>{name}</b> — {price} ₽ ({days} дн.)\n"
        "Проверьте поступление и выдайте подписку.",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text=f"✅ Выдать {days} дн.",
                        callback_data=f"grant:{user.id}:{days}",
                    ),
                    InlineKeyboardButton(
                        text="❌", callback_data=f"deny:{user.id}"
                    ),
                ]
            ]
        ),
    )


@router.callback_query(F.data.startswith("grant:"))
async def cb_grant_subscription(callback: CallbackQuery, db: Database) -> None:
    """Админ подтверждает оплату — подписка выдаётся автоматически."""
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("⛔ Только администратор", show_alert=True)
        return
    parts = callback.data.split(":")  # grant:<user_id>:<days>
    if len(parts) != 3 or not parts[1].isdigit() or not parts[2].isdigit():
        await callback.answer()
        return
    user_id, days = int(parts[1]), int(parts[2])

    if not await db.user_exists(user_id):
        await callback.answer("Пользователь не найден в БД", show_alert=True)
        return

    until = await db.extend_subscription(user_id, days)
    await callback.answer(f"✅ Выдано до {until[:10]}")
    try:
        await callback.bot.send_message(
            user_id,
            f"✅ Подписка активирована до <b>{until[:10]}</b>.\n"
            "Спасибо, что поддерживаете бота! 🙌",
        )
    except Exception:
        pass  # юзер мог остановить бота — не критично


@router.callback_query(F.data.startswith("deny:"))
async def cb_deny_subscription(callback: CallbackQuery) -> None:
    """Админ отклоняет заявку."""
    if callback.from_user.id != ADMIN_ID:
        await callback.answer("⛔ Только администратор", show_alert=True)
        return
    try:
        user_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer()
        return
    await callback.answer("Заявка отклонена")
    try:
        await callback.bot.send_message(
            user_id, "⚠️ Заявка на подписку отклонена. Свяжитесь с администратором."
        )
    except Exception:
        pass


@router.message(Command("grant"))
async def cmd_grant(message: Message, command: CommandObject, db: Database) -> None:
    """/grant <user_id> <дней> — ручная выдача подписки (только админ)."""
    if message.from_user.id != ADMIN_ID:
        await message.answer("⛔ Команда только для администратора")
        return
    parts = (command.args or "").split()
    if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
        await message.answer("⚠️ Формат: <code>/grant &lt;user_id&gt; &lt;дней&gt;</code>")
        return
    user_id, days = int(parts[0]), int(parts[1])
    if not await db.user_exists(user_id):
        await message.answer("🤷 Пользователь не найден в БД")
        return
    until = await db.extend_subscription(user_id, days)
    await message.answer(f"✅ Подписка {user_id} продлена до {until[:10]}")


# --------------------- режим фото: все или одна ---------------------

@router.message(F.text.in_({BTN_PHOTO_ALL, BTN_PHOTO_ONE}))
async def toggle_photo_mode(message: Message, db: Database) -> None:
    """Переключает режим фото: альбом всех фото ↔ первая фотография."""
    # Кнопка показывает текущее состояние — нажатие переключает на другое
    new_mode = "one" if message.text == BTN_PHOTO_ALL else "all"
    await db.add_user(message.from_user.id, active=True)  # upsert на всякий случай
    await db.set_photo_mode(message.from_user.id, new_mode)

    if new_mode == "one":
        description = "одну фотографию — первую картинку объявления"
    else:
        description = "все фотографии объявления (до 10 за раз)"
    await message.answer(
        f"✅ Теперь буду присылать {description}.",
        reply_markup=main_keyboard(new_mode),
    )
