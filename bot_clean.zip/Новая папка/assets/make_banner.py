"""Генератор приветственного баннера бота (assets/welcome.png).

Рендерит assets/banner.html в PNG через Playwright (Chromium уже
установлен для парсера). Запуск из корня проекта:

    .venv\\Scripts\\python.exe assets\\make_banner.py

После правки banner.html просто запустите скрипт заново.
"""

import asyncio
from pathlib import Path

from playwright.async_api import async_playwright

ASSETS_DIR = Path(__file__).parent
BANNER_HTML = ASSETS_DIR / "banner.html"
WELCOME_PNG = ASSETS_DIR / "welcome.png"

WIDTH, HEIGHT = 1200, 630


async def main() -> None:
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        try:
            page = await browser.new_page(
                viewport={"width": WIDTH, "height": HEIGHT},
                device_scale_factor=2,  # ретина-масштаб для чёткости
            )
            await page.goto(BANNER_HTML.as_uri())
            await page.wait_for_timeout(400)  # даём отрисоваться шрифтам
            await page.screenshot(path=str(WELCOME_PNG))
            print(f"[OK] баннер сохранён: {WELCOME_PNG}")
        finally:
            await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
