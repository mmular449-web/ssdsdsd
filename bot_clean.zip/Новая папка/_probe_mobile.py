"""Эмпирический замер: что реально отдаёт m.avito.ru (не по коду, а по факту).

Прогоняет цепочку запросов через один persistent AsyncSession c
impersonate="chrome120" и печатает статусы, куки и маркеры вёрстки.
"""

from __future__ import annotations

import asyncio
import re
import time

from curl_cffi import AsyncSession

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

MARKERS = ("__initialState__", "initial-state", "__NEXT_DATA__", "__NUXT__",
           "application/ld+json", "data-marker=\"item\"", "item-card",
           "Доступ ограничен", "captcha", "Проверка безопасности",
           "items-catalog", "js-catalog")


def report(label: str, status: int, body: str, cookies: list[str],
           elapsed: float) -> None:
    head = re.sub(r"\s+", " ", body[:220]) if body else ""
    found = [m for m in MARKERS if m in body]
    print(f"\n--- {label}")
    print(f"    HTTP {status} | {len(body)} байт | {elapsed:.2f} с")
    print(f"    куки сессии: {cookies or 'НЕТ'}")
    print(f"    маркеры: {found or 'нет'}")
    print(f"    начало тела: {head[:200]}")


async def main() -> None:
    async with AsyncSession(impersonate="chrome120", timeout=30) as s:
        s.headers.update({"User-Agent": UA})

        # 1. Закрытый внутренний API — то, от чего уходим
        for label, url in (
            ("API /api/30/items",
             "https://m.avito.ru/api/30/items?locationId=637640&q=hollister"),
            ("API /api/29/items",
             "https://m.avito.ru/api/29/items?locationId=637640&q=hollister"),
            ("API /api/1/locations",
             "https://m.avito.ru/api/1/locations?q=moskva&limit=1"),
        ):
            t0 = time.perf_counter()
            try:
                r = await s.get(url)
                report(label, r.status_code, r.text or "", list(s.cookies.keys()),
                       time.perf_counter() - t0)
            except Exception as exc:
                print(f"\n--- {label}\n    ОШИБКА: {type(exc).__name__}: {exc}")

        # 2. Warm-up: обязательный GET на главную мобильной версии
        t0 = time.perf_counter()
        try:
            r = await s.get("https://m.avito.ru/")
            report("WARM-UP /m.avito.ru/", r.status_code, r.text or "",
                   list(s.cookies.keys()), time.perf_counter() - t0)
        except Exception as exc:
            print(f"\n--- WARM-UP\n    ОШИБКА: {type(exc).__name__}: {exc}")
            return

        # 3. Поисковая выдача мобильной версии (после прогрева, та же сессия)
        for label, url in (
            ("SEARCH /m.avito.ru/moskva?q=hollister",
             "https://m.avito.ru/moskva?q=hollister"),
            ("SEARCH /m.avito.ru/moskva/odezhda",
             "https://m.avito.ru/moskva/odezhda"),
        ):
            t0 = time.perf_counter()
            try:
                r = await s.get(url)
                report(label, r.status_code, r.text or "", list(s.cookies.keys()),
                       time.perf_counter() - t0)
            except Exception as exc:
                print(f"\n--- {label}\n    ОШИБКА: {type(exc).__name__}: {exc}")


if __name__ == "__main__":
    asyncio.run(main())
